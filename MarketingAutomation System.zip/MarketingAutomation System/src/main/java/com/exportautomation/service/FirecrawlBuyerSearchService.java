package com.exportautomation.service;

import com.exportautomation.config.FirecrawlConfig;
import com.exportautomation.dto.BuyerSearchResult;
import com.exportautomation.repository.BuyerRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URI;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import reactor.core.publisher.Mono;

@Service
public class FirecrawlBuyerSearchService {

    private static final Logger logger = LoggerFactory.getLogger(FirecrawlBuyerSearchService.class);

    // Search queries are built product-first because Firecrawl ranks keywords
    // left-to-right: the user's PRODUCT is always the primary term. Diversity
    // comes from many DIVERSIFIED query strategies derived from the user's 4
    // fields, e.g. for "Crystal Singing Bowls", Texas, Plano:
    //   "Crystal Singing Bowls" "Plano" TX
    //   "Crystal Singing Bowls" "Plano" shop
    //   "Crystal Singing Bowls" "Plano" store
    //   "Crystal Singing Bowls" "Dallas" TX      (nearby metro hub)
    //   "Crystal Singing Bowls" Texas wholesale / distributor / supplier / retailer
    // Firecrawl has no offset pagination, so a strategy is never fired twice.
    // When a strategy only returns already-known businesses, the search jumps
    // to a DIFFERENT strategy instead of re-running the same location form,
    // because the goal is discovering NEW buyers.
    // SOCIAL TARGETING: after the exact/web phases, a dedicated LinkedIn +
    // Facebook pass fires site:linkedin.com / site:facebook.com queries for the
    // SAME product + location the user selected. It SHARES the single
    // 6-request Firecrawl budget with the web passes, so web + social together
    // can never exceed 6 Firecrawl requests per search, and it only accepts
    // company/showcase and business-page URLs - individual person profiles are
    // still rejected.
    private static final String[][] NATIONWIDE_QUERY_WORDS = {
        {"shop", "Retailer"},
        {"store", "Retailer"},
        {"wholesale", "Wholesaler"},
        {"distributor", "Distributor"},
        {"supplier", "Supplier"},
        {"importer", "Importer"},
        {"retailer", "Retailer"},
        {"home decor store", "Retailer"},
        {"bulk", "Wholesaler"},
        {"custom", "Buyer"},
        {"buy online", "Retailer"}
    };

    // Major cities per US state and Canadian province, used to automatically
    // broaden the search when the SELECTED city does not provide enough NEW
    // buyers: selected city first, then other major cities of the same region,
    // then the region overall. A city already chosen by the user is skipped.
    // It never changes location verification: results are still required not to
    // conflict with the selected region, and unverifiable locations are saved
    // as Unknown rather than guessed.
    private static final Map<String, List<String>> REGION_MAJOR_CITIES = Map.ofEntries(
        Map.entry("alabama", List.of("Birmingham", "Mobile", "Montgomery")),
        Map.entry("alaska", List.of("Anchorage", "Fairbanks", "Juneau")),
        Map.entry("arizona", List.of("Phoenix", "Tucson", "Mesa")),
        Map.entry("arkansas", List.of("Little Rock", "Fort Smith", "Fayetteville")),
        Map.entry("california", List.of("Los Angeles", "San Diego", "San Jose", "San Francisco",
                "Sacramento", "Fresno", "Long Beach", "Oakland", "Anaheim", "Bakersfield", "Stockton", "Riverside")),
        Map.entry("colorado", List.of("Denver", "Colorado Springs", "Boulder")),
        Map.entry("connecticut", List.of("Hartford", "New Haven", "Stamford")),
        Map.entry("delaware", List.of("Wilmington", "Dover", "Newark")),
        Map.entry("florida", List.of("Miami", "Orlando", "Tampa", "Jacksonville", "St. Petersburg",
                "Hialeah", "Fort Lauderdale", "Tallahassee", "Gainesville", "Naples", "West Palm Beach")),
        Map.entry("georgia", List.of("Atlanta", "Savannah", "Augusta")),
        Map.entry("hawaii", List.of("Honolulu", "Hilo", "Kailua")),
        Map.entry("idaho", List.of("Boise", "Idaho Falls", "Meridian")),
        Map.entry("illinois", List.of("Chicago", "Springfield", "Rockford")),
        Map.entry("indiana", List.of("Indianapolis", "Fort Wayne", "Evansville")),
        Map.entry("iowa", List.of("Des Moines", "Cedar Rapids", "Davenport")),
        Map.entry("kansas", List.of("Wichita", "Kansas City", "Topeka")),
        Map.entry("kentucky", List.of("Louisville", "Lexington", "Bowling Green")),
        Map.entry("louisiana", List.of("New Orleans", "Baton Rouge", "Shreveport", "Lafayette")),
        Map.entry("maine", List.of("Portland", "Bangor", "Lewiston")),
        Map.entry("maryland", List.of("Baltimore", "Annapolis", "Rockville")),
        Map.entry("massachusetts", List.of("Boston", "Worcester", "Springfield")),
        Map.entry("michigan", List.of("Detroit", "Grand Rapids", "Ann Arbor")),
        Map.entry("minnesota", List.of("Minneapolis", "Saint Paul", "Duluth")),
        Map.entry("mississippi", List.of("Jackson", "Gulfport", "Biloxi")),
        Map.entry("missouri", List.of("St. Louis", "Kansas City", "Springfield")),
        Map.entry("montana", List.of("Billings", "Missoula", "Great Falls")),
        Map.entry("nebraska", List.of("Omaha", "Lincoln", "Grand Island")),
        Map.entry("nevada", List.of("Las Vegas", "Reno", "Henderson")),
        Map.entry("new hampshire", List.of("Manchester", "Nashua", "Concord")),
        Map.entry("new jersey", List.of("Newark", "Jersey City", "Paterson")),
        Map.entry("new mexico", List.of("Albuquerque", "Santa Fe", "Las Cruces")),
        Map.entry("new york", List.of("New York", "Buffalo", "Rochester", "Albany", "Yonkers",
                "Syracuse", "Utica", "White Plains", "Schenectady")),
        Map.entry("north carolina", List.of("Charlotte", "Raleigh", "Greensboro")),
        Map.entry("north dakota", List.of("Fargo", "Bismarck", "Grand Forks")),
        Map.entry("ohio", List.of("Columbus", "Cleveland", "Cincinnati", "Toledo")),
        Map.entry("oklahoma", List.of("Oklahoma City", "Tulsa", "Norman")),
        Map.entry("oregon", List.of("Portland", "Eugene", "Salem")),
        Map.entry("pennsylvania", List.of("Philadelphia", "Pittsburgh", "Allentown")),
        Map.entry("rhode island", List.of("Providence", "Warwick", "Cranston")),
        Map.entry("south carolina", List.of("Columbia", "Charleston", "Greenville")),
        Map.entry("south dakota", List.of("Sioux Falls", "Rapid City", "Aberdeen")),
        Map.entry("tennessee", List.of("Nashville", "Memphis", "Knoxville")),
        // Texas: ordered pool of IMPORTANT cities (never every Texas town).
        // The selected city is searched FIRST, then this list rotates in one
        // NEW city per remaining request (order = importance), and only LAST
        // does a query go state-wide. Buying requests are never spent on a
        // city already searched or on cities beyond the remaining budget.
        Map.entry("texas", List.of(
                "Houston", "Austin", "San Antonio", "Dallas", "Fort Worth",
                "El Paso", "Arlington", "Corpus Christi", "Plano", "Laredo",
                "Lubbock", "Garland", "Irving", "Amarillo", "Grand Prairie",
                "McKinney", "Frisco", "Brownsville", "Pasadena", "Killeen",
                "McAllen", "Waco", "Carrollton", "Denton", "Midland", "Abilene",
                "Beaumont", "Round Rock", "Richardson", "Conroe", "Tyler",
                "Lewisville", "League City", "Pearland", "College Station",
                "Sugar Land", "Edinburg", "Mission", "Longview", "Odessa",
                "Bryan", "San Angelo", "Victoria", "Temple", "Pharr",
                "New Braunfels")),
        Map.entry("utah", List.of("Salt Lake City", "Provo", "Ogden")),
        Map.entry("vermont", List.of("Burlington", "Montpelier", "South Burlington")),
        Map.entry("virginia", List.of("Virginia Beach", "Richmond", "Norfolk", "Arlington")),
        Map.entry("washington", List.of("Seattle", "Spokane", "Tacoma")),
        Map.entry("west virginia", List.of("Charleston", "Huntington", "Morgantown")),
        Map.entry("wisconsin", List.of("Milwaukee", "Madison", "Green Bay")),
        Map.entry("wyoming", List.of("Cheyenne", "Casper", "Laramie")),
        Map.entry("district of columbia", List.of("Washington")),
        Map.entry("alberta", List.of("Calgary", "Edmonton", "Red Deer", "Lethbridge",
                "St. Albert", "Medicine Hat")),
        Map.entry("british columbia", List.of("Vancouver", "Surrey", "Victoria", "Burnaby",
                "Richmond", "Kelowna", "Abbotsford", "Nanaimo")),
        Map.entry("manitoba", List.of("Winnipeg", "Brandon", "Steinbach")),
        Map.entry("new brunswick", List.of("Moncton", "Saint John", "Fredericton")),
        Map.entry("newfoundland and labrador", List.of("St. John's", "Corner Brook", "Mount Pearl")),
        Map.entry("nova scotia", List.of("Halifax", "Sydney", "Dartmouth")),
        Map.entry("ontario", List.of("Toronto", "Ottawa", "Mississauga", "Hamilton", "London",
                "Brampton", "Kitchener", "Windsor", "Oshawa", "Thunder Bay", "Guelph")),
        Map.entry("prince edward island", List.of("Charlottetown", "Summerside", "Stratford")),
        Map.entry("quebec", List.of("Montreal", "Quebec City", "Laval")),
        Map.entry("saskatchewan", List.of("Saskatoon", "Regina", "Prince Albert")),
        Map.entry("northwest territories", List.of("Yellowknife", "Inuvik", "Hay River")),
        Map.entry("nunavut", List.of("Iqaluit", "Rankin Inlet", "Arviat")),
        Map.entry("yukon", List.of("Whitehorse", "Dawson City"))
    );

    // Major USA + Canada cities used to broaden a city search when the user did
    // not select a state/province to scope the "other cities" phase to.
    private static final List<String> NATIONWIDE_MAJOR_CITIES = List.of(
        "Houston", "Chicago", "Los Angeles", "Miami", "Seattle", "Denver",
        "San Francisco", "Boston", "Phoenix", "Toronto", "Vancouver", "Montreal"
    );

    // When this fraction of a strategy's raw results are already-known
    // businesses (existing DB rows / returned earlier in this search) and none
    // are new, the remaining same-location-form strategies are skipped: keep
    // discovering NEW businesses instead of re-running queries that only
    // produce duplicates.
    private static final double DUP_HEAVY_RATIO = 0.6;

    // Firecrawl search returns a single batch of results per call (no offset
    // pagination), so each round advances to the next query strategy. A search
    // NEVER fires more than 6 requests (first attempts + 429 retries all share
    // the same 6-request global budget). With a selected city the search uses
    // PROGRESSIVE GEOGRAPHIC BROADENING - the requested city first, then the
    // requested state, then the whole country - never rotating through other
    // cities. Every query pairs a DIFFERENT in-family product variant with a
    // DIFFERENT commercial buyer word and a narrower/later location:
    //   Phase "requested city"    : R1-R2 - "<Product>" <City> <State>
    //   Phase "state-wide"        : R3-R4 - "<Product>" <State>
    //   Phase "nationwide"        : R5-R6 - "<Product>" <USA>
    private static final int RESULTS_PER_QUERY = 20;
    // Firecrawl searches are fired one at a time and globally paced so the
    // account's requests-per-minute budget is never exhausted. The plan allows
    // 20 requests/minute, so the pacing below keeps a safe margin.
    private static final long MIN_FIRECRAWL_REQUEST_INTERVAL_MS = 3500;
    // A rate-limited (429) query retries at most twice after the initial call
    // (3 attempts total). The FIRST retry waits for the server-provided
    // Retry-After when the 429 response includes one (never retried
    // immediately); without a header the fixed short backoff below is used.
    // After the retries the query is skipped - no long, repeated waits.
    private static final int MAX_429_RETRIES = 2;
    private static final long[] FIRE_429_RETRY_BASE_DELAY_MS = {2500, 6000};
    private static final long[] FIRE_429_RETRY_JITTER_MS = {500, 1000};
    // Hard cap on a server-provided Retry-After (429): the search waits at most
    // this long, never indefinitely, even if the server asks for more.
    private static final long MAX_SERVER_RETRY_AFTER_MS = 60_000;
    // Hard cap on actual Firecrawl API requests (first attempts + retries) for
    // a whole buyer search, so credits are never wasted on retries or on
    // searching after enough new buyers have been found. EVERY search - city,
    // state or nationwide - uses exactly this budget: no search ever exceeds 6.
    private static final int MAX_FIRECRAWL_REQUESTS_PER_SEARCH = 6;
    // Timestamp of the most recent Firecrawl request, shared across all searches
    // so two concurrent buyer-searches can never burst past the rate limit.
    private static final AtomicLong LAST_FIRECRAWL_REQUEST_NANOS = new AtomicLong(0);

    private static final int EMAIL_DISCOVERY_PARALLELISM = 8;

    // Hostnames that never represent an actual buyer business (social profiles,
    // business directories, review/content sites). Such hosts are excluded from
    // Firecrawl searches (excludeDomains) AND filtered again locally so a
    // profile/directory listing can never be returned as a buyer. Marketplace
    // hosts (amazon, ebay, etsy, ...) are NOT listed here: those pages are
    // evaluated by content - a generic product page is rejected, while a page
    // that clearly identifies a distinct relevant seller business may pass.
    // Event/ticket platforms are excluded too: an event listing (workshop,
    // sound bath, class) is not a business that provides/sells the product.
    private static final Set<String> NON_BUSINESS_HOSTS = Set.of(
        "linkedin.com", "facebook.com", "instagram.com", "twitter.com", "x.com",
        "youtube.com", "pinterest.com", "tiktok.com", "snapchat.com",
        "yelp.com", "yelp.ca", "glassdoor.com", "indeed.com",
        "foursquare.com", "angieslist.com", "mapquest.com", "yellowpages.com",
        "manta.com", "whitepages.com", "bbb.org", "trustpilot.com",
        "houzz.com", "behance.net", "dribbble.com", "medium.com",
        "crunchbase.com", "zoominfo.com", "wikipedia.org", "quora.com",
        "reddit.com", "tripadvisor.com", "city-data.com", "imdb.com",
        "eventbrite.com", "eventbrite.ca", "eventbrite.co.uk", "meetup.com",
        "poshmark.com", "mercari.com", "depop.com", "vinted.com",
        "thredup.com", "ebth.com", "chairish.com", "bonanza.com",
        "ebid.net", "worthpoint.com", "1stdibs.com",
        // Content/news sites and event-listings that surface in product queries
        // but are not buyer businesses: magazines, trade journals, event
        // planners, ticket marketplaces, podcast carriers and database portals.
        "menshealth.com", "avnetwork.com", "partyslate.com",
        "escholarship.org", "vividseats.com", "apple.com", "jogs.com", "etnow.com",
        // Marketplaces / online platforms sell many third-party products - a
        // listing there is never a specific business website with its own
        // product, so they are excluded from searches and rejected outright.
        "etsy.com", "ebay.com", "ebay.ca", "ebay.co.uk", "amazon.com", "amazon.ca",
        "amazon.co.uk", "alibaba.com", "aliexpress.com", "walmart.com", "target.com",
        "faire.com", "atly.com", "importyeti.com", "panjiva.com",
        "made-in-china.com", "dhgate.com", "zibbet.com", "wish.com",
        "wayfair.com", "overstock.com", "taobao.com", "shopee.com"
    );

    // Marketplace / aggregator hosts. Generic product pages on these sites are
    // rejected as "shopping/product page"; a page that clearly identifies a
    // distinct relevant seller business is still considered.
    private static final Set<String> SHOPPING_HOSTS = Set.of(
        "amazon.com", "amazon.ca", "amazon.co.uk", "amazon.de", "amazon.fr",
        "amazon.it", "amazon.es", "amazon.in", "amazon.ae", "amazon.com.au",
        "ebay.com", "ebay.co.uk", "ebay.de", "ebay.com.au", "ebay.in",
        "etsy.com", "etsy.co.uk", "etsy.com.au",
        "alibaba.com", "aliexpress.com", "1688.com", "taobao.com", "tmall.com",
        "walmart.com", "target.com", "bestbuy.com", "homedepot.com", "lowes.com",
        "costco.com", "wayfair.com", "overstock.com", "macys.com",
        "flipkart.com", "shopclues.com", "meesho.com", "shein.com", "temu.com",
        "noon.com", "jd.com", "wish.com", "dhgate.com", "zoro.com", "uline.com"
    );

    // Platform / site-builder hosts: the business has no independent domain, so
    // a title without a distinct brand (e.g. "Singing Bowls - myshopify.com")
    // is treated like a generic product/shopping page.
    private static final Set<String> PLATFORM_HOST_SUFFIXES = Set.of(
        ".myshopify.com", ".shopify.com", ".wixsite.com", ".squarespace.com",
        ".weebly.com", ".bigcartel.com", ".godaddysites.com", ".yolasite.com",
        ".webnode.", ".carrd.co", ".about.me", ".square.site"
    );

    // Brand words that alone never prove a distinct seller business (the
    // marketplace's own identity, or generic commerce words).
    private static final Set<String> AGGREGATOR_BRANDS = Set.of(
        "amazon", "ebay", "etsy", "alibaba", "ali express", "aliexpress",
        "ubuy", "desertcart", "walmart", "target", "shopee", "wish", "temu",
        "shein", "flipkart", "meesho", "noon", "zazzle", "dhgate", "taobao",
        "tmall", "1688", "gearbest", "banggood"
    );

    private static final Set<String> COMMERCE_NOISE_WORDS = Set.of(
        "online", "shop", "store", "stores", "shopping", "marketplace", "mall",
        "deals", "deal", "order", "orders", "cart", "price", "prices",
        "wholesale", "wholesaler", "wholesalers", "retail", "retailer",
        "retailers", "importer", "importers", "distributor", "distributors",
        "supplier", "suppliers", "vendor", "vendors", "trade", "trading",
        "buy", "buying", "buyers", "boutique", "ware", "wares", "goods",
        "outlet", "kiosk", "hub", "trends", "ltd", "llc", "inc", "company",
        "limited", "corp", "pvt", "usa", "com", "uk", "in", "ca", "au"
    );

    private static final Set<String> SHOPPING_PATH_MARKERS = Set.of(
        "/product/", "/product-", "/products/", "/products-", "/pdp",
        "/item/", "/dp/", "/gp/", "/catalog/", "/browse/", "/cart",
        "/checkout", "/offers/", "/compare", "/buy/", "/sku/", "/variant",
        "/collection", "/collections"
    );

    // Commerce (physical-product seller) sentences that, appearing NEAR a
    // genuine product phrase, prove the business actually sells the physical
    // product rather than merely writing about it. Deliberately excludes
    // service/ritual words (class, workshop, retreat, session, event, tickets,
    // book, register, enrol) so service-based pages never pass.
    private static final List<String> COMMERCE_SIGNAL_PHRASES = List.of(
        "we sell", "we carry", "we offer", "for sale", "sells", "selling",
        "buy", "buying", "purchase", "purchases", "purchasing", "shop now",
        "shop online", "shop our", "our shop", "online shop", "online store",
        "estore", "storefront", "add to cart", "add to basket", "cart",
        "checkout", "order now", "order online", "in stock", "on sale",
        "wholesale", "wholesaler", "wholesalers", "retail", "retailer",
        "retailers", "catalog", "catalogue", "catalogs", "collection",
        "collections", "product line", "product range", "product listing",
        "products", "price", "prices", "pricing", "discount", "supplier",
        "suppliers", "distributor", "distributors", "importer", "importers",
        "dealer", "dealers", "stockist", "stockists", "vendor", "vendors",
        "handmade", "handcrafted", "made to order", "custom order",
        "shipping", "free shipping", "delivery", "gift", "gifts", "boutique",
        "merchandise");

    // Business identity markers: standard pages every genuine business site
    // carries (About/Contact/address/phone/company/store phrases). They let the
    // DIRECT relevance gate accept a real business that names the product even
    // when no price/cart sentence sits right beside it - while articles, news,
    // event and directory pages (already filtered by classifyPage) stay out.
    private static final Set<String> BUSINESS_IDENTITY_MARKERS = Set.of(
        "about us", "about our store", "about our company", "our company",
        "our store", "our shop", "our business", "contact us", "contact our",
        "visit our store", "visit us", "call us", "email us", "send us a message",
        "address", "address:", "located at", "location", "phone", "telephone",
        "phone number", "fax", "hours", "store hours", "privacy policy",
        "terms of service", "terms & conditions", "terms and conditions",
        "our products", "our catalog", "our catalogue", "shop our",
        "view our", "best sellers", "our team", "our founder", "customer service",
        "faq", "shipping policy", "returns policy");

    private static final Set<String> SHOPPING_QUERY_KEYS = Set.of(
        "pid", "product", "products", "sku", "item", "asin", "variant",
        "offer", "ean", "upc", "prodid", "product_id"
    );

    private static final Set<String> SHOPPING_TITLE_MARKERS = Set.of(
        "add to cart", "buy now", "shop now", "free shipping",
        "online shopping", "compare prices", "best price", "lowest price",
        "checkout", "shopping cart", "in stock", "buy online", "order now",
        "save big", "% discount", "% off", "flash sale", "great deal"
    );

    private static final Set<String> ARTICLE_TITLE_MARKERS = Set.of(
        "how to", "top 10", "top ten", "10 best", "5 best", "best of",
        "guide to", "guide for", "review of", "reviews of", " review",
        "article", "what is a", "what are", "why you should",
        "everything you need", "tips for", "all about", "learn about",
        "a beginner's guide", "beginners guide", "the history of"
    );

    // Content/news hosts that routinely surface in product searches but are
    // never buyer businesses: online magazines, trade journals, event planners,
    // ticket marketplaces, research repositories and podcast carriers. Any page
    // on these hosts is classified as an article/news page, not a business.
    private static final Set<String> CONTENT_NEWS_HOST_PARTS = Set.of(
        "menshealth.com", "avnetwork.com", "partyslate.com",
        "escholarship.org", "vividseats.com", "jogs.com", "etnow.com",
        "maybevents", "millersoundstudio"
    );

    // Music / audio-streaming platforms whose pages are pure content, never
    // buyer businesses for a product. Matched on the exact host or any of its
    // subdomains (e.g. "open.spotify.com").
    private static final Set<String> MEDIA_CONTENT_HOSTS = Set.of(
        "spotify.com", "soundcloud.com", "bandcamp.com", "mixcloud.com",
        "pandora.com", "deezer.com", "tidal.com"
    );

    private static final Set<String> DIRECTORY_TITLE_MARKERS = Set.of(
        "listings", "directory", "business listing", "company profile",
        "member profile", "wholesale directory", "supplier directory",
        "members directory", " forum", "supplier guide"
    );

    private static final Set<String> LOW_SIGNAL_DOMAIN_PARTS = Set.of(
        "com", "org", "net", "edu", "gov", "mil", "co", "uk", "de", "fr",
        "it", "es", "nl", "be", "ca", "au", "in", "us", "jp", "cn", "hk",
        "sg", "biz", "info", "io", "me", "tv", "app", "shop", "store", "web"
    );

    private static final Pattern PRICE_PATTERN = Pattern.compile(
            "(?i)(?:\\b(?:usd|inr|eur|gbp)\\s?\\d|[$\\u20AC\\u00A3\\u20B9]\\s?\\d|\\bprice\\s?[:$])");

    private static final String REJECT_NOT_BUYER = "REJECTED - not a buyer/business website";
    private static final String REJECT_SHOPPING = "REJECTED - shopping/product page";
    private static final String REJECT_ARTICLE = "REJECTED - article/blog";
    private static final String REJECT_GOV = "REJECTED - government site";
    private static final String REJECT_FILE = "REJECTED - file/document";
    private static final String REJECT_ACADEMIC = "REJECTED - academic/research page";

    // Exact rejection codes logged when a candidate fails one of the gates.
    // A result is rejected for: wrong product, wrong/conflicting location,
    // invalid content (article/PDF/directory/forum/event/unrelated website),
    // no genuine business identity, or an already-known website. Buyer intent
    // is NOT a rejection reason: a business that genuinely provides, sells,
    // uses, teaches or works with the product is accepted and classified as a
    // product-relevant business even when no importer/wholesaler/retailer/
    // buyer keyword is present.
    private static final String CODE_WRONG_PRODUCT = "WRONG PRODUCT";
    private static final String CODE_WRONG_LOCATION = "WRONG LOCATION";
    private static final String CODE_NO_BUYER_INTENT = "NO BUYER INTENT";
    private static final String CODE_INVALID_CONTENT = "INVALID CONTENT";
    private static final String CODE_NO_COMPANY_IDENTITY = "NO COMPANY IDENTITY";
    private static final String CODE_NO_PRODUCT_COMMERCE_EVIDENCE = "NO COMMERCIAL PRODUCT EVIDENCE";
    private static final String CODE_DUPLICATE = "DUPLICATE";
    private static final String CODE_ALREADY_IN_DATABASE = "ALREADY IN DATABASE";

    // Location-priority classes used for final selection/ranking. EXACT_CITY is
    // the highest priority, then SAME_STATE (same requested state, different
    // city), then SAME_COUNTRY (another US state / reliable-USA-but-unpinned) -
    // and the pipeline sorts accepted buyers so EXACT_CITY comes first and
    // SAME_COUNTRY is always selected only after all tighter matches. See the
    // locationClass field set in GATE 4 / the comparator in SEARCH COMPLETE.
    private static final String LOCATION_CLASS_EXACT_CITY = "EXACT_CITY";
    private static final String LOCATION_CLASS_SAME_STATE = "SAME_STATE";
    private static final String LOCATION_CLASS_SAME_COUNTRY = "SAME_COUNTRY";

    // Classification applied to an accepted business that shows product
    // relevance and a valid location/identity but no buyer-role keywords.
    private static final String PRODUCT_RELEVANT_CLASSIFICATION = "PRODUCT_RELEVANT_BUSINESS";

    // Default classification when neither the page NOR the website evidence
    // states an importer/distributor/wholesaler/retailer/supplier/dealer/buyer
    // role. A business is NEVER assigned a buyer role it does not evidence.
    private static final String CLASSIFICATION_OTHER = "OTHER";

    // Cheap-screen qualification marker: the candidate passed the URL/title/
    // snippet product screen and may proceed to FULL verification (homepage
    // fetch). It is NOT a buyer claim of any kind - commercial evidence,
    // business type and location are gated on the full page afterwards, and
    // only then does a candidate become a FINAL buyer.
    private static final String QUAL_PRODUCT_RELEVANT = "PRODUCT_RELEVANT";

    // Full-page product-match marker: the canonical/variant product phrase was
    // found in the CANDIDATE'S OWN listing (title/snippet/path/domain) but the
    // website text itself did not independently re-confirm it
    // (VERIFICATION_UNAVAILABLE). The commercial/business/location gates still
    // filter such a candidate - it is never a WRONG-PRODUCT auto-reject.
    private static final String QUAL_PRODUCT_LISTING = "PRODUCT_LISTING_RELEVANT";

    // Buyer-qualification tiers (full-page verify): what kind of product match
    // each accepted result is. These are prospect labels of the PRODUCT match,
    // never a business-type/classification claim:
    //  - DIRECT_PRODUCT_BUYER       the site demonstrably deals in the product
    //  - RELATED_CATEGORY_BUYER     a related-category store (meditation/spiritual/
    //                               wellness/metaphysical/gift/home-decor shop) that
    //                               plausibly carries the product, with store evidence
    //  - POTENTIAL_WHOLESALE_BUYER  accepted business carrying a wholesale signal
    //  - POTENTIAL_RETAIL_BUYER     accepted business carrying a retail/store signal
    //  - NOT_A_BUYER                rejected (never stored)
    private static final String QUAL_DIRECT_PRODUCT_BUYER = "DIRECT_PRODUCT_BUYER";
    private static final String QUAL_RELATED_CATEGORY_BUYER = "RELATED_CATEGORY_BUYER";
    private static final String QUAL_POTENTIAL_WHOLESALE_BUYER = "POTENTIAL_WHOLESALE_BUYER";
    private static final String QUAL_POTENTIAL_RETAIL_BUYER = "POTENTIAL_RETAIL_BUYER";
    private static final String QUAL_NOT_A_BUYER = "NOT_A_BUYER";

    // Valid business/buyer TYPE signals (requirement 4): words that express an
    // actual commercial business identity. They are honoured ONLY when they
    // appear in the CANDIDATE or WEBSITE evidence (title/snippet/URL/about/
    // contact/footer/homepage), NEVER in the fired search query. The cheap
    // screen uses phrase-level product relevance only; these words gate the
    // BUSINESS/BUYER TYPE on the full page.
    private static final String[] BUSINESS_TYPE_WORDS = {
        "retailer", "retailers", "wholesaler", "wholesalers", "distributor",
        "distributors", "importer", "importers", "dealer", "dealers",
        "supplier", "suppliers", "vendor", "vendors", "stockist", "stockists",
        "b2b", "procurement", "sourcing", "shop", "shops", "store", "stores",
        "storefront", "boutique", "estore", "booth", "marketplace", "wholesale",
        "retail", "bulk", "trading", "company", "companies", "enterprise",
        "enterprises", "corporation", "incorporated", "llc", "ltd", "inc"
    };
    // Multi-word business-type phrases checked with containsPhrase.
    private static final String[] BUSINESS_TYPE_PHRASES = {
        "retail store", "retail stores", "retail shop", "online store",
        "online shop", "gift shop", "trading company", "trading companies",
        "bulk supplier", "bulk buyer", "wholesale supplier", "wholesale store",
        "company store", "company shop"
    };

    // Words/markers of a SERVICE-only business: massage spas, therapy/
    // practitioner pages, classes, workshops, retreats, courses, training,
    // certification, booking/session/consultation pages and events. A page that
    // is only a service is rejected as a buyer EVEN when it names the product -
    // a therapy practice that USES singing bowls is not a business that buys
    // them. The same business that ALSO runs a store/shop/product catalogue IS
    // accepted (it buys stock), so this is only a reject when no commerce
    // evidence exists on the page.
    private static final String[] SERVICE_ONLY_MARKERS = {
            "massage", "spa", "therapy", "therapist", "therapists", "therapeutic",
            "practitioner", "practitioners", "healing session", "healing sessions",
            "sound bath", "sound baths", "sound healing session", "sound healing sessions",
            "meditation session", "meditation sessions", "meditation class", "yoga class",
            "yoga classes", "class", "classes", "workshop", "workshops", "retreat",
            "retreats", "course", "courses", "training", "certification", "certificate",
            "session", "sessions", "consultation", "appointment", "book a session",
            "book a class", "register for", "enroll", "enrol", "membership",
            "wellness studio", "meditation studio", "yoga studio", "healing studio",
            "ticket", "tickets", "register", "rsvp", "schedule a", "our hours"
    };

    // Words that show the page actually SELLS a physical product (a real store /
    // product catalogue / shop) rather than providing a service or being content.
    // Used to turn a product mention - DIRECT or a RELATED-CATEGORY store - into
    // a buyer lead, and to rescue a business that ALSO offers classes from the
    // service-only rejection.
    private static final String[] STORE_SELLING_MARKERS = {
            "our shop", "our store", "online store", "online shop", "shop now",
            "shop online", "shop our", "shop here", "our products", "our product",
            "our catalog", "our catalogue", "our collections", "our collection",
            "add to cart", "add to bag", "buy now", "for sale", "shopping cart",
            "checkout", "in stock", "back in stock", "product catalog",
            "product catalogue", "products", "collections", "catalog", "catalogue",
            "price", "prices", "order online", "wholesale", "wholesaler",
            "retailer", "retail", "shop", "store", "boutique", "estore",
            "storefront", "buy", "purchase", "ordering", "orders"
    };

    // Store-selling markers strong enough to count as commerce evidence on their
    // own (a single hit already proves selling intent).
    private static final String[] STRONG_STORE_SELLING_MARKERS = {
            "our shop", "our store", "online store", "online shop", "shop now",
            "shop online", "shop our", "our products", "our catalog",
            "our collections", "add to cart", "add to bag", "buy now",
            "shopping cart", "checkout", "in stock", "product catalog",
            "product catalogue", "estore", "storefront"
    };

    private static final Set<String> FILE_EXTENSIONS = Set.of(
        "pdf", "doc", "docx", "xls", "xlsx", "csv", "ppt", "pptx", "txt",
        "rtf", "zip", "rar", "7z", "gz", "tar", "jpg", "jpeg", "png", "gif",
        "webp", "tiff", "svg", "mp3", "mp4", "epub"
    );

    private static final Set<String> ACADEMIC_PATH_MARKERS = Set.of(
        "/research", "/papers", "/publications", "/journal", "/theses",
        "/dissertation", "/conference", "/proceedings"
    );

    private static final Set<String> ACADEMIC_TITLE_MARKERS = Set.of(
        "journal of", "research on", "research report", "working paper",
        "white paper", "whitepaper", "thesis", "dissertation", "proceedings",
        "academic", "scientific", "peer-reviewed", "conference paper",
        "preprint", "study of", "impact of"
    );

    // ------------------------------------------------------------------
    // Location (country/state/city) verification data. Buyers may be in the USA
    // OR Canada (all US states and Canadian provinces/territories). A decisive
    // location-conflict signal - a country other than USA/Canada (country words,
    // ", Country" address tails, "based in <country>" phrases, pvt ltd / private
    // limited suffixes, foreign phone prefixes, 6-digit PIN/postal codes or a
    // foreign ccTLD) or a region other than the requested one - rejects a
    // candidate as "REJECTED - wrong country/state/city" BEFORE any homepage
    // fetch, email scraping or save. A missing location never rejects: it is
    // saved as Unknown. The domain TLD is only ever one contributing signal,
    // never the sole evidence.
    // ------------------------------------------------------------------

    private static final Set<String> FOREIGN_COUNTRIES = Set.of(
        "india", "nepal", "united kingdom", "england", "scotland",
        "wales", "britain", "ireland", "australia", "new zealand", "germany",
        "france", "spain", "italy", "netherlands", "belgium", "switzerland",
        "austria", "sweden", "norway", "denmark", "finland", "poland",
        "czech republic", "romania", "hungary", "ukraine", "russia", "turkey",
        "greece", "portugal", "china", "japan", "south korea", "taiwan",
        "hong kong", "singapore", "malaysia", "indonesia", "thailand",
        "vietnam", "philippines", "pakistan", "bangladesh", "sri lanka",
        "dubai", "uae", "saudi arabia", "qatar", "oman", "kuwait", "israel",
        "kenya", "nigeria", "ghana", "south africa", "egypt", "mexico",
        "brazil", "argentina", "chile", "colombia", "peru"
    );

    // Country names strong enough that a bare mention means the business is
    // there (import-source mentions like "imports from India" are stripped
    // first). Ambiguous words like "china", "turkey" or "poland" are NOT here:
    // they are still caught by the ", Country" / "based in <country>" / phone /
    // PIN patterns below.
    private static final Set<String> DECISIVE_FOREIGN_WORDS = Set.of(
        "india", "nepal", "uk", "united kingdom", "england",
        "scotland", "wales", "britain", "ireland", "australia", "new zealand",
        "sri lanka", "singapore", "thailand", "vietnam", "philippines",
        "pakistan", "bangladesh", "dubai", "hong kong", "south africa",
        "kenya", "nigeria", "germany", "netherlands", "switzerland",
        "sweden", "norway", "denmark", "finland", "south korea", "uae",
        "united arab emirates"
    );

    private static final Set<String> FOREIGN_CCTLDS = Set.of(
        "uk", "in", "au", "de", "fr", "es", "it", "nl", "be", "ch",
        "at", "se", "no", "dk", "fi", "ie", "pt", "pl", "cz", "ro", "hu",
        "ru", "ua", "tr", "cn", "jp", "kr", "tw", "hk", "sg", "my", "th",
        "vn", "ph", "pk", "bd", "lk", "np", "ng", "za", "eg", "ae", "qa",
        "il", "br", "mx", "ar", "cl"
    );

    // Foreign nationality words that, when found in a business's hostname,
    // flag a company located abroad (e.g. czechchandeliers.com). A genuine
    // USA/Canada business almost always shows a "City, ST ZIP" / "City, ST" /
    // postal-style address on its page: when such an address is present, the
    // foreign-sounding hostname is trusted as a local brand, otherwise the
    // business is rejected as non-US. "british" and "indian" are deliberately
    // excluded: "British Columbia" and "Indiana/Indianapolis" businesses would
    // otherwise be falsely rejected.
    private static final Set<String> FOREIGN_HOST_WORDS = Set.of(
        "czech", "deutsch", "german", "french", "italian", "spanish",
        "swedish", "danish", "norwegian", "finnish", "polish", "portuguese",
        "dutch", "belgian", "austrian", "swiss", "hungarian", "romanian",
        "bulgarian", "croatian", "serbian", "turkish", "russian", "ukrainian",
        "greek", "scottish", "nepali", "australian"
    );

    private static final String FOREIGN_COUNTRY_ALTERNATION =
            FOREIGN_COUNTRIES.stream().map(Pattern::quote)
                    .collect(Collectors.joining("|"));

    // Canadian provinces and territories (lowercased full name -> 2-letter
    // abbreviation). Together with STATE_ABBREVIATIONS these form the accepted
    // USA + Canada location set; "CA"/"ON" style abbreviations are kept out of
    // the US maps so "California" and "Ontario" never collide.
    private static final Map<String, String> CANADIAN_PROVINCE_ABBREVIATIONS = Map.ofEntries(
        Map.entry("alberta", "AB"),
        Map.entry("british columbia", "BC"),
        Map.entry("manitoba", "MB"),
        Map.entry("new brunswick", "NB"),
        Map.entry("newfoundland and labrador", "NL"),
        Map.entry("nova scotia", "NS"),
        Map.entry("ontario", "ON"),
        Map.entry("prince edward island", "PE"),
        Map.entry("quebec", "QC"),
        Map.entry("saskatchewan", "SK"),
        Map.entry("northwest territories", "NT"),
        Map.entry("nunavut", "NU"),
        Map.entry("yukon", "YT")
    );

    private static final String[] CANADIAN_PROVINCE_NAMES = {
        "alberta", "british columbia", "manitoba", "new brunswick",
        "newfoundland and labrador", "nova scotia", "ontario",
        "prince edward island", "quebec", "saskatchewan",
        "northwest territories", "nunavut", "yukon"
    };

    // ------------------------------------------------------------------
    // Buyer-intent language: words/phrases that show the business itself buys
    // or sells the product as an importer / distributor / wholesaler /
    // retailer / dealer / buyer / sourcing company (or a trading/stockist
    // equivalent for the searched product). Matched as whole tokens, so
    // "singing bowls | Blue Gem Wholesale" proves intent while a bare product
    // title does not.
    // ------------------------------------------------------------------
    private static final Set<String> BUYER_INTENT_WORDS = Set.of(
        "importer", "importers", "import", "imports", "importing", "imported",
        "distributor", "distributors", "distribution", "distributing",
        "wholesaler", "wholesalers", "wholesale",
        "retailer", "retailers", "retail", "retailing",
        "dealer", "dealers", "dealership",
        "buyer", "buyers", "buy", "buying",
        "sourcing company", "sourcing agent", "sourcing",
        "stockist", "stockists", "buying house",
        "trading company", "trade company", "trader", "traders", "trading",
        "supplier", "suppliers", "supplying", "vendor", "vendors",
        "bulk supplier", "b2b"
    );

    // Trade-data / import-export record & analytics sites (OEC, Panjiva,
    // Volza, Trademap, ImportGenius, customs/shipment data portals). They are
    // data providers, never buyers - rejected as NO BUYER INTENT.
    private static final Set<String> TRADE_DATA_HOST_PARTS = Set.of(
        "oec", "panjiva", "volza", "trademap", "importgenius", "exportgenius",
        "comtrade", "indexmundi", "tradingeconomics", "customsdata",
        "shipmentdata", "importdata", "exportdata", "tradeanalytics",
        "onlyimportdata", "importinfo", "seair", "cybex", "exim", "tradedata",
        "go4worldbusiness", "eximpedia", "globaltradeplaza", "tradeford",
        "customsmobile", "importyeti", "tradewheel", "exportpages",
        "tradeindia", "globalsources"
    );
    private static final Set<String> TRADE_DATA_TITLE_MARKERS = Set.of(
        "import data", "export data", "trade data", "customs data",
        "import records", "export records", "shipment records",
        "trade statistics", "country of import", "import statistics",
        "export statistics", "trade value", "trade volume", "customs records",
        "buyers & importers", "buyers and importers", "importers & buyers",
        "importers and buyers", "buyers list", "buyer list",
        "buying agents", "buyers directory", "importers directory",
        "shipment details", "importer names", "market insights",
        "importers leads", "buyers leads", "b2b buyers", "leads data",
        "customs ruling", "customs rulings", "tariff classification",
        "tradebase", "importers database", "buyers database",
        "supplier database", "exporter database", "importers usa",
        "business database", "companies database"
    );

    // Words that carry no product meaning; a product like "Basmati Rice" is
    // reduced to its meaningful terms ["basmati", "rice"] for relevance checks.
    // Trade qualifiers ("wholesale", "importer", "bulk", ...) are dropped so a
    // product such as "Wholesale Singing Bowls" is matched on "singing bowls".
    private static final Set<String> STOPWORDS = Set.of(
        "a", "an", "the", "of", "for", "and", "or", "in", "on", "with",
        "by", "at", "from", "to", "usa", "us", "u", "s", "&", "-", "co",
        "ltd", "llc", "inc", "corp", "company", "products", "product",
        "wholesale", "wholesaler", "wholesalers", "retail", "retailer",
        "importer", "import", "importers", "exporter", "export", "exporters",
        "distributor", "distributors", "distribution", "supplier", "suppliers",
        "supply", "bulk", "buy", "buyer", "buyers", "trade", "trading",
        "vendor", "vendors", "dealer", "dealers", "stockist", "stockists",
        "buying", "house", "traders", "supplying"
    );

    // ------------------------------------------------------------------
    // Supported home-decor product category gate. A buyer search ONLY runs
    // for products in this category (singing/tibetan/crystal bowls, candles
    // & candle holders, lanterns & crystal lantern holders, decorative jars,
    // home decor). Anything else (cars, clothing, hotels, event supplies...)
    // is rejected BEFORE any Firecrawl request is fired, so credits are never
    // spent on an invalid product.
    // ------------------------------------------------------------------
    private static final String UNSUPPORTED_PRODUCT_MESSAGE =
            "Please search for a supported home decor product such as singing bowls, "
            + "candles, candle holders, lanterns, or decorative jars.";

    // Words that turn a plain "bowl(s)" into a supported singing/tibetan/
    // crystal bowl product; a bare "bowls" is ambiguous kitchen crockery and
    // is rejected so unrelated buyers are never returned to fill a quota.
    private static final Set<String> SUPPORTED_BOWL_QUALIFIERS = Set.of(
            "singing", "song", "tibetan", "crystal", "himalayan", "meditation",
            "sound", "buddhist", "zen", "chakra", "decorative", "decoration", "decor"
    );

    // Context words that make a "jar(s)" a DECORATIVE jar (home decor) rather
    // than a kitchen/canning storage jar. "storage"/"display" are accepted only
    // because kitchen words like "food" are rejected below by NON_HOME_DECOR_WORDS.
    private static final Set<String> DECORATIVE_JAR_CONTEXT = Set.of(
            "decorative", "decoration", "decor", "apothecary",
            "candy", "cookie", "ceramic", "mason", "amber", "vintage",
            "rustic", "farmhouse", "candle", "display", "storage"
    );

    // Query synonyms for the decorative-jar home-decor family. The user's own
    // phrasing is always tried first, then these related phrasings - all STILL
    // within the decorative/jar home-decor family, never unrelated products.
    // Each synonym is combined with the selected location and a business role
    // word (wholesaler, supplier, retailer, importer, distributor, ...) so the
    // 6-request budget explores diverse queries instead of repeating one
    // overly-specific phrase that returns zero results.
    private static final List<String> DECORATIVE_JAR_QUERY_SYNONYMS = List.of(
            "decorative jars",
            "glass jars",
            "apothecary jars",
            "decorative storage jars",
            "glass canisters",
            "decorative glass jars",
            "storage jars",
            "display jars",
            "jars with handles",
            "decorative jars with handles",
            "glass display jars",
            "home decor jars",
            "decorative canisters",
            "glass storage containers",
            "decorative storage containers",
            "decorative jar"
    );

    // ------------------------------------------------------------------
    // PRODUCT-FIRST query planning. Every buyer search builds its 6-request
    // window from the USER'S OWN product first, then MORE commercial synonym
    // phrases from the same home-decor family - each slot fires a DIFFERENT
    // product phrase so the budget never repeats one overly-specific exact
    // phrase that can return 0 results. Firecrawl queries always lead with a
    // product phrase from the user's own family and never cycle unrelated
    // catalogue products (lanterns/jars/... for a "Crystal Singing Bowls"
    // search).
    //   Slot 0 (selected city)   : the user's product + "for sale"
    //   Slot 1-4 (other cities)  : one DIFFERENT synonym per major city
    //   Slot 5 (state-wide)      : one more synonym for the fallback phase
    // The supported home-decor families, used to pick in-family synonym phrases
    // for the user's product. In priority order:
    //   1. Singing / wellness    4. Votive holders
    //   2. Lantern / lighting    5. Decorative jars
    //   3. Candle / candle holders 6. Handmade & home decor
    // ------------------------------------------------------------------
    // Product-family synonym phrases used for queries. Products are NEVER
    // broadened to generic wellness/meditation terms ("meditation bowls",
    // "healing sound therapy", "spiritual decor"...) because that surfaces
    // class, retreat and service pages, not buyers of the physical product.
    // Singing-bowl family terms stay STRONG singing-bowl phrases only.
    private static final List<List<String>> PRODUCT_FAMILY_TERMS = List.of(
        // Singing / wellness bowl family: commercially useful phrases only.
        // Overly narrow combinations ("buddhist singing bowls retailer",
        // "singing bowl wholesale supplier") are NOT used - they return poor
        // search-engine results and burn the whole 6-request budget.
        List.of("singing bowls", "tibetan singing bowls", "himalayan singing bowls",
                "crystal singing bowls", "meditation singing bowls", "sound healing bowls"),
        List.of("decorative lanterns", "metal lanterns", "moroccan lanterns",
                "glass lanterns", "hanging lanterns", "garden lanterns",
                "home decor lanterns"),
        List.of("candles", "candle holders", "candle stands",
                "crystal candle holders", "crystal votive holders",
                "crystal tealight holders", "tealight holders", "votive holders",
                "pillar candle holders", "decorative candle holders",
                "decorative candles", "handmade candles", "scented candles",
                "premium candles", "candle sets"),
        List.of("votive holders", "glass votive holders", "decorative votive holders"),
        List.of("decorative jars", "glass jars", "apothecary jars",
                "decorative storage jars", "glass canisters",
                "decorative glass jars", "storage jars", "display jars",
                "jars with handles", "decorative jars with handles",
                "glass display jars", "home decor jars", "decorative canisters",
                "glass storage containers", "decorative storage containers",
                "decorative jar"),
        List.of("handmade home decor", "handcrafted home decor", "home decor",
                "spiritual decor", "wellness decor", "meditation decor", "yoga decor",
                "gift and home decor", "artisan home decor")
    );

    // Related-category buyer profiles used for the two category-profile search
    // queries (slot 4-5 state-wide). Each product family gets TWO adjacent store
    // categories through which the physical product is genuinely sold - e.g. for
    // singing bowls: meditation/spiritual/wellness stores and metaphysical/
    // crystal/gift shops. The engine generates the equivalent category-profile
    // query for the searched product's family; nothing is hardcoded per product.
    // Index order matches PRODUCT_FAMILY_TERMS (bowls, lanterns, candles &
    // holders, votive, jars, home decor). A slot's phrasing stays PRODUCT +
    // BUYER PROFILE: `"<cat>"... store "<product>" <state>`.
    private static final List<List<String>> RELATED_CATEGORY_PROFILES = List.of(
        // Singing / wellness bowls: meditation & spiritual & wellness stores;
        // metaphysical & crystal & gift shops.
        List.of("meditation", "spiritual", "wellness"),
        List.of("metaphysical", "crystal", "gift"),
        // Lanterns / lighting: home-decor, lighting, garden stores.
        List.of("home decor", "lighting", "garden"),
        List.of("outdoor", "furniture", "gift"),
        // Candles & candle holders: home-decor, home-fragrance, gift stores.
        List.of("home decor", "home fragrance", "gift"),
        List.of("spiritual", "wellness", "boutique"),
        // Votive holders: home-decor, glassware, gift stores.
        List.of("home decor", "glassware", "gift"),
        List.of("candle", "spiritual", "boutique"),
        // Decorative jars: home-decor, glassware, kitchen/gift stores.
        List.of("home decor", "glassware", "kitchen"),
        List.of("gift", "storage", "boutique"),
        // Handmade / home decor: artisan & home-goods stores.
        List.of("handmade", "artisan", "home goods"),
        List.of("gift", "boutique", "decor")
    );

    // Buyer-type words cycled onto the product-first slots (one unique buyer
    // type per slot so the 6 requests never repeat the same role). Commerce
    // (product) buyer roles lead - importers, wholesalers, distributors,
    // retailers, suppliers. Broad "store" words like "home decor store",
    // "wellness store" or "yoga store" are gone: they widened the search to
    // businesses that never carry the specific physical product.
    private static final List<String[]> BUYER_WORDS = List.of(
        new String[]{"importer", "Importer"},
        new String[]{"wholesaler", "Wholesaler"},
        new String[]{"distributor", "Distributor"},
        new String[]{"retailer", "Retailer"},
        new String[]{"supplier", "Supplier"},
        new String[]{"wholesale buyer", "Wholesaler"},
        new String[]{"buyer", "Buyer"},
        new String[]{"specialty retailer", "Retailer"},
        new String[]{"boutique", "Retailer"},
        new String[]{"store", "Retailer"}
    );

    // ------------------------------------------------------------------
    // DYNAMIC PRODUCT QUERY GENERATION. Every search slot = ONE generated
    // PRODUCT-ONLY phrase (never a location) + an optional buyer word; the
    // location is added LATER by the phase planner. The generator is
    // category-aware and product-family-CONSISTENT: every variation is derived
    // from the user's OWN product (same OM Enterprises family) - lanterns /
    // jars / candles are NEVER mixed into a singing-bowl search, products are
    // never broadened to flashlights / industrial wax / canning jars / crystal
    // shops, and the query list is never padded with unrelated catalogue items.
    // ------------------------------------------------------------------

    // Words that make a generated phrase commercially oriented. A slot whose
    // phrase already contains one of these is fired WORDLESS so the built query
    // never doubles the role ("singing bowl supplier supplier").
    private static final Pattern ROLE_WORD_PATTERN = Pattern.compile(
        "\\b(wholesale|wholesaler|wholesalers|supplier|suppliers|distributor|distributors|"
            + "importer|importers|retailer|retailers|buyer|buyers|bulk|bulk buyer)\\b");

    // Generalized craft/quality/venue modifiers safe to combine with ANY
    // supported home-decor product - the building blocks of the generator for
    // products without a dedicated reference dictionary (e.g. "Wooden Wall
    // Decor", "Metal Home Decor").
    private static final String[] GENERIC_DECOR_MODIFIERS = {
        "handmade", "handcrafted", "artisan", "artisanal", "decorative",
        "luxury", "premium", "rustic", "modern"
    };

    // ---- Singing / wellness bowl family vocabulary ----
    private static final String[] BOWL_STYLE_MODIFIERS = {
        "crystal", "tibetan", "himalayan", "buddhist", "meditation", "spiritual",
        "yoga", "healing", "sound healing", "sound therapy", "chakra", "antique",
        "traditional", "artisan", "handcrafted", "handmade", "metal", "bronze", "brass"
    };
    private static final String[] BOWL_CORE_SYNONYMS = {
        "singing bowl", "buddhist singing bowl",
        "tibetan meditation bowl", "himalayan meditation bowl",
        "meditation sound bowl", "chakra healing bowl",
        "handmade tibetan bowl", "handmade himalayan bowl"
    };

    // ---- Candle holder / candle / votive / tealight family vocabulary ----
    private static final String[] CANDLE_HOLDER_STYLE_MODIFIERS = {
        "decorative", "handmade", "handcrafted", "crystal", "glass", "metal",
        "brass", "iron", "wooden", "ceramic", "votive", "tealight", "pillar",
        "hanging", "wall", "table", "home decor", "luxury", "artisan"
    };
    private static final String[] CANDLE_HOLDER_CLOSE_SYNONYMS = {
        "candle stand", "decorative candle stand", "candle holder set"
    };
    private static final String[] CANDLE_STYLE_PHRASES = {
        "decorative candles", "scented candles", "handmade candles", "luxury candles",
        "pillar candles", "votive candles", "soy candles", "home decor candles",
        "artisan candles", "handcrafted candles", "natural candles", "premium candles",
        "organic candles", "beeswax candles", "aromatherapy candles", "therapeutic candles",
        "container candles", "jar candles", "tealight candles",
        "candle sets", "decorative candle sets"
    };
    private static final String[] VOTIVE_HOLDER_STYLE_MODIFIERS = {
        "glass", "crystal", "decorative", "handmade", "handcrafted", "metal",
        "brass", "ceramic", "wooden", "tealight", "luxury", "artisan"
    };

    // ---- Lantern / lantern holder family vocabulary ----
    private static final String[] LANTERN_STYLE_MODIFIERS = {
        "decorative", "handmade", "handcrafted", "candle", "hanging", "metal",
        "brass", "iron", "glass", "moroccan", "indian", "artisan", "traditional",
        "garden", "table", "outdoor", "luxury"
    };
    private static final String[] LANTERN_HOLDER_STYLE_MODIFIERS = {
        "decorative", "candle", "hanging", "metal", "brass", "iron", "glass",
        "handmade", "handcrafted", "artisan", "wall", "garden", "outdoor"
    };

    // ---- Decorative jar family vocabulary (never kitchen/canning jars) ----
    private static final String[] JAR_STYLE_PHRASES = {
        "decorative home decor jars", "handmade decorative jars",
        "handcrafted decorative jars", "glass decorative jars",
        "decorative jars with handles", "decorative storage jars",
        "luxury decorative jars", "home decor accent jars",
        "decorative display jars", "glass display jars",
        "decorative glass jars", "artisan decorative jars",
        "decorative ceramic jars", "decorative metal jars",
        "vintage decorative jars", "rustic decorative jars",
        "farmhouse decorative jars", "decorative apothecary jars",
        "decorative jar sets", "decorative jars for home decor"
    };

    // Product category used to route dynamic query generation. Detection reuses
    // the exact helpers the home-decor category gate uses, so a query family is
    // always consistent with what the gate accepted.
    private enum QueryCategory { BOWL, CANDLE_HOLDER, CANDLE, VOTIVE_HOLDER, TEALIGHT, LANTERN, LANTERN_HOLDER, JAR, HOME_DECOR }

    // One PRODUCT-ONLY query candidate + the metadata the <=6-request planner
    // uses to keep the frozen Firecrawl budget diverse:
    //   band 0 - the user's exact phrasing (always first, never mixed products)
    //   band 1 - close synonyms + material/style/use-case/craft variations
    //   band 2 - wholesale / bulk commercial phrases
    //   band 3 - buyer/role phrases (supplier / wholesaler / distributor / importer)
    private static final class ProductQueryCandidate {
        final String query;
        final int band;
        final String product;
        final String queryKey;

        ProductQueryCandidate(String query, int band, String product, String queryKey) {
            this.query = query;
            this.band = band;
            this.product = product;
            this.queryKey = queryKey;
        }
    }

    /** Builds the <=6 PRODUCT-FOCUSED query slots for one search. Every slot's
     *  TERM is a PRODUCT-ONLY phrase produced by generateProductSearchQueries -
     *  location is never part of the product query; the phase planner adds the
     *  buyer word and the location. The dynamic generator keeps every variation
     *  inside the user's OWN product family (singing bowls for a "Singing Bowl"
     *  search, never lanterns/jars/candles) and the diversity planner picks the
     *  best slots so the frozen 6 requests are never burned on near-identical
     *  queries. Fewer than 6 slots is fine. */
    private List<String[]> buildProductFocusedSlots(List<String> products) {
        List<ProductQueryCandidate> generated = new ArrayList<>();
        Set<String> catalogueKeys = new HashSet<>();

        for (String product : products) {
            if (product == null || product.isBlank()) {
                continue;
            }
            List<ProductQueryCandidate> productQueries = generateProductSearchQueries(product);
            logger.info("PRODUCT QUERIES GENERATED for '{}' ({} candidate(s)):",
                    product, productQueries.size());
            for (int i = 0; i < productQueries.size(); i++) {
                ProductQueryCandidate cq = productQueries.get(i);
                logger.info("  Candidate {}. [band {}] '{}'",
                        i + 1, cq.band, cq.query);
                if (cq.queryKey != null && catalogueKeys.add(cq.queryKey)) {
                    generated.add(cq);
                }
            }
        }

        List<ProductQueryCandidate> selected = selectDiverseQueries(generated, MAX_FIRECRAWL_REQUESTS_PER_SEARCH);
        logger.info("SELECTED FIRECRAWL QUERY SLOTS (max {} per search):",
                MAX_FIRECRAWL_REQUESTS_PER_SEARCH);
        List<String[]> slots = new ArrayList<>();
        for (int i = 0; i < selected.size(); i++) {
            ProductQueryCandidate cq = selected.get(i);
            logger.info("  Slot {}. '{}' (product variation only - buyer word & location are added by the phase planner)",
                    i + 1, cq.query);
            // A phrase that already carries a commercial role/wholesale word is
            // fired wordless so the full query never reads "... supplier supplier".
            String[] buyer = hasCommerceTerm(cq.query) ? null : buyerWordForTerm(cq.query, i);
            slots.add(new String[]{
                    cq.query,
                    buyer == null ? "" : buyer[0],
                    buyer == null ? "" : buyer[1]});
        }
        return slots;
    }

    /** Generates the PRODUCT-ONLY query candidates for ONE user product. The
     *  user's exact phrasing is always candidate 1 (band 0); every further
     *  candidate is derived from the same physical product family - synonyms,
     *  material/style/use-case/craft variations (band 1), wholesale/bulk
     *  commercial phrasings (band 2) and buyer/role phrasings (band 3).
     *  No candidate ever contains a location. Output is deduplicated on a
     *  singular key so "Singing Bowls" and "singing bowl" don't burn two
     *  slots in the 6-request budget. */
    private List<ProductQueryCandidate> generateProductSearchQueries(String product) {
        List<ProductQueryCandidate> generated = new ArrayList<>();
        Set<String> seenSingular = new HashSet<>();
        String given = collapseWhitespace(product);
        String normalized = normalizeProductForValidation(product);
        if (given == null || normalized.isEmpty()) {
            return generated;
        }
        addGeneratedKeyword(generated, seenSingular, given, 0, product);
        Set<String> words = new HashSet<>(tokenizeWords(normalized));
        QueryCategory category = detectQueryCategory(normalized, words);
        switch (category) {
            case BOWL:
                generateBowlQueries(generated, seenSingular, product, normalized);
                break;
            case CANDLE_HOLDER:
                generateCandleHolderQueries(generated, seenSingular, product, normalized);
                break;
            case CANDLE:
                generateCandleQueries(generated, seenSingular, product, normalized);
                break;
            case VOTIVE_HOLDER:
                generateVotiveHolderQueries(generated, seenSingular, product, normalized);
                break;
            case TEALIGHT:
                generateTealightQueries(generated, seenSingular, product, normalized);
                break;
            case LANTERN:
                generateLanternQueries(false, generated, seenSingular, product, normalized);
                break;
            case LANTERN_HOLDER:
                generateLanternQueries(true, generated, seenSingular, product, normalized);
                break;
            case JAR:
                generateJarQueries(generated, seenSingular, product, normalized);
                break;
            default:
                generateGenericDecorQueries(generated, seenSingular, product, normalized);
                break;
        }
        return generated;
    }

    /** Routes the user's product to the same family the home-decor category
     *  gate accepted, so the generated queries always match what was approved.
     *  Any product the gate lets through but the generator has no dictionary
     *  for falls to the generic home-decor generator. */
    private QueryCategory detectQueryCategory(String norm, Set<String> words) {
        if (isBowlFamilyProduct(norm, words) || isSoundHealingProduct(norm)) {
            return QueryCategory.BOWL;
        }
        if (isLanternProduct(norm)) {
            return norm.contains("holder") ? QueryCategory.LANTERN_HOLDER : QueryCategory.LANTERN;
        }
        if (words.contains("votive") || words.contains("votives")) {
            return QueryCategory.VOTIVE_HOLDER;
        }
        if (words.contains("tealight") || words.contains("tealights")
                || norm.contains("tea light") || norm.contains("tea lights")) {
            return QueryCategory.TEALIGHT;
        }
        if (isCandleProduct(norm, words)) {
            if (norm.contains("holder") || norm.contains("stand") || words.contains("holders")) {
                return QueryCategory.CANDLE_HOLDER;
            }
            return QueryCategory.CANDLE;
        }
        if (isDecorativeJarProduct(words)) {
            return QueryCategory.JAR;
        }
        return QueryCategory.HOME_DECOR;
    }

    /** Adds one generated keyword unless a singular variant of it is already
     *  present. The key recorded on the candidate is the normalized full key
     *  (used for the cross-product catalog dedup); the seen set is keyed on
     *  the singular form so plural/singular spelling variants collapse. */
    private void addGeneratedKeyword(List<ProductQueryCandidate> out, Set<String> seenSingular,
                                     String query, int band, String product) {
        String q = collapseWhitespace(query);
        if (q == null || q.isEmpty()) {
            return;
        }
        String key = normalizeProductQueryKey(q);
        String singular = singularQueryKey(key);
        if (singular == null || !seenSingular.add(singular)) {
            return;
        }
        out.add(new ProductQueryCandidate(q, band, product, key));
    }

    private String normalizeProductQueryKey(String query) {
        String normalized = normalizeProductForValidation(query);
        return collapseWhitespace(normalized.replaceAll("[^a-z0-9]+", " "));
    }

    /** Collapses a normalized query key to its singular form for dedup:
     *  "holders" -> "holder", "jars" -> "jar", but "glass" and "vases" are
     *  left alone so unrelated words never collide. */
    private static String singularQueryKey(String key) {
        if (key == null || key.isEmpty()) {
            return key;
        }
        String k = key.trim();
        if (k.endsWith("ies")) {
            return k.substring(0, k.length() - 3) + "y";
        }
        if (k.endsWith("ss") || k.endsWith("ses")) {
            return k;
        }
        if (k.endsWith("s")) {
            return k.substring(0, k.length() - 1);
        }
        return k;
    }

    private boolean hasCommerceTerm(String term) {
        if (term == null || term.isBlank()) {
            return false;
        }
        return ROLE_WORD_PATTERN.matcher(term.toLowerCase(Locale.ROOT)).find();
    }

    private boolean containsWholeWord(String text, String word) {
        if (text == null || word == null || word.isBlank()) {
            return false;
        }
        return (" " + text.trim().toLowerCase(Locale.ROOT) + " ")
                .contains(" " + word.trim().toLowerCase(Locale.ROOT) + " ");
    }

    /** The buyer word for one slot, cycling through BUYER_WORDS from that
     *  slot's index and skipping any keyword already inside the product phrase
     *  (a "crystal candle holder" slot never gets "buyer", "wholesaler",
     *  "importer", ... that would read "... supplier supplier"). */
    private String[] buyerWordForTerm(String term, int slotIndex) {
        int start = slotIndex % BUYER_WORDS.size();
        for (int i = 0; i < BUYER_WORDS.size(); i++) {
            String[] candidate = BUYER_WORDS.get((start + i) % BUYER_WORDS.size());
            if (!containsWholeWord(term, candidate[0])) {
                return candidate;
            }
        }
        return BUYER_WORDS.get(start);
    }

    /** Picks up to max diverse candidates from the generated pool within the
     *  frozen Firecrawl budget. Pass 1 always takes each product's EXACT
     *  phrasing (band 0, one per product, in input order). Pass 2 then walks
     *  the remaining candidates left-to-right alternating a close variant
     *  (band 1) with a commercial wholesale/role phrase (band 2/3) so the 6
     *  requests explore distinct commercial angles instead of 6 near-identical
     *  keywords. */
    private List<ProductQueryCandidate> selectDiverseQueries(
            List<ProductQueryCandidate> generated, int max) {
        List<ProductQueryCandidate> chosen = new ArrayList<>();
        if (generated.isEmpty()) {
            return chosen;
        }
        Set<String> presentedProducts = new HashSet<>();
        for (ProductQueryCandidate c : generated) {
            if (chosen.size() >= max) {
                break;
            }
            if (c.band == 0 && presentedProducts.add(c.product)) {
                chosen.add(c);
            }
        }
        boolean pickCommercial = false;
        for (ProductQueryCandidate c : generated) {
            if (chosen.size() >= max) {
                break;
            }
            if (chosen.contains(c)) {
                continue;
            }
            if (c.band == 1) {
                if (!pickCommercial) {
                    chosen.add(c);
                }
                pickCommercial = !pickCommercial;
            } else if (c.band == 2 || c.band == 3) {
                if (pickCommercial) {
                    chosen.add(c);
                }
                pickCommercial = !pickCommercial;
            }
        }
        return chosen;
    }

    /** Adds the commercial angle phrases (band 2) for a canonical base noun. */
    private void addBulkQueries(List<ProductQueryCandidate> out, Set<String> seenSingular,
                                String product, String baseNoun) {
        addGeneratedKeyword(out, seenSingular, baseNoun + " wholesale", 2, product);
        addGeneratedKeyword(out, seenSingular, baseNoun + " bulk", 2, product);
    }

    /** Adds the buyer/role phrases (band 3) for a canonical base noun. */
    private void addRoleQueries(List<ProductQueryCandidate> out, Set<String> seenSingular,
                                String product, String baseNoun) {
        for (String role : new String[]{"supplier", "wholesaler", "distributor", "importer"}) {
            addGeneratedKeyword(out, seenSingular, baseNoun + " " + role, 3, product);
        }
    }

    private void generateBowlQueries(List<ProductQueryCandidate> out, Set<String> seenSingular,
                                     String product, String normalized) {
        String core = "singing bowl";
        for (String mod : BOWL_STYLE_MODIFIERS) {
            if (containsWholeWord(normalized, mod)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, mod + " " + core, 1, product);
        }
        for (String syn : BOWL_CORE_SYNONYMS) {
            if (containsPhrase(normalized, syn)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, syn, 1, product);
        }
        addBulkQueries(out, seenSingular, product, core);
        addRoleQueries(out, seenSingular, product, core);
    }

    private void generateCandleHolderQueries(List<ProductQueryCandidate> out,
                                             Set<String> seenSingular,
                                             String product, String normalized) {
        boolean crystal = containsWholeWord(normalized, "crystal");
        String core = "candle holder";
        for (String mod : CANDLE_HOLDER_STYLE_MODIFIERS) {
            if (containsWholeWord(normalized, mod)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, mod + " " + core, 1, product);
        }
        if (crystal) {
            addGeneratedKeyword(out, seenSingular, "crystal tealight holder", 1, product);
            addGeneratedKeyword(out, seenSingular, "crystal votive holder", 1, product);
            addGeneratedKeyword(out, seenSingular, "crystal candle stand", 1, product);
            addGeneratedKeyword(out, seenSingular, "crystal candle set", 1, product);
            addGeneratedKeyword(out, seenSingular, "gemstone candle holder", 1, product);
            addGeneratedKeyword(out, seenSingular, "natural crystal candle holder", 1, product);
        } else {
            for (String syn : CANDLE_HOLDER_CLOSE_SYNONYMS) {
                if (containsPhrase(normalized, syn)) {
                    continue;
                }
                addGeneratedKeyword(out, seenSingular, syn, 1, product);
            }
        }
        addBulkQueries(out, seenSingular, product, core);
        addRoleQueries(out, seenSingular, product, core);
    }

    private void generateCandleQueries(List<ProductQueryCandidate> out,
                                       Set<String> seenSingular,
                                       String product, String normalized) {
        for (String phrase : CANDLE_STYLE_PHRASES) {
            if (containsPhrase(normalized, phrase)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, phrase, 1, product);
        }
        addBulkQueries(out, seenSingular, product, "candles");
        addRoleQueries(out, seenSingular, product, "candle");
    }

    private void generateVotiveHolderQueries(List<ProductQueryCandidate> out,
                                             Set<String> seenSingular,
                                             String product, String normalized) {
        String core = "votive holder";
        for (String mod : VOTIVE_HOLDER_STYLE_MODIFIERS) {
            if (containsWholeWord(normalized, mod)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, mod + " " + core, 1, product);
        }
        addBulkQueries(out, seenSingular, product, core);
        addRoleQueries(out, seenSingular, product, core);
    }

    private void generateTealightQueries(List<ProductQueryCandidate> out,
                                         Set<String> seenSingular,
                                         String product, String normalized) {
        String core = "tealight holder";
        String[] mods = {"decorative", "glass", "crystal", "metal", "brass",
                "handmade", "handcrafted", "ceramic", "wooden", "luxury"};
        for (String mod : mods) {
            if (containsWholeWord(normalized, mod)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, mod + " " + core, 1, product);
        }
        addGeneratedKeyword(out, seenSingular, "tealight candles", 1, product);
        addGeneratedKeyword(out, seenSingular, "tea light candles", 1, product);
        addBulkQueries(out, seenSingular, product, core);
        addRoleQueries(out, seenSingular, product, "tealight");
    }

    private void generateLanternQueries(boolean holder, List<ProductQueryCandidate> out,
                                        Set<String> seenSingular,
                                        String product, String normalized) {
        String[] mods = holder ? LANTERN_HOLDER_STYLE_MODIFIERS : LANTERN_STYLE_MODIFIERS;
        String core = holder ? "lantern holder" : "lantern";
        for (String mod : mods) {
            if (containsWholeWord(normalized, mod)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, mod + " " + core, 1, product);
        }
        addBulkQueries(out, seenSingular, product, core);
        addRoleQueries(out, seenSingular, product, core);
    }

    private void generateJarQueries(List<ProductQueryCandidate> out, Set<String> seenSingular,
                                    String product, String normalized) {
        for (String phrase : JAR_STYLE_PHRASES) {
            if (containsPhrase(normalized, phrase)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, phrase, 1, product);
        }
        addBulkQueries(out, seenSingular, product, "decorative jar");
        addRoleQueries(out, seenSingular, product, "decorative jar");
    }

    /** Generic home-decor generator for products without a dedicated reference
     *  dictionary (e.g. "Wooden Wall Decor", "Metal Home Decor"): craft/quality
     *  modifiers on the user's own product, "for home decor" framing and the
     *  literal wall-decor -> wall-art synonym. Wholesale/role phrases are not
     *  bolted on here because the generic terms are already decorated, rarely
     *  unique, and commercial doubling adds noise. */
    private void generateGenericDecorQueries(List<ProductQueryCandidate> out,
                                             Set<String> seenSingular,
                                             String product, String normalized) {
        for (String mod : GENERIC_DECOR_MODIFIERS) {
            if (containsWholeWord(normalized, mod)) {
                continue;
            }
            addGeneratedKeyword(out, seenSingular, mod + " " + product, 1, product);
        }
        addGeneratedKeyword(out, seenSingular, product + " for home decor", 1, product);
        String swapped = normalized.replace(" wall decor", " wall art");
        if (!swapped.equals(normalized)) {
            addGeneratedKeyword(out, seenSingular, swapped, 1, product);
            addGeneratedKeyword(out, seenSingular, "handmade " + swapped, 1, product);
        }
        addGeneratedKeyword(out, seenSingular, normalized + " home decor", 1, product);
    }

    /** The in-family synonym phrases of the user's product: the family it
     *  belongs to (bowls / lanterns / candles / jars / home decor), chosen with
     *  the same detection used by the home-decor category gate. */
    private List<String> relatedFamilyTerms(String product) {
        String p = normalizeProductForValidation(product);
        Set<String> words = new HashSet<>(tokenizeWords(p));
        if (isBowlFamilyProduct(p, words) || isSoundHealingProduct(p)) {
            // Singing-bowl phrases are identity-preserving (tibetan / himalayan
            // / crystal / meditation / sound-healing singing bowls all stay
            // "singing bowls"), so the family terms are valid discovery variants.
            return PRODUCT_FAMILY_TERMS.get(0);
        }
        if (isLanternProduct(p)) {
            Set<String> required = requiredAttributesOf(p, words, 1);
            if (required.contains("wall")) {
                // A "wall lantern" search only fires attribute-preserving variants
                // ("outdoor wall lantern", "wall mounted lantern", ...) - never
                // the bare metal/glass/moroccan/hanging lantern category, which
                // is a DIFFERENT product (requirement 6).
                return attributePreservingVariants(p, 1, required);
            }
            return PRODUCT_FAMILY_TERMS.get(1);
        }
        if (isCandleProduct(p, words)) {
            boolean holderProduct = words.contains("holder") || words.contains("holders")
                    || words.contains("stand") || words.contains("stands");
            if (holderProduct && requiredAttributesOf(p, words, 2).contains("crystal")) {
                // Crystal candle holders: only crystal-preserving holder phrases
                // are fired; the generic candle-holder family is NOT a variant.
                return STRONG_CRYSTAL_CANDLE_HOLDER_PHRASES;
            }
            return PRODUCT_FAMILY_TERMS.get(2);
        }
        if (isDecorativeJarProduct(words)) {
            return PRODUCT_FAMILY_TERMS.get(4);
        }
        if (isHomeDecorProduct(p, words)) {
            return PRODUCT_FAMILY_TERMS.get(5);
        }
        return List.of();
    }

    /** The home-decor family index (0=bowls, 1=lanterns, 2=candles/holders,
     *  4=jars, 5=home decor, 3=votive reserved) of the product, or -1 when it
     *  belongs to no supported family. Drives the per-family RELATED-CATEGORY
     *  buyer-profile queries (RELATED_CATEGORY_PROFILES). */
    private int familyIndexFor(String product) {
        String p = normalizeProductForValidation(product);
        Set<String> words = new HashSet<>(tokenizeWords(p));
        if (isBowlFamilyProduct(p, words) || isSoundHealingProduct(p)) {
            return 0;
        }
        if (isLanternProduct(p)) {
            return 1;
        }
        if (isCandleProduct(p, words)) {
            return 2;
        }
        if (isDecorativeJarProduct(words)) {
            return 4;
        }
        if (isHomeDecorProduct(p, words)) {
            return 5;
        }
        return -1;
    }

    /** The two RELATED-CATEGORY buyer profiles of the product's family (A, B);
     *  a generic gift/home-goods pair is returned when the product has no
     *  supported family so the slot still searches real retailers. */
    private List<List<String>> categoryProfilesFor(String product) {
        int familyIdx = familyIndexFor(product);
        if (familyIdx < 0) {
            return List.of(
                    List.of("gift", "boutique", "home goods"),
                    List.of("handmade", "artisan", "decor"));
        }
        return List.of(
                RELATED_CATEGORY_PROFILES.get(familyIdx * 2),
                RELATED_CATEGORY_PROFILES.get(familyIdx * 2 + 1));
    }

    /** The ordered, commercially useful product phrases fired for one user
     *  product: the USER'S OWN phrasing first, then the next in-family
     *  synonyms (e.g. for "Singing Bowls": "Tibetan Singing Bowls", "Himalayan
     *  Singing Bowls", "Crystal Singing Bowls", "Meditation Bowls" and "Sound
     *  Healing Bowls"). Only whole meaningful product phrases are used - never
     *  loose tokens ("singing", "bowl") and never generic home-decor
     *  replacements. The query planner (buildProductPlan) cycles its 6 slots
     *  through this list - the user's exact phrasing first, then the in-family
     *  synonyms - so every slot fires a DIFFERENT product variant, no slot
     *  repeats the user's overly-specific exact phrasing (which can return 0
     *  results) and no query stuffs all synonyms together. */
    private List<String> commercialProductPhrases(String product) {
        List<String> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (product != null && !product.isBlank()) {
            String key = product.trim().toLowerCase(Locale.ROOT);
            if (seen.add(key)) {
                out.add(product.trim());
            }
        }
        List<String> family = relatedFamilyTerms(product);
        for (String phrase : family) {
            String key = phrase.trim().toLowerCase(Locale.ROOT);
            if (seen.add(key)) {
                out.add(phrase.trim());
            }
        }
        return out;
    }

    // Buyer-role vocabulary: the natural search word and the business-type
    // label saved when the role is confirmed by the page's OWN evidence. The
    // nine buyer-intent types (importer, distributor, wholesaler, retailer,
    // dealer, buyer, sourcing, supplier, bulk) all appear across per-product
    // plans: the four core commerce-resell roles always lead, and two more
    // rotate in from the extra pool so no single search repeats a buyer type.
    private static final String[][] BUYER_ROLE_INVENTORY = {
        {"retailer",    "Retailer"},
        {"wholesaler",  "Wholesaler"},
        {"distributor", "Distributor"},
        {"importer",    "Importer"},
        {"dealer",      "Dealer"},
        {"buyer",       "Buyer"},
        {"supplier",    "Supplier"},
        {"sourcing",    "Sourcing Company"},
        {"bulk",        "Bulk Buyer"}
    };

    // Every product plan always leads with these four commerce-resell roles -
    // genuine stock-buying businesses. Their order defines slot priority:
    // retailer + wholesaler for the selected-city slots, then distributor +
    // importer for the B2B state-wide slots.
    private static final String[] CORE_BUYER_ROLES =
            {"retailer", "wholesaler", "distributor", "importer"};

    // Rotating pools: each product plan adds two different roles for the last
    // two state-wide slots. Slot 5 cycles through supplier/bulk and slot 6
    // through dealer/buyer/sourcing so the six strategies keep a breadth of
    // stock-buying intent (and per-product cycle -> different products mix the
    // roles differently). This avoids the duplicate-heavy repeat of the core
    // four roles.
    private static final String[] SUPPLIER_BUYER_ROLES = {"supplier", "bulk"};
    private static final String[] DEALER_BUYER_ROLES = {"dealer", "buyer", "sourcing"};

    /**
     * The deterministic 6-slot plan for ONE product. Every slot pairs a
     * DIFFERENT in-family product variant with a DIFFERENT buyer-role word, so
     * the six requests fire six unique product+intent queries:
     *   Slot 0 : exact product  + retailer
     *   Slot 1 : variant       + wholesaler
     *   Slot 2 : variant       + distributor
     *   Slot 3 : variant       + importer
     *   Slot 4 : variant       + supplier/bulk
     *   Slot 5 : variant       + dealer/buyer/sourcing
     * Phrases cycle through the variant list when the family has fewer than six
     * terms; each slot's distinct role word still keeps every full query unique.
     */
    private List<Slot> buildProductPlan(String prod) {
        return buildProductPlan(prod, MAX_FIRECRAWL_REQUESTS_PER_SEARCH);
    }

    /**
     * Deterministic product-buyer-role plan for one product: {@code slotCount}
     * slots, each pairing a DIFFERENT in-family product variant with a DIFFERENT
     * buyer-role word. City searches request more slots than the default so the
     * requested city keeps 4 rounds and up to 5 same-state fallback cities each
     * receive their own request; state/nationwide searches keep 6.
     */
    private List<Slot> buildProductPlan(String prod, int slotCount) {
        List<String> phrases = commercialProductPhrases(prod);
        if (phrases.isEmpty()) {
            phrases = new ArrayList<>(Collections.singletonList(prod));
        }
        List<String> slotPhrases = new ArrayList<>();
        // One slot occupies the user's own phrasing, the rest fire DISTINCT
        // in-family variants. The variant list carries plural defensive forms
        // ("wall lanterns" next to "wall lantern"), which a search engine would
        // collapse anyway; deduping by singular stem keeps slots for genuinely
        // DIFFERENT variants (e.g. a "Wall Lantern" search fires wall/mounted/
        // outdoor/exterior/decorative/LED - never a wasted plural repeat).
        Set<String> stems = new HashSet<>();
        for (String phrase : phrases) {
            String stem = singularStemOf(phrase);
            if (!stems.add(stem)) {
                continue;
            }
            slotPhrases.add(phrase);
            if (slotPhrases.size() == slotCount) {
                break;
            }
        }
        // A family with fewer than slotCount distinct stems still fills every
        // slot by cycling (each slot keeps a different buyer-role word, so the
        // queries stay unique).
        for (int i = slotPhrases.size(); i < slotCount; i++) {
            slotPhrases.add(phrases.get(i % phrases.size()));
        }

        String[] roles = new String[slotCount];
        roles[0] = CORE_BUYER_ROLES[0];
        roles[1] = CORE_BUYER_ROLES[1];
        roles[2] = CORE_BUYER_ROLES[2];
        roles[3] = CORE_BUYER_ROLES[3];
        int start = Math.floorMod(prod.toLowerCase(Locale.ROOT).hashCode(),
                SUPPLIER_BUYER_ROLES.length);
        for (int i = 4; i < slotCount; i++) {
            int pair = (i - 4) / 2;
            roles[i] = ((i - 4) % 2 == 0)
                    ? SUPPLIER_BUYER_ROLES[(start + pair) % SUPPLIER_BUYER_ROLES.length]
                    : DEALER_BUYER_ROLES[(start + pair) % DEALER_BUYER_ROLES.length];
        }

        List<Slot> slots = new ArrayList<>();
        for (int i = 0; i < slotCount; i++) {
            String word = null;
            String type = null;
            for (String[] inv : BUYER_ROLE_INVENTORY) {
                if (inv[0].equals(roles[i])) {
                    word = inv[0];
                    type = inv[1];
                    break;
                }
            }
            slots.add(new Slot(slotPhrases.get(i), word, type, null));
        }
        return slots;
    }

    // Returns the singular stem of a phrase ("wall lanterns" -> "wall lantern")
    // so plural defensive forms never count as DISTINCT variants when the slot
    // plan is filled (buildProductPlan). Conservative: "glass", "is" and other
    // words genuinely ending in "ss"/short "s" are left untouched.
    private String singularStemOf(String phrase) {
        String trimmed = collapseWhitespace(phrase).trim();
        if (trimmed.length() > 4 && trimmed.endsWith("s") && !trimmed.endsWith("ss")) {
            return trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed;
    }

    private String keyOf(String phrase) {
        return phrase == null || phrase.isBlank()
                ? null : collapseWhitespace(phrase).toLowerCase(Locale.ROOT);
    }

    // Sound-healing / meditation-therapy phrases in the supported wellness &
    // home-decor category. Only these explicit phrases are accepted - a bare
    // "yoga", "meditation" or "healing" stays out so yoga classes/mats or
    // generic therapy clinics are never pulled in.
    private static final String[] SOUND_HEALING_TERMS = {
            "sound healing", "sound therapy", "healing sound",
            "yoga meditation", "sound healing therapy"
    };

    // Event / non-home venues that are never home decor even when a decor or
    // candle/lantern word appears in the product (party/wedding supplies).
    private static final Set<String> EVENT_NON_DECOR_WORDS = Set.of(
            "party", "event", "wedding", "banquet", "celebration", "occasion",
            "festival", "birthday"
    );

    // Product words that point outside the home-decor category even when a
    // decor word is present (car decor, cake decorations, clothing, hotels...).
    private static final Set<String> NON_HOME_DECOR_WORDS = Set.of(
            "car", "auto", "automobile", "vehicle", "jeep", "motorcycle",
            "truck", "boat", "rv",
            "cake", "cupcake", "baking", "bakery",
            "clothing", "clothes", "apparel", "garment", "garments", "jeans",
            "pants", "shirt", "dress", "shoe", "shoes",
            "hotel", "motel", "inn", "resort", "restaurant", "pizza", "food",
            "snack", "nail", "eyelash", "eyelashes", "lash", "lashes", "hair",
            "makeup", "cosmetic", "cosmetics", "beauty"
    );

    // Home-decor family words that carry no "decor" substring; plain "decor",
    // "decorative", "decoration", "décor" (normalized to "decor") and every
    // "home decor"/"wall decor" style phrase are matched by containment below.
    private static final String[] HOME_DECOR_PHRASES = {
            "home accessory", "home accessories", "home accent", "home accents",
            "home goods", "home furnishing", "home furnishings",
            "houseware", "housewares", "homeware", "homewares",
            "housewarming gift", "housewarming gifts",
            "festive lighting", "festive lights"
    };

    private static final Map<String, String> STATE_ABBREVIATIONS = buildStateAbbreviations();

    private static final String[] US_STATE_NAMES = {
        "alabama", "alaska", "arizona", "arkansas", "california", "colorado",
        "connecticut", "delaware", "florida", "georgia", "hawaii", "idaho",
        "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana",
        "maine", "maryland", "massachusetts", "michigan", "minnesota",
        "mississippi", "missouri", "montana", "nebraska", "nevada",
        "new hampshire", "new jersey", "new mexico", "new york",
        "north carolina", "north dakota", "ohio", "oklahoma", "oregon",
        "pennsylvania", "rhode island", "south carolina", "south dakota",
        "tennessee", "texas", "utah", "vermont", "virginia",
        "washington", "west virginia", "wisconsin", "wyoming",
        "district of columbia"
    };

    // ------------------------------------------------------------------
    // Individual business-location extraction. Used when the searched region is
    // too broad to be a useful per-buyer location (USA-wide / state-wide search)
    // or the searched city could not be confirmed: the buyer's REAL location is
    // pulled from the actual evidence, not guessed. Sources, best first:
    //   Google Business address in the search result -> search title/snippet ->
    //   schema.org structured data -> homepage footer -> homepage body ->
    //   contact page -> about page. Contact/about pages are fetched with plain
    //   HTTP (website scraping, NOT Firecrawl) so the 6-request search budget is
    //   never touched. A location is only saved when the website / search result
    //   actually contains it; otherwise it is recorded as Unknown (or the bare
    //   country when the country alone is positively known).
    // ------------------------------------------------------------------

    // Contact/About page paths tried (contact and about interleaved first)
    // only when the search result + homepage did not already reveal the buyer's
    // city/state. At most MAX_LOCATION_PAGE_FETCHES pages are fetched per buyer.
    private static final String[] LOCATION_PAGE_PATHS = {
        "/contact", "/about", "/contact-us", "/about-us", "/contactus",
        "/aboutus", "/pages/contact", "/pages/about", "/pages/contact-us",
        "/pages/about-us", "/get-in-touch", "/contact.html", "/about.html"
    };
    private static final int MAX_LOCATION_PAGE_FETCHES = 3;

    // "City ST ZIP" / "City, ST 12345" (comma optional) - the state MUST be a
    // real US state / Canadian province abbreviation, checked against the maps.
    private static final Pattern CITY_STATE_ZIP_PATTERN = Pattern.compile(
            "(?<![A-Za-z0-9])([A-Za-z][A-Za-z .'\\-]{0,60}?)\\s*,?\\s+([A-Za-z]{2})\\s+\\d{5}(?:-\\d{4})?(?![A-Za-z0-9])");
    // "City, ST" without a ZIP - requires the comma so a bare
    // "Visit Dallas CA" / "Shipping Texas" cannot become a fake city match.
    private static final Pattern CITY_STATE_PATTERN = Pattern.compile(
            "(?<![A-Za-z0-9])([A-Za-z][A-Za-z .'\\-]{0,60}?)\\s*,\\s*([A-Za-z]{2})(?![A-Za-z0-9])");
    // "City, FullStateName" (e.g. "Dallas, Texas").
    private static final Pattern CITY_FULL_STATE_PATTERN = Pattern.compile(
            "(?<![A-Za-z0-9])([A-Za-z][A-Za-z .'\\-]{0,60}?)\\s*,\\s*("
                    + buildFullStateAlternation() + ")\\b", Pattern.CASE_INSENSITIVE);
    // "ST ZIP" (state + ZIP but no city) - establishes the state reliably.
    private static final Pattern STATE_ZIP_PATTERN = Pattern.compile(
            "(?<![A-Za-z0-9])([A-Za-z]{2})\\s+\\d{5}(?:-\\d{4})?(?![A-Za-z0-9])");

    // Every major US + Canadian city this app already knows (region/nationwide
    // maps), lowercased -> proper display name. Used to confirm a city candidate
    // so a random word is never saved as a buyer's location.
    private static final Map<String, String> KNOWN_US_CA_CITIES = buildKnownCityMap();

    // Reverse lookup: US state / Canadian province abbreviation -> full name.
    private static final Map<String, String> STATE_ABBR_TO_NAME = buildStateAbbrToNameMap();

    private static String buildFullStateAlternation() {
        List<String> names = new ArrayList<>();
        for (String s : US_STATE_NAMES) {
            names.add(s);
        }
        for (String s : CANADIAN_PROVINCE_NAMES) {
            names.add(s);
        }
        return names.stream().map(Pattern::quote).collect(Collectors.joining("|"));
    }

    private static Map<String, String> buildKnownCityMap() {
        Map<String, String> map = new HashMap<>();
        for (List<String> list : REGION_MAJOR_CITIES.values()) {
            for (String city : list) {
                if (city != null && !city.isBlank()) {
                    map.put(city.toLowerCase(Locale.ROOT), city.trim());
                }
            }
        }
        for (String city : NATIONWIDE_MAJOR_CITIES) {
            if (city != null && !city.isBlank()) {
                map.put(city.toLowerCase(Locale.ROOT), city.trim());
            }
        }
        return Collections.unmodifiableMap(map);
    }

    private static Map<String, String> buildStateAbbrToNameMap() {
        Map<String, String> map = new HashMap<>();
        for (Map.Entry<String, String> e : STATE_ABBREVIATIONS.entrySet()) {
            map.put(e.getValue(), e.getKey());
        }
        for (Map.Entry<String, String> e : CANADIAN_PROVINCE_ABBREVIATIONS.entrySet()) {
            map.put(e.getValue(), e.getKey());
        }
        return Collections.unmodifiableMap(map);
    }

    @Autowired
    @Qualifier("firecrawlWebClient")
    private WebClient webClient;

    @Autowired
    private FirecrawlConfig firecrawlConfig;

    @Autowired
    private EmailDiscoveryService emailDiscoveryService;

    @Autowired
    private UsaVerificationService usaVerificationService;

    @Autowired
    private BuyerRepository buyerRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<BuyerSearchResult> searchBuyers(String productName, int limit,
                                                 String state, String city, String country) {
        // HOME-DECOR CATEGORY GATE: every entered product must belong to one of
        // the supported home-decor families. An unrelated product (cars, clothing,
        // hotels, ...) stops immediately, BEFORE any Firecrawl request, so no
        // credits are ever spent on an invalid search.
        for (String entry : parseCommaSeparated(productName)) {
            if (!isSupportedHomeDecorProduct(entry)) {
                logger.warn("Unsupported product '{}' - stopping before any Firecrawl request", entry);
                throw new IllegalArgumentException(UNSUPPORTED_PRODUCT_MESSAGE);
            }
        }

        String apiKey = firecrawlConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            throw new RuntimeException("Firecrawl API key is not configured. Set the FIRECRAWL_API_KEY environment variable.");
        }

        // Requested country (USA / Canada). Country-wide searches append the
        // country word to every query; per-buyer locations are then extracted
        // from each real website (never guessed).
        String countryValue = country == null || country.isBlank() ? "USA"
                : collapseWhitespace(country);
        if (!countryValue.equalsIgnoreCase("USA") && !countryValue.equalsIgnoreCase("Canada")) {
            throw new IllegalArgumentException(
                    "Unsupported country '" + countryValue + "' - supported values are USA and Canada.");
        }

        // A product made only of buyer-role words (wholesale/retailer/
        // distributor/supplier/...) has no meaningful product term, so it could
        // never satisfy the product gate - returning nothing avoids wasting
        // Firecrawl credits on a meaningless query.
        List<String> parsedProducts = parseCommaSeparated(productName);
        // All saved buyers of one search are associated with the product the
        // USER entered - not with the internal catalogue term each query used -
        // so "find buyers by product" and email discovery keep working.
        String userProductLabel = String.join(", ", parsedProducts);
        List<String> products = parsedProducts.stream()
                .filter(p -> !significantTerms(p).isEmpty())
                .collect(Collectors.toList());
        if (products.isEmpty()) {
            logger.warn("Product name '{}' has no meaningful product terms "
                    + "(only buyer-role words) - returning no results", productName);
            return List.of();
        }
        if (products.size() < parsedProducts.size()) {
            logger.warn("Dropping product entries with no meaningful product terms: {}",
                    parsedProducts.stream()
                            .filter(p -> significantTerms(p).isEmpty())
                            .collect(Collectors.toList()));
        }

        String stateValue = collapseWhitespace(state);
        List<String> cities = parseCommaSeparated(city);
        // Every CITY searched during THIS search (fire order, unique) - the
        // same city is never searched twice and the final summary logs the
        // total city coverage. Empty for state/country-wide searches.
        Set<String> searchedCities = new LinkedHashSet<>();
        Set<String> allQueries = new LinkedHashSet<>();

        // Deterministic 6-query plan: PRODUCT VARIANT + BUYER-ROLE WORD +
        // LOCATION. Every query is ONE product phrase (the user's exact product
        // or an in-family synonym) followed by an explicit commercial buyer /
        // business word and a location, so EVERY one of the 6 requests carries
        // buyer intent - a bare "<product> <city> <state>" query that only
        // surfaces accessory shops, classes or articles is never fired. The six
        // slots are (Product variant, Buyer-role word, Location):
        //   R1 variant0 + retailer           + selected city
        //   R2 variant1 + wholesaler         + selected city
        //   R3 variant2 + distributor        + state-wide
        //   R4 variant3 + importer           + state-wide
        //   R5 variant4 + supplier/bulk      + state-wide
        //   R6 variant5 + dealer/buyer/sourcing + state-wide
        // Every slot pairs a DIFFERENT in-family product variant with a
        // DIFFERENT buyer-role word, so the six requests never repeat a product
        // phrasing or a buyer type and cover the broadest possible mix of real
        // stock buyers. Example for Product=Singing Bowls, State=Texas,
        // City=Fort Worth:
        //   R1: "singing bowls" retailer "Fort Worth" Texas
        //   R2: "tibetan singing bowls" wholesaler "Fort Worth" Texas
        //   R3: "himalayan singing bowls" distributor Texas
        //   R4: "crystal singing bowls" importer Texas
        //   R5: "meditation singing bowls" supplier/bulk Texas
        //   R6: "sound healing bowls" dealer/buyer/sourcing Texas
        // Only the selected city is ever searched (R1+R2); every remaining
        // request goes straight to the state/country-wide phase with a DIFFERENT
        // commercial intent word so wide-search recall is maximised - requests
        // are never spent rotating through OTHER cities.
        boolean canada = countryValue.equalsIgnoreCase("Canada");
        String countryWord = canada ? "Canada" : "USA";
        String countryNameFull = countryWord;

        String locationDesc = stateValue != null
                ? (cities.isEmpty() ? stateValue : cities + ", " + stateValue)
                : (cities.isEmpty() ? countryNameFull : String.join(", ", cities));

        // EVERY search - city, state or nationwide - uses the SAME hard budget
        // of exactly MAX_FIRECRAWL_REQUESTS_PER_SEARCH (6) Firecrawl requests
        // (first attempts AND 429 retries share the single 6-request budget).
        int requestBudget = MAX_FIRECRAWL_REQUESTS_PER_SEARCH;

        // Build the flat list of slots for all entered products from the
        // per-product deterministic plan (buildProductPlan): every slot pairs a
        // DIFFERENT in-family product variant with a DIFFERENT buyer-role word.
        // Each product fills up to the request budget (the global budget is
        // shared, so a multi-product search uses fewer slots per product). No
        // slot uses the old category-profile query form ("<cat> <cat> store
        // <product>") - every query stays natural: product variant + simple
        // buyer word + location.
        List<Slot> allSlots = new ArrayList<>();
        for (String prod : products) {
            for (Slot slot : buildProductPlan(prod, requestBudget)) {
                allSlots.add(slot);
                if (allSlots.size() >= requestBudget) {
                    break;
                }
            }
            if (allSlots.size() >= requestBudget) {
                break;
            }
        }

        List<SearchPhase> phases = new ArrayList<>();

        if (cities.isEmpty()) {
            // No city selected: all queries are state-wide or country-wide.
            List<StageEntry> entries = new ArrayList<>();
            for (Slot slot : allSlots) {
                Combo combo = stateValue != null
                        ? new Combo(slot.phrase, slot.phrase, stateValue, null, countryNameFull)
                        : new Combo(slot.phrase, slot.phrase, null, null, countryNameFull);
                addSlotEntry(entries,
                        stateValue != null ? QueryFamily.STATE : QueryFamily.NATIONWIDE,
                        stateValue != null ? LocTemplate.STATE_FULL : LocTemplate.NONE,
                        new String[]{slot.phrase, slot.word, slot.type},
                        combo, stateValue != null ? null : countryWord, slot.profile);
                String builtQuery = buildDiversifiedQuery(combo, entries.get(entries.size() - 1));
                logger.info("QUERY: {} | PRODUCT: {} | BUYER TYPE: {} | LOCATION: {}",
                        builtQuery, slot.phrase, slot.word != null ? slot.word : "-", locationDesc);
            }
            phases.add(new SearchPhase(stateValue != null ? "state-wide"
                    : "nationwide", entries, MAX_FIRECRAWL_REQUESTS_PER_SEARCH));
        } else {
            // City selected: PROGRESSIVE GEOGRAPHIC BROADENING with the same
            // 6-request budget. The slots are split between the REQUESTED city
            // and, when a state was requested, the REQUESTED state - a city
            // search NEVER rotates through other major cities and NEVER falls
            // back to nationwide USA results (requirement 2/3: a requested
            // city/state is never broadened to the whole country). When no
            // state was given, every slot targets the requested city/cities
            // exclusively (exact-city results only). Result priority equals the
            // phases' order: verified EXACT_CITY buyers first, then SAME_STATE
            // (a requested state is a valid broadening) - the location gate
            // classifies each result into exactly one bucket; breadth is
            // geographic, relevance stays strict.
            int stateStart = 2;
            boolean stateGiven = stateValue != null && !stateValue.isBlank();

            List<String> selectedCities = new ArrayList<>();
            Set<String> selectedCitySeen = new HashSet<>();
            for (String c : cities) {
                String cc = collapseWhitespace(c);
                if (cc != null && selectedCitySeen.add(cc.toLowerCase(Locale.ROOT))) {
                    selectedCities.add(cc);
                }
            }

            // PHASE 1 - the REQUESTED city/cities. Each slot keeps its distinct
            // (product phrase, buyer word); when several cities were given the
            // slots take them in order instead of repeating the first. When a
            // state was requested only the first two slots are city slots so the
            // remaining requests can broaden to the requested state; otherwise
            // every slot stays on the requested city/cities.
            List<StageEntry> cityEntries = new ArrayList<>();
            int citySlots = stateGiven ? Math.min(2, allSlots.size()) : allSlots.size();
            for (int i = 0; i < citySlots; i++) {
                Slot slot = allSlots.get(i);
                String targetCity = selectedCities == null || selectedCities.isEmpty() ? null
                        : selectedCities.get(i % selectedCities.size());
                if (targetCity != null) {
                    searchedCities.add(targetCity);
                }
                Combo combo = new Combo(slot.phrase, slot.phrase, stateValue, targetCity, countryNameFull);
                addSlotEntry(cityEntries, QueryFamily.CITY, LocTemplate.CITY_STATE_FULL,
                        new String[]{slot.phrase, slot.word, slot.type},
                        combo, null, slot.profile);
                String builtQuery = buildDiversifiedQuery(combo, cityEntries.get(cityEntries.size() - 1));
                logger.info("QUERY: {} | PRODUCT: {} | BUYER TYPE: {} | LOCATION: {} (requested city)",
                        builtQuery, slot.phrase, slot.word != null ? slot.word : "-",
                        targetCity != null
                                ? targetCity + (stateValue != null ? ", " + stateValue : "")
                                : countryNameFull);
            }
            if (!cityEntries.isEmpty()) {
                phases.add(new SearchPhase("requested city", cityEntries, cityEntries.size()));
            }

            // PHASE 2 - the REQUESTED state (the remaining slots). Only when a
            // state was requested and only reached when the city rounds did not
            // fill the limit; the state is the user's state, never another city.
            // There is NO nationwide phase for a city search (requirements 2/3),
            // so when the city and state rounds are spent the search ends.
            if (stateGiven) {
                List<StageEntry> stateEntries = new ArrayList<>();
                int stateSlots = Math.min(requestBudget - stateStart,
                        Math.max(0, allSlots.size() - stateStart));
                for (int i = 0; i < stateSlots; i++) {
                    Slot slot = allSlots.get(stateStart + i);
                    Combo combo = new Combo(slot.phrase, slot.phrase, stateValue, null, countryNameFull);
                    addSlotEntry(stateEntries, QueryFamily.STATE, LocTemplate.STATE_FULL,
                            new String[]{slot.phrase, slot.word, slot.type},
                            combo, null, slot.profile);
                    String builtQuery = buildDiversifiedQuery(combo,
                            stateEntries.get(stateEntries.size() - 1));
                    logger.info("QUERY: {} | PRODUCT: {} | BUYER TYPE: {} | LOCATION: {} (state-wide)",
                            builtQuery, slot.phrase, slot.word != null ? slot.word : "-",
                            stateValue);
                }
                if (!stateEntries.isEmpty()) {
                    phases.add(new SearchPhase("state-wide: " + stateValue,
                            stateEntries, stateEntries.size()));
                }
            }
        }

        logger.info("========================================");
        logger.info("BUYER SEARCH STARTED");
        logger.info("  Queries   : {} deterministic product-buyer-type queries", allSlots.size());
        logger.info("  Products  : {}", products);
        logger.info("  Country   : {}", countryNameFull);
        logger.info("  Limit     : {}", limit);
        logger.info("  State     : {}", stateValue != null ? stateValue : "(any)");
        logger.info("  Cities    : {}", cities.isEmpty() ? "(any)" : cities);
        for (SearchPhase phaseEntry : phases) {
            String queries = phaseEntry.entries.stream()
                    .map(StageEntry::describe)
                    .collect(Collectors.joining(" | "));
            logger.info("  Phase '{}': {} queries, budget {} calls, plan: [{}]",
                    phaseEntry.label, phaseEntry.entries.size(), phaseEntry.maxCalls, queries);
        }
        logger.info("========================================");

        Set<String> knownDatabaseWebsites = loadNormalizedDatabaseWebsites();
        logger.info("Loaded {} existing website(s) from database to exclude", knownDatabaseWebsites.size());

        // Websites already returned for any product/location - never returned twice.
        Set<String> returnedWebsites = new HashSet<>();
        // Every DISTINCT domain already seen anywhere in this search (accepted,
        // rejected or filtered). A domain re-surfaced by a later query/phase is a
        // duplicate: it was already evaluated, so it is never re-verified - its
        // previous verdict stands (requirement 6: verify each domain once).
        Set<String> seenThisSearch = new HashSet<>();
        // Domains for which full homepage verification actually ran in this
        // search (safety net at the verify layer, keyed by normalized domain).
        Set<String> verifiedDomains = new HashSet<>();
        // Normalized business names already accepted - catches the same business
        // reached through different domains / country versions (big-bowl.com vs
        // big-bowl.co.uk) or different tracking URLs.
        Set<String> claimedBusinessNames = new HashSet<>();
        // Per-combo seen set so deeper rounds never re-consider earlier candidates,
        // while the same website stays eligible for a different product/city combo.
        Map<Combo, Set<String>> seenByCombo = new HashMap<>();
        List<BuyerSearchResult> verifiedBuyers = new ArrayList<>();
        Map<String, String> homepageCache = new ConcurrentHashMap<>();
        // Canonical lowercased queries already fired during THIS search, so a
        // repeated synonym / role-word / location combination is never fired
        // twice (Firecrawl has no offset pagination, so a re-run adds nothing).
        Set<String> firedQueries = new HashSet<>();

        int firecrawlCalls = 0;
        int totalRawResults = 0;
        int totalDupSkipped = 0;
        int totalDbSkipped = 0;
        int totalRejected = 0;
        int totalAccepted = 0;
        SearchTally tally = new SearchTally();

        // Each round advances through the phase's ordered DIVERSIFIED query
        // strategies so the same strategy is never fired twice for the same
        // combo; Firecrawl has no offset pagination. Only ONE strategy is
        // attempted per combo per round, so the search is adaptive: it stops the
        // moment the limit or the per-search Firecrawl request budget is
        // reached. Once a phase's budget slice is spent without filling the
        // limit, the next phase (state-wide/nationwide fallback) starts a fresh
        // strategy list while credits remain. A strategy that came back
        // duplicate-heavy makes the remaining same-location-form strategies be
        // skipped, favouring NEW businesses over repeated hits.
        int phaseIdx = 0;
        int entryIdx = 0;
        int phaseCalls = 0;
        boolean skipSameFamily = false;
        QueryFamily firedFamily = null;
        String firedLocationKey = null;
        SearchPhase phase = phases.get(0);
        SearchBudget budget = new SearchBudget(requestBudget);
        String stopReason = null;

        for (int round = 0; round < requestBudget
                && verifiedBuyers.size() < limit && !budget.exhausted(); round++) {

            // Fallback gate: when the current phase's strategies are consumed
            // (or its call slice is spent) without filling the limit, move to
            // the next phase while credits remain. A state-wide phase only
            // exists when a specific state was requested (a requested city/state
            // is never broadened to the whole country - nationwide never fires
            // for a city search), so once every phase is spent, no strategy can
            // still yield results.
            if (entryIdx >= phase.entries.size() || phaseCalls >= phase.maxCalls) {
                if (phaseIdx + 1 < phases.size()) {
                    phaseIdx++;
                    phase = phases.get(phaseIdx);
                    entryIdx = 0;
                    phaseCalls = 0;
                    skipSameFamily = false;
                    logger.info("--- Broadening to phase '{}' ({} strategies) ---",
                            phase.label, phase.entries.size());
                    // Broadening without firing must not consume a round slot:
                    // only fired strategies count toward the 6-query budget.
                    round--;
                    continue;
                } else {
                    stopReason = "query bank yielded no more results";
                    break;
                }
            }

            // Duplicate-heavy strategy feedback: a strategy that returned almost
            // only already-known businesses means more of the SAME location
            // will too. When a DIFFERENT location still remains in this phase
            // the remaining same-location strategies are skipped (each other-city
            // entry targets a different city, so a duplicate-heavy Houston query
            // must NOT swallow Dallas / San Antonio). When every entry shares the
            // one fired location (selected-city phase) but a broader phase
            // exists, the phase is skipped so the search broadens state/nationwide
            // and never keeps repeating the same city. For a lone broad
            // state-wide phase the next entry - a DIFFERENT product variant +
            // buyer intent - is still tried instead of ending the search.
            if (skipSameFamily && phase.entries.get(entryIdx).family == firedFamily
                    && locationKey(phase.entries.get(entryIdx)).equals(firedLocationKey)) {
                String skippedLocation = firedLocationKey;
                boolean differentLocationRemains = false;
                for (int i = entryIdx; i < phase.entries.size(); i++) {
                    if (!locationKey(phase.entries.get(i)).equals(firedLocationKey)) {
                        differentLocationRemains = true;
                        break;
                    }
                }
                if (differentLocationRemains) {
                    while (entryIdx < phase.entries.size()
                            && phase.entries.get(entryIdx).family == firedFamily
                            && locationKey(phase.entries.get(entryIdx)).equals(skippedLocation)) {
                        entryIdx++;
                    }
                    skipSameFamily = false;
                    logger.info("Skipping remaining '{}' strategies at '{}' (previous one was duplicate-heavy)",
                            firedFamily.name().toLowerCase(Locale.ROOT), skippedLocation);
                    if (entryIdx >= phase.entries.size()) {
                        // Skipping consumed no credit - don't spend a round slot.
                        round--;
                        continue;
                    }
                } else if (phaseIdx + 1 < phases.size()) {
                    // Same location in every remaining entry (a selected-city
                    // phase with one city) but a broader phase exists: a
                    // duplicate-heavy city strategy means the other city slots
                    // (different combo next behaviour) would keep returning the
                    // SAME known businesses. Skip the whole phase and broaden to
                    // the state / nationwide phase instead of wasting a second
                    // credit repeating the same city.
                    entryIdx = phase.entries.size();
                    skipSameFamily = false;
                    logger.info("Duplicate-heavy at '{}' - skipping remaining same-location city strategies and broadening",
                            skippedLocation);
                    round--;
                    continue;
                } else {
                    // One location left and no broader phase: try the next
                    // strategy (different product variant + buyer intent) rather
                    // than ending the search early.
                    skipSameFamily = false;
                }
            }

            StageEntry entry = phase.entries.get(entryIdx);
            firedFamily = entry.family;
            firedLocationKey = locationKey(entry);

            // The selected city is fired MULTIPLE times on purpose - once per
            // distinct (product phrase, buyer word) slot - so the city-first
            // plan can surface several kinds of Arlington business. Exact
            // duplicate queries are still prevented by the firedQueries set
            // inside executeCombosSerially.

            int remaining = limit - verifiedBuyers.size();
            logger.info("--- Round {} [{}] : {} combo(s), query '{}', budget {}/{} ---",
                    round + 1, phase.label, entry.combos.size(), entry.describe(),
                    budget.used(), budget.max());

            // Search queries are fired one at a time, globally paced to respect
            // the Firecrawl rate limit, and stop immediately once the per-search
            // Firecrawl request budget is spent.
            CombosRound roundResponse =
                    executeCombosSerially(entry.combos, apiKey, entry, budget, firedQueries, round + 1);
            if (roundResponse.budgetExhausted) {
                stopReason = "Firecrawl request budget exhausted";
            }
            int roundCalls = roundResponse.grouped.values().stream().mapToInt(List::size).sum();
            firecrawlCalls += roundCalls;
            phaseCalls += roundCalls;

            List<Candidate> batchCandidates = new ArrayList<>();
            int entryRaw = 0;
            int entryDup = 0;
            int entryNew = 0;
            int roundDbSkipped = 0;

            // Every query fired in this round is fully processed for statistics
            // AND candidate collection - even when an earlier combo already fills
            // the requested window - so Raw results / DB skipped / duplicates
            // always reflect the COMPLETE search, never just the part that
            // eventually produced buyers.
            for (Combo combo : entry.combos) {
                Set<String> comboSeen = seenByCombo.computeIfAbsent(combo, k -> new HashSet<>());
                for (QueryTaskResult task : roundResponse.grouped.getOrDefault(combo, List.of())) {
                    totalRawResults += task.results.size();
                    entryRaw += task.results.size();
                    allQueries.add(task.query);
                    int newFromQuery = 0;
                    int dbSkippedFromQuery = 0;
                    int dupSkippedFromQuery = 0;
                    int filteredFromQuery = 0;

                    for (BuyerSearchResult result : task.results) {
                        String rawUrl = result.getWebsite();
                        String normalizedWebsite = normalizeWebsite(rawUrl);
                        if (normalizedWebsite == null || normalizedWebsite.isEmpty()) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.contentRejects.incrementAndGet();
                            logger.info("{} - no valid website URL in result (raw={})",
                                    CODE_INVALID_CONTENT, rawUrl);
                            continue;
                        }

                        if (isNonBusinessHost(normalizedWebsite)) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.contentRejects.incrementAndGet();
                            logger.info("{} '{}' ({}) - social/directory/review host",
                                    CODE_INVALID_CONTENT, result.getCompanyName(), normalizedWebsite);
                            continue;
                        }

                        if (knownDatabaseWebsites.contains(normalizedWebsite)) {
                            dbSkippedFromQuery++;
                            totalDbSkipped++;
                            roundDbSkipped++;
                            logger.info("{} '{}' ({}) - already in the buyer database",
                                    CODE_ALREADY_IN_DATABASE, result.getCompanyName(), normalizedWebsite);
                            continue;
                        }

                        if (returnedWebsites.contains(normalizedWebsite)) {
                            dupSkippedFromQuery++;
                            totalDupSkipped++;
                            logger.info("{} '{}' ({}) - already returned for another product/location",
                                    CODE_DUPLICATE, result.getCompanyName(), normalizedWebsite);
                            continue;
                        }

                        if (!comboSeen.add(normalizedWebsite)) {
                            dupSkippedFromQuery++;
                            totalDupSkipped++;
                            logger.info("{} '{}' ({}) - duplicate for combo '{}'",
                                    CODE_DUPLICATE, result.getCompanyName(), normalizedWebsite, combo.queryLabel());
                            continue;
                        }

                        // Search-wide dedup (requirement 6): a domain already seen
                        // for a DIFFERENT query/phase of this search is not
                        // re-processed - its previous screen/verdict stands. Only
                        // genuinely NEW domains reach the cheap screen, so late
                        // rounds surface different businesses instead of re-verifying
                        // the same ones for every query.
                        if (!seenThisSearch.add(normalizedWebsite)) {
                            dupSkippedFromQuery++;
                            totalDupSkipped++;
                            logger.info("{} '{}' ({}) - already processed earlier in this search",
                                    CODE_DUPLICATE, result.getCompanyName(), normalizedWebsite);
                            continue;
                        }

                        // ---- CHEAP SCREEN: URL/title/snippet only (no HTTP) ----
                        // Page-type classification (shopping/product page, file,
                        // article, government, directory, forum, academic) runs
                        // before any homepage fetch, so obviously bad results never
                        // cost processing.
                        String rejectReason = classifyPage(rawUrl, result.getRawTitle(), combo.queryProduct);
                        if (rejectReason != null) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.contentRejects.incrementAndGet();
                            logger.info("{} - {} '{}' ({})",
                                    CODE_INVALID_CONTENT, rejectReason,
                                    result.getRawTitle(), normalizedWebsite);
                            continue;
                        }

                        result.setWebsite(normalizedWebsite);
                        // The user's original product label is what gets saved and
                        // shown; the effective synonym is carried separately so the
                        // mandatory relevance gate verifies against what was actually
                        // searched.
                        result.setProductName(userProductLabel);
                        result.setSearchProduct(combo.queryProduct);

                        // Trade-data / import-export records & analytics portals
                        // (OEC, Panjiva, Volza, Trademap, customs data) provide
                        // statistics - they never buy the product.
                        if (isTradeDataPage(rawUrl, result.getRawTitle())) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.contentRejects.incrementAndGet();
                            logger.info("{} '{}' ({}) - trade-data/records site",
                                    CODE_NO_BUYER_INTENT, result.getRawTitle(), normalizedWebsite);
                            continue;
                        }

                        // CONDITION 1 - PRODUCT MATCH: every meaningful product
                        // term must be explicitly present in the title/snippet
                        // (known aliases count, e.g. meditation/sound bowl for
                        // singing bowls). Verified against the USER'S ENTERED
                        // products - the same gate the stage-2 full-page verify
                        // uses - so a result matching only the internal synonym
                        // ("meditation bowls") still fails when the user's own
                        // product family is absent.
                        if (!isProductRelevantForAny(result.getRawTitle(), result.getSnippet(),
                                normalizedWebsite, null, products, task.query)) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.productRejects.incrementAndGet();
                            logCandidateVerdict("REJECT", "no product relevance evidence",
                                    result.getRawTitle(), result.getSnippet(), normalizedWebsite,
                                    combo.queryProduct, combo.state, combo.city);
                            logger.info("{} '{}' ({}) - evidence does not mention '{}'",
                                    CODE_WRONG_PRODUCT, result.getRawTitle(), normalizedWebsite, combo.queryProduct);
                            continue;
                        }
                        // Cheap screen passed. This is NOT an accept/verdict:
                        // the commercial-evidence, business-type and location
                        // gates run on the homepage during full verification, so
                        // an ACCEPT logged here would contradict a later gate's
                        // rejection of the same candidate.
                        logCandidateVerdict("PASSED-CHEAP-SCREEN",
                                "product relevance evidence in the search listing; "
                                        + "commercial/business/location gates run on the homepage",
                                result.getRawTitle(), result.getSnippet(), normalizedWebsite,
                                combo.queryProduct, combo.state, combo.city);

                        // CONDITION 2 - LOCATION (cheap pre-filter): verified from the raw
                        // result BEFORE any homepage fetch / email scraping / save.
                        // A decisive non-US signal (country word, ", Country"
                        // address tail, based-in phrase, +foreign phone prefix,
                        // PIN code, foreign ccTLD) already rejects this candidate.
                        // US geo-targeting is benign and does NOT reject here: a
                        // buyer found state-wide or nationwide is acceptable, so
                        // the detailed EXACT_CITY/SAME_STATE/SAME_COUNTRY
                        // classification happens on the homepage in GATE 4.
                        String evidenceRaw = buildRawText(buildEvidence(result));
                        if (hasNonUsBusinessLocationSignal(evidenceRaw)
                                || hasForeignTld(normalizedWebsite)
                                || hasForeignHostSignal(normalizedWebsite, evidenceRaw)) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.locationRejects.incrementAndGet();
                            logger.info("{} '{}' ({}) - evidence points outside {}",
                                    CODE_WRONG_LOCATION, result.getRawTitle(), normalizedWebsite,
                                    combo.country != null ? combo.country : "USA");
                            continue;
                        }

                        // CONDITION 2b - CONFLICTING STATE (cheap pre-filter): a
                        // candidate whose OWN listing carries an ADDRESS for a
                        // DIFFERENT state than the one requested (", ST" or
                        // "ST ZIP"-form evidence) - and never the requested state
                        // by name or abbreviation - is a hard location mismatch
                        // and is rejected before any homepage fetch. A bare
                        // mention of another state ("now shipping to New York")
                        // is NOT an address and is left for the full GATE-4
                        // verification on the homepage (requirement 2: state-wide
                        // results must be in the requested state).
                        if (combo.state != null && !combo.state.isBlank()) {
                            String surfaceLower = evidenceRaw.toLowerCase(Locale.ROOT);
                            String stateKey = combo.state.trim().toLowerCase(Locale.ROOT);
                            String abbr = stateAbbreviation(combo.state);
                            boolean requestedStateMentioned = containsToken(surfaceLower, stateKey)
                                    || (!abbr.isEmpty()
                                    && containsStateAbbrevAddress(evidenceRaw, abbr));
                            if (!requestedStateMentioned
                                    && showsConflictingStateAddress(evidenceRaw, abbr)) {
                                filteredFromQuery++;
                                totalRejected++;
                                tally.locationRejects.incrementAndGet();
                                logger.info("{} '{}' ({}) - listing evidence gives an address in "
                                                + "a different state than requested '{}' (conflicting state)",
                                        CODE_WRONG_LOCATION, result.getRawTitle(),
                                        normalizedWebsite, combo.state);
                                continue;
                            }
                        }

                        // CONDITION 3 - BUYER INTENT is NO LONGER required to
                        // accept a result: a business that genuinely provides,
                        // sells, uses, teaches or works with the searched product
                        // (e.g. "Singing Bowl Lady: Silent Bowls", "Academy of
                        // Sound Healing") is valid even without importer/
                        // wholesaler/retailer/distributor/dealer/buyer keywords.
                        // Missing intent is logged and classified later (after the
                        // homepage is inspected) but never rejects the result.
                        // Product relevance, location and business identity above
                        // still guarantee the result is a real business related to
                        // the searched product.

                        // A result is only saved with a meaningful business name:
                        // "-" or a bare product title is never accepted as a buyer.
                        String businessName = extractBusinessName(result, combo.queryProduct);
                        if (businessName == null || !isMeaningfulName(businessName, combo.queryProduct)
                                || !hasGenuineBrandWord(businessName)) {
                            filteredFromQuery++;
                            totalRejected++;
                            tally.identityRejects.incrementAndGet();
                            logger.info("{} '{}' ({}) - no business identity in title/URL",
                                    CODE_NO_COMPANY_IDENTITY, result.getRawTitle(), normalizedWebsite);
                            continue;
                        }

                        // Same business reached via another domain / country version
                        // / tracking URL is a duplicate, not a new buyer.
                        String businessKey = normalizeBusinessKey(businessName);
                        if (businessKey != null && !claimedBusinessNames.add(businessKey)) {
                            dupSkippedFromQuery++;
                            totalDupSkipped++;
                            logger.info("{} '{}' ({}) - same business as an already accepted result",
                                    CODE_DUPLICATE, businessName, normalizedWebsite);
                            continue;
                        }

                        result.setCompanyName(businessName);
                        result.setBuyerName(businessName);
                        result.setState(combo.state);
                        result.setCity(combo.city);
                        result.setCountry(combo.country);
                        result.setLocation(buildLocationDisplay(combo.state, combo.city, combo.country));
                        batchCandidates.add(new Candidate(combo, result));
                        newFromQuery++;
                    }

                    // A query whose results are all DB rows / earlier hits must
                    // not end the search: log how many duplicates it returned so
                    // the credit use is visible, and keep trying the NEXT query
                    // strategy (requirement: continue until limit or budget ends).
                    if (newFromQuery == 0 && task.results.size() > 0) {
                        logger.info("Query '{}' yielded no new candidates ({} raw, {} already in DB, "
                                        + "{} duplicate in this search, {} filtered) - "
                                        + "continuing to the next query strategy",
                                task.query, task.results.size(), dbSkippedFromQuery,
                                dupSkippedFromQuery, filteredFromQuery);
                    }
                    entryDup += dbSkippedFromQuery + dupSkippedFromQuery;
                    entryNew += newFromQuery;
                }
            }

            if (!batchCandidates.isEmpty() && remaining > 0) {
                // Homepage verification is free (plain HTTP) and parallel, so
                // EVERY new candidate is verified - none are silently dropped.
                // The search still stops the moment the requested window fills.
                List<BuyerSearchResult> toVerify = new ArrayList<>(batchCandidates.size());
                for (Candidate candidate : batchCandidates) {
                    toVerify.add(candidate.result);
                }

                logger.info("Relevance/location-verifying {} candidate(s) to fill {} remaining slot(s)...",
                        toVerify.size(), remaining);

                List<BuyerSearchResult> roundVerified =
                        verifyCandidatesInParallel(toVerify, homepageCache, verifiedDomains,
                                tally);

                int rejected = toVerify.size() - roundVerified.size();
                totalRejected += rejected;

                int slotsToAdd = Math.min(remaining, roundVerified.size());
                totalAccepted += slotsToAdd;
                int roundAccepted = 0;
                for (int i = 0; i < slotsToAdd; i++) {
                    BuyerSearchResult toAdd = roundVerified.get(i);
                    verifiedBuyers.add(toAdd);
                    returnedWebsites.add(toAdd.getWebsite());
                    roundAccepted++;
                }

                logger.info("Verification: {} passed, {} rejected -> total {}/{}",
                        roundVerified.size(), rejected, verifiedBuyers.size(), limit);
                logger.info("Round {} | Searched City={} | Query=\"{}\" | Accepted={} | Rejected={} | Existing DB={} | Final Buyers={}",
                        round + 1,
                        !entry.combos.isEmpty() && entry.combos.get(0).city != null
                                ? entry.combos.get(0).city
                                : (stateValue != null ? "state-wide" : "nationwide"),
                        roundResponse.grouped.values().stream()
                                .flatMap(List::stream)
                                .map(t -> t.query)
                                .collect(Collectors.joining(" | ")),
                        roundAccepted, rejected, roundDbSkipped, verifiedBuyers.size());
            }

            // Stop immediately once the requested limit is reached. DB-skipped
            // and rejected results never count toward the limit.
            if (verifiedBuyers.size() >= limit) {
                stopReason = "requested limit reached";
                logger.info("Limit ({}) reached after round {} - {} Firecrawl call(s) used",
                        limit, round + 1, firecrawlCalls);
                break;
            }

            // Duplicate-heavy strategy feedback: when most raw results were already-known
            // businesses and nothing new came through, the remaining strategies
            // with the same location form are skipped so credit moves to a
            // different strategy that can actually surface NEW businesses.
            skipSameFamily = entryRaw > 0 && entryNew == 0
                    && entryDup > 0 && ((double) entryDup / entryRaw) >= DUP_HEAVY_RATIO;
            if (skipSameFamily) {
                logger.info("Strategy '{}' was duplicate-heavy ({}/{} = {}% dup/DB, 0 new) "
                                + "- pivoting to a different strategy",
                        entry.describe(), entryDup, entryRaw,
                        Math.round(100.0 * entryDup / entryRaw));
            }

            // Next round runs the next strategy for this phase's combos and can
            // only move forward - a strategy is never fired twice.
            entryIdx += 1;
        }

        if (stopReason == null) {
            stopReason = budget.exhausted()
                    ? "Firecrawl request budget exhausted"
                    : "query bank consumed";
        }
        logger.info("Search stopped: {}", stopReason);

        // SOCIAL TARGETING PASS - LinkedIn company/showcase pages and Facebook
        // business pages for the SAME product + location the user selected.
        // Runs ONLY while the requested limit is not yet filled and SHARES the
        // same 6-request Firecrawl budget as the exact/web search above, so the
        // whole search (web + social) never exceeds 6 Firecrawl requests. Social
        // pages block plain HTTP scraping and are not company websites, so they
        // are verified from the search result evidence itself (title/snippet)
        // and are automatically skipped by email discovery
        // (isRealBusinessWebsite=false) - they can never interrupt the
        // web-buyer email flow.
        int socialCalls = 0;
        if (verifiedBuyers.size() < limit && !products.isEmpty() && !budget.exhausted()) {
            Set<String> existingSocialWebsites = loadExistingSocialWebsites();
            Set<String> socialSeen = new HashSet<>();
            int callsBeforeSocial = budget.used();
            List<BuyerSearchResult> socialBuyers = runSocialSearch(
                    products.get(0), userProductLabel,
                    stateValue, cities.isEmpty() ? null : cities.get(0),
                    countryNameFull, countryWord, apiKey, budget,
                    limit - verifiedBuyers.size(), existingSocialWebsites, socialSeen);
            socialCalls = budget.used() - callsBeforeSocial;
            int socialAccepted = 0;
            for (BuyerSearchResult socialBuyer : socialBuyers) {
                if (verifiedBuyers.size() >= limit) {
                    break;
                }
                verifiedBuyers.add(socialBuyer);
                returnedWebsites.add(socialBuyer.getWebsite());
                socialAccepted++;
            }
            totalAccepted += socialAccepted;
            if (!socialBuyers.isEmpty()) {
                logger.info("SOCIAL SEARCH | LinkedIn/Facebook surfaced {} buyer(s) for '{}' in {}",
                        socialBuyers.size(), userProductLabel,
                        stateValue != null
                                ? (cities.isEmpty() ? stateValue : cities.get(0) + ", " + stateValue)
                                : countryNameFull);
            }
        }

        if (verifiedBuyers.size() > limit) {
            verifiedBuyers = new ArrayList<>(verifiedBuyers.subList(0, limit));
        }

        logger.info("========================================");
        logger.info("SEARCH + DEDUP + RELEVANCE-VERIFY COMPLETE");
        logger.info("  Firecrawl calls  : {}", firecrawlCalls);
        logger.info("  API requests     : {} ({} retried)", budget.used(), budget.retries());
        logger.info("  Social requests  : {} (LinkedIn/Facebook)", socialCalls);
        logger.info("  Raw results      : {}", totalRawResults);
        logger.info("  DB skipped       : {}", totalDbSkipped);
        logger.info("  Duplicate skipped: {}", totalDupSkipped);
        logger.info("  Rejected         : {}", totalRejected);
        logger.info("  Accepted         : {}", totalAccepted);
        logger.info("  Final buyers     : {}", verifiedBuyers.size());
        logger.info("  Stopped because  : {}", stopReason);
        logger.info("  Cities searched  : {}",
                searchedCities.isEmpty() ? "(none - state/country-wide)" : String.join(", ", searchedCities));
        logger.info("========================================");
        logger.info("FINAL SEARCH | Product={} | State={} | RequestedCity={} | ActualSearchCity={} | "
                        + "Query={} | Accepted={} | Rejected={} | ExistingDB={} | FinalBuyers={}",
                products, stateValue != null ? stateValue : "(any)",
                cities.isEmpty() ? "(any)" : cities,
                searchedCities.isEmpty() ? "(none - state/country-wide)" : String.join(",", searchedCities),
                allQueries.isEmpty() ? "(none fired)" : String.join(" | ", allQueries),
                totalAccepted, totalRejected, totalDbSkipped, verifiedBuyers.size());

        long emailStart = System.currentTimeMillis();
        ExecutorService emailExecutor = Executors.newFixedThreadPool(EMAIL_DISCOVERY_PARALLELISM);
        try {
            logger.info("Starting email scraping for {} buyer(s)", verifiedBuyers.size());
            List<CompletableFuture<Void>> tasks = new ArrayList<>();
            for (BuyerSearchResult result : verifiedBuyers) {
                tasks.add(CompletableFuture.runAsync(() -> {
                    try {
                        // STRICT VALIDATION BEFORE EMAIL SCRAPING: a candidate is
                        // only sent to EmailDiscoveryService when its Relevant URL
                        // is the actual business/company website. Social profiles,
                        // marketplaces/platform pages, document/PDF platforms,
                        // newsletter platforms, directories/listing sites,
                        // article/blog/news pages, forum/event pages and generic
                        // platform domains are rejected here and never scraped.
                        if (!emailDiscoveryService.isRealBusinessWebsite(result.getWebsite())) {
                            logger.info("EMAIL NOT FOUND | buyer='{}' | website={} | reason=not the actual business/company website - email scraping skipped",
                                    result.getCompanyName(), result.getWebsite());
                            return;
                        }
                        // Reuse the homepage fetched during verification so the
                        // official website is requested only once when available.
                        // When the homepage was never reached, discovery is STILL
                        // run (passing null): EmailDiscoveryService then tries the
                        // homepage again plus the contact/about pages, because the
                        // email usually lives on a dedicated contact page.
                        String homepageHtml = homepageCache.get(result.getWebsite());
                        String email = emailDiscoveryService.discoverEmail(result.getWebsite(), homepageHtml);
                        result.setEmail(email);
                        if (email != null && !email.isBlank()) {
                            logger.info("EMAIL FOUND | buyer='{}' | website={} | email={}",
                                    result.getCompanyName(), result.getWebsite(), email);
                        } else {
                            logger.info("EMAIL NOT FOUND | buyer='{}' | website={}",
                                    result.getCompanyName(), result.getWebsite());
                        }
                    } catch (Exception e) {
                        logger.warn("EMAIL SCRAPING FAILED | buyer='{}' | website={} - buyer kept without email: {}",
                                result.getCompanyName(), result.getWebsite(), e.getMessage());
                    }
                }, emailExecutor));
            }
            CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).join();
        } finally {
            emailExecutor.shutdown();
        }

        // Final ranking: location priority (EXACT_CITY > SAME_STATE > SAME_COUNTRY)
        // dominates (lower priority value = better), then evidence strength
        // (higher relevanceScore = better), then email availability (present
        // beats absent) - requirement 14 ordering.
        verifiedBuyers.sort(Comparator
                .comparingInt((BuyerSearchResult r) -> locationClassPriority(r.getLocationClass()))
                .thenComparingInt(r -> r.getEmail() != null && !r.getEmail().isBlank() ? 0 : 1)
                .thenComparingInt((BuyerSearchResult r) -> -r.getRelevanceScore()));

        int exactCityCount = 0;
        int sameStateCount = 0;
        int sameCountryCount = 0;
        int unknownClassCount = 0;
        for (BuyerSearchResult r : verifiedBuyers) {
            String lc = r.getLocationClass();
            if (LOCATION_CLASS_EXACT_CITY.equals(lc)) {
                exactCityCount++;
            } else if (LOCATION_CLASS_SAME_STATE.equals(lc)) {
                sameStateCount++;
            } else if (LOCATION_CLASS_SAME_COUNTRY.equals(lc)) {
                sameCountryCount++;
            } else {
                unknownClassCount++;
            }
        }

        long totalDuration = System.currentTimeMillis() - emailStart;
        logger.info("========================================");
        logger.info("BUYER SEARCH COMPLETE");
        logger.info("  Products         : {}", products);
        logger.info("  Requested region : {}/{}", stateValue, cities.isEmpty() ? "(any)" : cities);
        logger.info("  Searched cities  : {}",
                searchedCities.isEmpty() ? "(none - state/country-wide)" : String.join(", ", searchedCities));
        logger.info("  Requested limit  : {}", limit);
        logger.info("  Unique returned  : {}", verifiedBuyers.size());
        logger.info("  Firecrawl calls  : {}", firecrawlCalls);
        logger.info("  Location class   : EXACT_CITY={} | SAME_STATE={} | SAME_COUNTRY={} | UNKNOWN={}",
                exactCityCount, sameStateCount, sameCountryCount, unknownClassCount);
        logger.info("  Reject breakdown : DB_SKIPPED={} | DUPLICATE={} | {} | FILTERED_RAW={}",
                totalDbSkipped, totalDupSkipped, tally.breakdown(),
                totalRejected - (totalDbSkipped + totalDupSkipped));
        logger.info("  Email scraping   : {} ms", totalDuration);
        logger.info("========================================");

        return verifiedBuyers;
    }

    /** Selection/ranking priority of a location class: lower = better
     *  (EXACT_CITY first, then SAME_STATE, then SAME_COUNTRY, UNKNOWN last). */
    private int locationClassPriority(String locationClass) {
        if (LOCATION_CLASS_EXACT_CITY.equals(locationClass)) {
            return 0;
        }
        if (LOCATION_CLASS_SAME_STATE.equals(locationClass)) {
            return 1;
        }
        if (LOCATION_CLASS_SAME_COUNTRY.equals(locationClass)) {
            return 2;
        }
        return 3;
    }

    // ------------------------------------------------------------------
    // Combo / query building
    // ------------------------------------------------------------------

    private static final class Combo {
        // The user's original product label - kept for display/classification and
        // stored as the buyer's productName (email discovery & campaigns depend on it).
        final String product;
        // The effective product phrasing actually sent to Firecrawl and used for
        // the mandatory relevance gate (e.g. a decorative-jar synonym).
        final String queryProduct;
        final String state;
        final String city;
        // Requested country ("USA"/"Canada") - drives the Firecrawl geo-location
        // and the country word appended to country-wide (nationwide) queries.
        final String country;

        Combo(String product, String state, String city) {
            this(product, product, state, city, "USA");
        }

        Combo(String product, String queryProduct, String state, String city) {
            this(product, queryProduct, state, city, "USA");
        }

        Combo(String product, String queryProduct, String state, String city, String country) {
            this.product = product;
            this.queryProduct = queryProduct != null && !queryProduct.isBlank() ? queryProduct : product;
            this.state = state;
            this.city = city;
            this.country = country != null && !country.isBlank() ? country : "USA";
        }

        String queryLabel() {
            StringBuilder sb = new StringBuilder();
            sb.append("\"").append(queryProduct).append("\"");
            if (city != null && !city.isBlank()) {
                sb.append(" \"").append(city).append("\"");
            }
            if (state != null && !state.isBlank()) {
                sb.append(" ").append(state);
            }
            if (country != null && !country.isBlank()) {
                sb.append(" ").append(country);
            }
            return sb.toString();
        }
    }

    // One planned query slot: the effective product phrase, the buyer-profile
    // word (e.g. "for sale", "store", "retailer", "wholesale") + its business
    // type, and an optional RELATED-CATEGORY profile (leading category words
    // for the category-profile queries, e.g. "meditation" "spiritual"
    // "wellness"); null for the standard product-first slots.
    private static final class Slot {
        final String phrase;
        final String word;
        final String type;
        final List<String> profile;

        Slot(String phrase, String word, String type, List<String> profile) {
            this.phrase = phrase;
            this.word = word;
            this.type = type;
            this.profile = profile;
        }
    }

    // Location/word query forms. Location-only forms (CITY_ABBR, HUB_ABBR) carry
    // no buyer-intent word: they surface businesses a role word would hide and
    // are still fully gated by the mandatory product/location/intent checks.
    private enum LocTemplate { CITY_ABBR, CITY_ONLY, HUB_ABBR, STATE_FULL, STATE_ABBR, CITY_STATE_FULL, NONE }

    // Strategy family used by duplicate-heavy feedback: "family" is the location
    // formula (city / metro / state / nationwide), so a city strategy that only
    // returns known businesses skips the OTHER city strategies and moves to a
    // different location formula.
    private enum QueryFamily { CITY, OTHER_CITY, STATE, NATIONWIDE }

    // One diversified query strategy: a single location template + optional
    // buyer-intent word, applied to each of its combos. Strategies are tried in
    // order and never fired twice for the same combo.
    private static final class StageEntry {
        final QueryFamily family;
        final LocTemplate loc;
        final String[] word;   // {word, businessType}; null for location-only
        final String hub;      // nearby metro city, only for HUB_ABBR
        final String countryWord; // "USA"/"Canada"; appended to country-wide queries
        // Leading category-profile words for the two RELATED-CATEGORY buyer
        // profile queries (e.g. "meditation" "spiritual" "wellness" store
        // "singing bowls" Texas). null for the standard product-first queries.
        final List<String> profile;
        final List<Combo> combos;

        StageEntry(QueryFamily family, LocTemplate loc, String[] word, String hub, List<Combo> combos) {
            this(family, loc, word, hub, combos, null, null);
        }

        StageEntry(QueryFamily family, LocTemplate loc, String[] word, String hub,
                   List<Combo> combos, String countryWord) {
            this(family, loc, word, hub, combos, countryWord, null);
        }

        StageEntry(QueryFamily family, LocTemplate loc, String[] word, String hub,
                   List<Combo> combos, String countryWord, List<String> profile) {
            this.family = family;
            this.loc = loc;
            this.word = word;
            this.hub = hub;
            this.combos = combos;
            this.countryWord = countryWord;
            this.profile = profile;
        }

        boolean wordless() {
            return word == null || word[0] == null || word[0].isBlank();
        }

        String businessType() {
            return wordless() ? "Buyer" : word[1];
        }

        String describe() {
            StringBuilder s = new StringBuilder();
            if (profile != null && !profile.isEmpty()) {
                for (String pw : profile) {
                    s.append("\"").append(pw).append("\" ");
                }
                if (!wordless()) {
                    s.append(word[0]);
                }
                if (combos != null && combos.size() == 1 && combos.get(0).queryProduct != null) {
                    s.append(" \"").append(combos.get(0).queryProduct.trim()).append("\"");
                }
            } else if (combos != null && combos.size() == 1 && combos.get(0).queryProduct != null) {
                s.append("\"").append(combos.get(0).queryProduct.trim()).append("\"");
                if (!wordless()) {
                    s.append(" ").append(word[0]);
                }
            } else if (!wordless()) {
                s.append(word[0]);
            }
            switch (loc) {
                case CITY_ABBR: s.append(" \"<city>\" <ABBR>"); break;
                case CITY_ONLY: s.append(" \"<city>\""); break;
                case HUB_ABBR:  s.append(" \"").append(hub).append("\" <ABBR>"); break;
                case STATE_FULL: s.append(" <state>"); break;
                case STATE_ABBR: s.append(" <ABBR>"); break;
                case CITY_STATE_FULL: s.append(" \"<city>\" <state>"); break;
                default:         s.append(" nationwide");
            }
            if (countryWord != null) {
                s.append(" ").append(countryWord);
            }
            return s.toString();
        }
    }

    // One search stage (exact city -> state-wide/nationwide fallback). Each
    // phase owns its ordered diversified query strategies and a slice of the
    // per-search Firecrawl budget, so the fallback can never be starved by the
    // first phase.
    private static final class SearchPhase {
        final String label;
        final List<StageEntry> entries;
        final int maxCalls;

        SearchPhase(String label, List<StageEntry> entries, int maxCalls) {
            this.label = label;
            this.entries = entries;
            this.maxCalls = maxCalls;
        }
    }

// One stage entry holds exactly ONE combo, so a round always fires a single
    // diversified query (product synonym x location form x role word). This
    // spreads the per-search Firecrawl budget across distinct queries instead of
    // firing every synonym/role-word combo of an entry in the same round.
    private void addStateEntry(List<StageEntry> entries, QueryFamily family, LocTemplate loc,
                               String word, String type, List<Combo> combos) {
        for (Combo combo : combos) {
            entries.add(new StageEntry(family, loc,
                    word != null ? new String[]{word, type} : null, null, List.of(combo)));
        }
    }

    private void addStateEntry(List<StageEntry> entries, QueryFamily family, LocTemplate loc,
                               String word, String type, List<Combo> combos, String hub) {
        for (Combo combo : combos) {
            entries.add(new StageEntry(family, loc,
                    word != null ? new String[]{word, type} : null, hub, List.of(combo)));
        }
    }

    // One product slot (product term + buyer word + business type) becomes ONE
    // diversified strategy entry, so a round always fires the product query.
    // An optional category-profile leads the RELATED-CATEGORY buyer queries
    // (e.g. "meditation" "spiritual" "wellness" store "<product>" <state>).
    private void addSlotEntry(List<StageEntry> entries, QueryFamily family, LocTemplate loc,
                              String[] slot, Combo combo, String countryWord) {
        addSlotEntry(entries, family, loc, slot, combo, countryWord, null);
    }

    private void addSlotEntry(List<StageEntry> entries, QueryFamily family, LocTemplate loc,
                              String[] slot, Combo combo, String countryWord, List<String> profile) {
        entries.add(new StageEntry(family, loc,
                new String[]{slot[1], slot[2]}, null, List.of(combo), countryWord, profile));
    }

    // The location a strategy targets ("state|city"), used so a
    // duplicate-heavy query only skips further strategies for the SAME
    // location and never silently drops the other cities of the chain.
    private String locationKey(StageEntry entry) {
        Combo combo = entry.combos.get(0);
        String state = combo.state == null ? "" : combo.state.toLowerCase(Locale.ROOT);
        String city = combo.city == null ? "" : collapseWhitespace(combo.city).toLowerCase(Locale.ROOT);
        return state + "|" + city;
    }

    // Query-product synonyms for one product. The user's own phrasing is always
    // first; decorative-jar searches are widened with in-family synonyms (never
    // unrelated products) so each of the 6 Firecrawl requests can surface NEW
    // buyers instead of repeating an overly specific phrase that returns zero.
    // Duplicates are removed so no synonym is ever searched twice.
    private List<String> productQuerySynonyms(String product) {
        String norm = normalizeProductForValidation(product);
        Set<String> words = new HashSet<>(tokenizeWords(norm));
        List<String> synonymList = isDecorativeJarProduct(words)
                ? DECORATIVE_JAR_QUERY_SYNONYMS : List.of();
        List<String> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (product != null && !product.isBlank()) {
            String key = product.trim().toLowerCase(Locale.ROOT);
            if (seen.add(key)) {
                result.add(product.trim());
            }
        }
        for (String synonym : synonymList) {
            String key = synonym.toLowerCase(Locale.ROOT);
            if (seen.add(key)) {
                result.add(synonym);
            }
        }
        return result;
    }

    // Builds the combos for one product and location: one combo per query
    // synonym. The user's original product is kept as the label; the synonym is
    // the effective phrase fired at Firecrawl and used by the relevance gate.
    private List<Combo> combosFor(String product, String stateValue, String city) {
        List<Combo> combos = new ArrayList<>();
        for (String synonym : productQuerySynonyms(product)) {
            combos.add(new Combo(product, synonym, stateValue, city));
        }
        return combos;
    }

    private List<String> parseCommaSeparated(String raw) {
        if (raw == null || raw.isBlank()) {
            return List.of();
        }
        return Arrays.stream(raw.split(","))
                .map(String::trim)
                .map(this::collapseWhitespace)
                .filter(s -> !s.isEmpty())
                .distinct()
                .collect(Collectors.toList());
    }

    private String stateAbbreviation(String state) {
        if (state == null || state.isBlank()) {
            return "";
        }
        String abbr = STATE_ABBREVIATIONS.get(state.trim().toLowerCase(Locale.ROOT));
        return abbr != null ? abbr : "";
    }

    private String buildLocationDisplay(String state, String city) {
        return buildLocationDisplay(state, city, null);
    }

    /**
     * Builds the display location string. The SEARCHED country is honored when
     * the city/state alone cannot decide it (e.g. the user searched Canada and
     * a Canadian province is implied, or a city has no provable province), so a
     * Canada search never renders "Toronto, USA" / "Ontario, USA". When no
     * country is passed, the US/Canada decision is still made from a real state
     * or province name.
     */
    private String buildLocationDisplay(String state, String city, String country) {
        String countryLabel = country != null && !country.isBlank()
                ? country
                : (state != null && !state.isBlank()
                        ? countryNameForState(state)
                        : "USA");
        if (city != null && !city.isBlank() && state != null && !state.isBlank()) {
            return city + ", " + state + ", " + countryLabel;
        }
        if (city != null && !city.isBlank()) {
            return city + ", " + countryLabel;
        }
        if (state != null && !state.isBlank()) {
            return state + ", " + countryLabel;
        }
        // A location we cannot verify is never guessed - it is marked Unknown.
        return "Unknown";
    }

    private String countryNameForState(String state) {
        if (state == null) {
            return "USA";
        }
        String key = state.trim().toLowerCase(Locale.ROOT);
        return CANADIAN_PROVINCE_ABBREVIATIONS.containsKey(key) ? "Canada" : "USA";
    }

    // Builds one diversified query from a combo and its strategy:
    //   product-first for the standard slots
    //     "Singing Bowls" "for sale" "San Antonio", Texas   (profile word quoted)
    //     "Decorative Lanterns" wholesaler Texas
    //   category-profile first for the RELATED-CATEGORY buyer slots
    //     "meditation" "spiritual" "wellness" store "singing bowls" Texas
    // The buyer word is quoted when it is multi-word ("for sale"), so Firecrawl
    // treats it as one phrase instead of two random keywords.
    private String buildDiversifiedQuery(Combo combo, StageEntry entry) {
        StringBuilder sb = new StringBuilder();
        if (entry.profile != null && !entry.profile.isEmpty()) {
            for (String pw : entry.profile) {
                sb.append("\"").append(pw).append("\" ");
            }
            if (!entry.wordless()) {
                sb.append(entry.word[0]);
            }
            sb.append(" \"").append(combo.queryProduct.trim()).append("\"");
        } else {
            sb.append("\"").append(combo.queryProduct.trim()).append("\"");
            if (!entry.wordless()) {
                sb.append(" ");
                appendBuyerWord(sb, entry.word[0]);
            }
        }
        String abbr = stateAbbreviation(combo.state);
        switch (entry.loc) {
            case CITY_ABBR:
                if (combo.city != null && !combo.city.isBlank()) {
                    sb.append(" \"").append(combo.city.trim()).append("\"");
                    if (!abbr.isEmpty()) sb.append(" ").append(abbr);
                }
                break;
            case CITY_ONLY:
                if (combo.city != null && !combo.city.isBlank()) {
                    sb.append(" \"").append(combo.city.trim()).append("\"");
                }
                break;
            case HUB_ABBR:
                if (entry.hub != null && !entry.hub.isBlank()) {
                    sb.append(" \"").append(entry.hub).append("\"");
                    if (!abbr.isEmpty()) sb.append(" ").append(abbr);
                }
                break;
            case STATE_FULL:
                if (combo.state != null && !combo.state.isBlank()) {
                    sb.append(" ").append(combo.state.trim());
                }
                break;
            case STATE_ABBR:
                if (!abbr.isEmpty()) sb.append(" ").append(abbr);
                break;
            case CITY_STATE_FULL:
                if (combo.city != null && !combo.city.isBlank()) {
                    sb.append(" \"").append(combo.city.trim()).append("\"");
                    if (combo.state != null && !combo.state.isBlank()) {
                        sb.append(" ").append(combo.state.trim());
                    }
                }
                break;
            default:
                break; // NONE: product + word, then the country word
        }
        // Country-wide (nationwide) queries append the requested country so
        // Firecrawl scopes results to the USA / Canada.
        if (entry.loc == LocTemplate.NONE && entry.countryWord != null
                && !entry.countryWord.isBlank()) {
            sb.append(" ").append(entry.countryWord);
        }
        return sb.toString();
    }

    /** Appends the buyer-profile word; multi-word words are quoted ("for sale")
     *  so Firecrawl matches them as one exact phrase, single words stay bare. */
    private void appendBuyerWord(StringBuilder sb, String word) {
        if (word == null || word.isBlank()) {
            return;
        }
        String w = word.trim();
        if (w.contains(" ")) {
            sb.append("\"").append(w).append("\"");
        } else {
            sb.append(w);
        }
    }

    /**
     * Geo-targeting value passed to Firecrawl's search `location` parameter
     * (e.g. "San Antonio, Texas, United States" or "Vancouver, British
     * Columbia, Canada"). Only the city/state/country the user actually asked
     * for is used - nothing is assumed.
     */
    private String buildFirecrawlLocation(Combo combo) {
        StringBuilder sb = new StringBuilder();
        if (combo.city != null && !combo.city.isBlank()) {
            sb.append(combo.city.trim());
        }
        if (combo.state != null && !combo.state.isBlank()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(combo.state.trim());
        }
        if (sb.length() == 0) {
            return null;
        }
        sb.append(", ").append(combo.country != null && combo.country.equalsIgnoreCase("Canada")
                ? "Canada" : "United States");
        return sb.toString();
    }

    /**
     * Fires ONE strategy per combo per round, ONE AT A TIME and globally paced
     * by the Firecrawl rate limiter, so a parallel burst can never trip the
     * account's requests-per-minute limit. The search adapts to the remaining
     * per-search budget: the next strategy is tried for each active combo and
     * firing stops at once when the Firecrawl request budget is exhausted.
     */
    private CombosRound executeCombosSerially(List<Combo> combos, String apiKey,
                                              StageEntry entry, SearchBudget budget,
                                              Set<String> firedQueries, int round) {
        Map<Combo, List<QueryTaskResult>> grouped = new LinkedHashMap<>();
        int usedTypeCount = 0;
        boolean budgetExhausted = false;

        for (Combo combo : combos) {
            if (budget.exhausted()) {
                budgetExhausted = true;
                break;
            }
            List<QueryTaskResult> tasks = new ArrayList<>();
            usedTypeCount = 1;
            String query = buildDiversifiedQuery(combo, entry);
            String wordDisplay = entry.wordless() ? "-" : entry.word[0];
            // Required per-request log: round, product phrase, buyer term, city,
            // state and the FULL query as actually fired at Firecrawl.
            logger.info("SEARCH ROUND {} | Product phrase = \"{}\" | Buyer term = {} | "
                            + "City = {} | State = {} | Query = \"{}\"",
                    round, combo.queryProduct,
                    wordDisplay,
                    combo.city != null ? combo.city : "(any)",
                    combo.state != null ? combo.state : "(any)",
                    query);

            // Never fire a query that was already fired this search (identical
            // synonym + role word + location). A repeated query would spend a
            // budget slot for nothing, so it is skipped and the budget moves to
            // a different strategy.
            String queryKey = query.toLowerCase(Locale.ROOT);
            if (!firedQueries.add(queryKey)) {
                logger.info("Skipping already-fired duplicate query '{}' - moving to the next strategy",
                        query);
                grouped.put(combo, tasks);
                continue;
            }

            List<BuyerSearchResult> results;
            try {
                results = executeSearch(query, entry.businessType(), apiKey, RESULTS_PER_QUERY,
                        buildFirecrawlLocation(combo), budget);
            } catch (BudgetExhaustedException e) {
                budgetExhausted = true;
                results = List.of();
            } catch (Exception e) {
                logger.error("Failed to execute search for '{}' ({}): {}",
                        combo.queryLabel(), wordDisplay, e.getMessage());
                results = List.of();
            }
            tasks.add(new QueryTaskResult(query, entry.word, results));
            grouped.put(combo, tasks);
        }

        return new CombosRound(grouped, usedTypeCount, budgetExhausted);
    }

    private static final class CombosRound {
        final Map<Combo, List<QueryTaskResult>> grouped;
        final int usedTypeCount;
        final boolean budgetExhausted;

        CombosRound(Map<Combo, List<QueryTaskResult>> grouped, int usedTypeCount, boolean budgetExhausted) {
            this.grouped = grouped;
            this.usedTypeCount = usedTypeCount;
            this.budgetExhausted = budgetExhausted;
        }
    }

    private static final class QueryTaskResult {
        final String query;
        final String[] queryDef;
        final List<BuyerSearchResult> results;

        QueryTaskResult(String query, String[] queryDef, List<BuyerSearchResult> results) {
            this.query = query;
            this.queryDef = queryDef;
            this.results = results != null ? results : List.of();
        }
    }

    /**
     * Counts the actual Firecrawl API requests (first attempts AND 429 retries)
     * for a single buyer search. Every HTTP attempt goes through tryAcquire(),
     * so a search can never spend more than the capped budget and immediately
     * stops firing once the cap is reached.
     */
    private static final class SearchBudget {
        private final int maxRequests;
        private final AtomicInteger requests = new AtomicInteger(0);
        private final AtomicInteger retries = new AtomicInteger(0);

        SearchBudget(int maxRequests) {
            this.maxRequests = maxRequests;
        }

        int max() {
            return maxRequests;
        }

        int used() {
            return requests.get();
        }

        int retries() {
            return retries.get();
        }

        boolean exhausted() {
            return requests.get() >= maxRequests;
        }

        boolean tryAcquire() {
            int current;
            do {
                current = requests.get();
                if (current >= maxRequests) {
                    return false;
                }
            } while (!requests.compareAndSet(current, current + 1));
            return true;
        }

        void recordRetry() {
            retries.incrementAndGet();
        }
    }

    /** Thrown when the per-search Firecrawl request budget is spent. */
    private static final class BudgetExhaustedException extends RuntimeException {
        BudgetExhaustedException(String message) {
            super(message);
        }
    }

    private static final class Candidate {
        final Combo combo;
        final BuyerSearchResult result;

        Candidate(Combo combo, BuyerSearchResult result) {
            this.combo = combo;
            this.result = result;
        }
    }

    // Thread-safe per-search counters for the FINAL reject-breakdown log
    // (requirement: EXACT_CITY/SAME_STATE/SAME_COUNTRY/FINAL + reject buckets).
    private static final class SearchTally {
        final AtomicLong productRejects = new AtomicLong();
        final AtomicLong commercialRejects = new AtomicLong();
        final AtomicLong businessTypeRejects = new AtomicLong();
        final AtomicLong locationRejects = new AtomicLong();
        final AtomicLong contentRejects = new AtomicLong();
        final AtomicLong identityRejects = new AtomicLong();

        String breakdown() {
            return "PRODUCT=" + productRejects.get()
                    + " | COMMERCIAL=" + commercialRejects.get()
                    + " | BUSINESS=" + businessTypeRejects.get()
                    + " | LOCATION=" + locationRejects.get()
                    + " | CONTENT=" + contentRejects.get()
                    + " | IDENTITY=" + identityRejects.get();
        }
    }

    // ------------------------------------------------------------------
    // Strict product + location + US relevance verification
    // ------------------------------------------------------------------

    private List<BuyerSearchResult> verifyCandidatesInParallel(List<BuyerSearchResult> batch,
                                                               Map<String, String> homepageCache,
                                                               Set<String> verifiedDomains,
                                                               SearchTally tally) {
        // Results are kept in Firecrawl ranking order so the highest-ranked
        // relevant buyers are returned first, not whichever check finishes first.
        BuyerSearchResult[] passed = new BuyerSearchResult[batch.size()];
        // Requirement 6: each normalized domain is verified at most once per
        // search. Domains verified in an earlier round keep their verdict - a
        // rejected domain is never re-verified for every later query.
        boolean[] schedule = new boolean[batch.size()];
        for (int i = 0; i < batch.size(); i++) {
            String domain = normalizeWebsite(batch.get(i).getWebsite());
            if (domain != null && verifiedDomains.add(domain)) {
                schedule[i] = true;
            } else {
                logger.info("{} - '{}' already verified earlier in this search - keeping its verdict",
                        CODE_DUPLICATE, domain == null ? batch.get(i).getWebsite() : domain);
            }
        }
        ExecutorService executor = Executors.newFixedThreadPool(EMAIL_DISCOVERY_PARALLELISM);
        try {
            List<CompletableFuture<Void>> tasks = new ArrayList<>();
            for (int i = 0; i < batch.size(); i++) {
                if (!schedule[i]) {
                    continue;
                }
                final int index = i;
                final BuyerSearchResult result = batch.get(i);
                tasks.add(CompletableFuture.runAsync(() -> {
                    try {
                        if (isRelevantBuyer(result, homepageCache, tally)) {
                            passed[index] = result;
                        }
                    } catch (Exception e) {
                        logger.warn("Verification error for '{}' - buyer kept: {}",
                                result.getWebsite(), e.getMessage());
                        passed[index] = result;
                    }
                }, executor));
            }
            CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).join();
        } finally {
            executor.shutdown();
        }
        List<BuyerSearchResult> verified = new ArrayList<>(batch.size());
        for (BuyerSearchResult result : passed) {
            if (result != null) {
                verified.add(result);
            }
        }
        return verified;
    }

    /**
     * Proof the buyer's own website URL carries the product, used when the
     * homepage cannot be crawled at all: the search-listing title/snippet are
     * only the engine echoing the queried terms, so a website that is
     * unreachable is accepted ONLY when its own URL (shopping path, e.g.
     * /crystal-singing-bowls/, or an alphanumeric domain) holds a strong
     * product phrase for any of the user's entered products.
     */
    private boolean hasWebsiteUrlProductEvidence(BuyerSearchResult result) {
        String path = shopPathText(result.getWebsite());
        String domain = domainEvidence(result.getWebsite());
        for (String product : parseCommaSeparated(result.getProductName())) {
            String p = normalizeProductForValidation(product);
            if (p == null || p.isBlank()) {
                continue;
            }
            ProductSpec spec = buildProductSpec(p, new HashSet<>(tokenizeWords(p)));
            List<String> candidates = new ArrayList<>();
            candidates.add(p);
            for (String phrase : spec.strongPhrases) {
                if (!candidates.contains(phrase)) {
                    candidates.add(phrase);
                }
            }
            if (findFirstStrongPhrase(candidates, "", path, "", domain, "") != null) {
                return true;
            }
        }
        return false;
    }

    /**
     * Positive USA evidence for a buyer whose exact region is unconfirmed:
     * a US postal address ("Dallas, TX 75201"), a city/full-state pair, a US
     * 10-digit phone number, an explicit United-States/USA form, or a decisive
     * US verdict from the location verifier. This is the OPPOSITE of
     * isUsRelevant (which tolerates absent signals): a rejected candidate is
     * NOT accepted on the absence of non-US evidence, only when a reliable US
     * signal is present, so a state-wide fallback never blindly admits
     * international or unlocated businesses.
     */
    private boolean hasReliableUsEvidence(String rawText) {
        if (rawText == null || rawText.isBlank()) {
            return false;
        }
        String text = buildRawText(rawText);
        // 5-digit ZIP code with a 2-letter state is unambiguous US: Canadian
        // postal codes are letter-digit-letter, never 5 numeric digits.
        if (CITY_STATE_ZIP_PATTERN.matcher(text).find()
                || STATE_ZIP_PATTERN.matcher(text).find()) {
            return true;
        }
        java.util.regex.Matcher fullState = CITY_FULL_STATE_PATTERN.matcher(text);
        if (fullState.find()) {
            return true;
        }
        java.util.regex.Matcher cityState = CITY_STATE_PATTERN.matcher(text);
        if (cityState.find()) {
            String abbrev = cityState.group(2).toUpperCase(Locale.ROOT);
            if (UsaVerificationService.US_STATE_ABBREVS.contains(abbrev)) {
                return true;
            }
        }
        if (Pattern.compile("\\b(?:united states|united states of america|the usa|"
                        + "u\\.s\\.a|u\\.s\\.)\\b", Pattern.CASE_INSENSITIVE)
                .matcher(text).find()) {
            return true;
        }
        if (Pattern.compile("\\b\\(?(\\d{3})\\)?[-.\\s]\\d{3}[-.\\s]\\d{4}\\b")
                .matcher(text).find()) {
            return true;
        }
        try {
            UsaVerificationService.Verdict verdict = usaVerificationService.verify(text);
            return UsaVerificationService.STATUS_US.equals(verdict.getStatus());
        } catch (Exception e) {
            logger.debug("USA verification failed for UNKNOWN-location fallback: {}",
                    e.getMessage());
            return false;
        }
    }

    /**
     * Buyer-search FULL verification as FOUR independent gates. Each gate can
     * only reject; no gate passes another, and no single gate can push a
     * candidate to a final accept on its own (requirement 1):
     *   GATE 1  PRODUCT RELEVANCE   - the candidate deals in one of the
     *                                  USER'S ENTERED product families
     *                                  (product-name check; canonical input only,
     *                                  related-category alone never accepts).
     *   GATE 2  COMMERCIAL PRODUCT EVIDENCE - the buyer's OWN website (or its
     *                                  product-named URL) really offers the
     *                                  product for sale - a product page /
     *                                  collection / catalogue / shop with
     *                                  store/selling or commerce evidence.
     *                                  A search-snippet mention is NEVER
     *                                  commercial evidence (the engine echoes
     *                                  the queried words). Government sites and
     *                                  article/blog/news/content pages (e.g.
     *                                  NaturalNews-style) are also rejected here.
     *   GATE 3  BUSINESS TYPE       - classification + whitelist. A literal
     *                                  "buyer" word is NOT required; retailer/
     *                                  wholesaler/distributor/importer/dealer/
     *                                  supplier/trading/B2B are all valid. A
     *                                  service-only business (no store/selling on
     *                                  its own site) and clearly non-buyer
     *                                  business types are rejected.
     *   GATE 4  LOCATION CLASS      - classifies the business into EXACT_CITY >
     *                                  SAME_STATE (both only reachable when the
     *                                  business is verified in the requested
     *                                  city/state) > SAME_COUNTRY (country-wide
     *                                  searches only). A confirmed non-US
     *                                  location, or a business NOT verified in a
     *                                  requested city/state, is rejected - a
     *                                  business from ANOTHER state is never accepted
     *                                  just for sharing the country (requirements
     *                                  1/2/3); breadth for a city/state search is
     *                                  geographic within the requested region only.
     *                                  Location priority also ranks results.
     * A single structured FINAL VERDICT (requirement 10) reports what each gate
     * found and, on rejection, ONE clear reason. A candidate becomes a FINAL
     * buyer only when ALL four gates plus the dedup checks pass (requirement 8).
     */
    private boolean isRelevantBuyer(BuyerSearchResult result, Map<String, String> homepageCache,
                                    SearchTally tally) {
        String evidence = buildEvidence(result);
        String homepage = homepageCache.computeIfAbsent(result.getWebsite(),
                w -> emailDiscoveryService.fetchHomepage(w));

        // Gates may read the search-listing evidence (the candidate's OWN title/
        // snippet) and the buyer's actual homepage - never the fired query text.
        String fullText = buildRawText(evidence, homepage);
        String homeText = prepareText(homepage);
        String titleText = prepareText(result.getRawTitle());
        String snippetText = prepareText(result.getSnippet());
        String path = shopPathText(result.getWebsite());
        String domain = domainEvidence(result.getWebsite());
        String productLabel = result.getProductName() != null && !result.getProductName().isBlank()
                ? result.getProductName() : effectiveSearchProduct(result);

        String matchType = "none";
        String commercialEvidence = "none";
        String businessEvidence = "none";
        String locationEvidence = "none";
        String rejectionReason = null;

        // ---- GATE 1 - PRODUCT RELEVANCE ----
        // The user's entered product family is canonical; search variants
        // (tibetan/himalayan/crystal/meditation/sound-healing bowls) are only
        // discovery - matching a variant is never a rejection (requirement 2).
        String qualification = isRelevantToEnteredProduct(result, homepage);
        boolean urlProductEvidence = hasWebsiteUrlProductEvidence(result);
        if (homepage == null || homepage.isBlank()) {
            // When the actual website cannot be crawled at all, the "never verify
            // a buyer on a snippet keyword alone" rule still holds: a snippet
            // phrase merely echoes the queried terms and is NOT acceptable product
            // evidence. The candidate is kept for the remaining gates ONLY on
            // NON-snippet evidence - its own listing headline (title) or a product
            // phrase in its own URL path/domain - so product/commerce/location are
            // still checked on the search-result surface before any save.
            boolean listingAnchorProof = urlProductEvidence
                    || hasListingAnchorProductPhrase(result);
            logger.info("WEBSITE_UNAVAILABLE | buyer='{}' | website={} | "
                            + "URL/TITLE_PRODUCT_EVIDENCE: {}",
                    result.getCompanyName(), result.getWebsite(),
                    listingAnchorProof
                            ? "product phrase in the listing headline/URL (snippet-only evidence is not accepted)"
                            : "none (snippet keywords and URL-alone echoes are not accepted)");
            if (!listingAnchorProof) {
                logger.info("{} '{}' ({}) - website unavailable and no non-snippet product "
                                + "evidence (headline/URL product evidence absent)",
                        CODE_WRONG_PRODUCT, result.getCompanyName(), result.getWebsite());
                rejectionReason = "website unavailable and no non-snippet product evidence";
                tally.productRejects.incrementAndGet();
                logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                        businessEvidence, locationEvidence, rejectionReason);
                return false;
            }
            logger.info("VERIFICATION_UNAVAILABLE for '{}' ({}) - accepted on "
                            + "URL/TITLE product evidence (product phrase in the listing headline/URL)",
                    result.getCompanyName(), result.getWebsite());
            if (qualification == null) {
                qualification = QUAL_PRODUCT_RELEVANT;
            }
        } else if (qualification == null) {
            // Strict product gate: the candidate must genuinely deal in one of
            // the USER'S ENTERED product families. A candidate is rejected only
            // here when NO canonical or approved variant phrase appears in the
            // candidate listing NOR on the website (requirement 2/7).
            logger.info("{} '{}' ({}) - not relevant to any entered product family "
                            + "(no canonical or variant phrase in the candidate or website evidence)",
                    CODE_WRONG_PRODUCT, result.getCompanyName(), result.getWebsite());
            rejectionReason = "not relevant to any entered product family";
            tally.productRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }
        matchType = matchTypeLabelOf(qualification);

        // ---- GATE 2 - COMMERCIAL PRODUCT EVIDENCE (REJECTING) ----
        // The buyer's OWN website (or its product-named URL) must really offer
        // the product for sale: a shopping URL path, a product-named URL/domain,
        // store/selling evidence on the website, or a commerce sentence on the
        // website. A word echoed in the search LISTING is never commercial
        // evidence - the engine only repeats the queried terms. Government sites
        // and article/blog/news/content pages (NaturalNews-style) are never
        // buyers and are rejected here, not allowed in by snippet echoes.
        commercialEvidence = commercialProductEvidenceOf(result, fullText, titleText, snippetText,
                homeText, path);
        String websiteHost = hostOf(result.getWebsite());
        String websiteHostL = websiteHost == null ? "" : websiteHost;
        boolean governmentSite = websiteHostL.matches("(?i).*\\.gov(\\.[a-z]{2})?$")
                || websiteHostL.endsWith(".mil") || path.contains("/gov")
                || titleText.contains("department of") || titleText.contains("ministry of")
                || titleText.contains("official website of");
        if (governmentSite) {
            logger.info("{} '{}' ({}) - government website is never a buyer",
                    CODE_NO_BUYER_INTENT, result.getCompanyName(), result.getWebsite());
            rejectionReason = "government website is not a buyer";
            tally.contentRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }
        boolean contentArticleSite = isArticleLike(websiteHostL, path, titleText);
        if (contentArticleSite) {
            logger.info("{} '{}' ({}) - article/blog/news/content page is never a buyer",
                    CODE_NO_BUYER_INTENT, result.getCompanyName(), result.getWebsite());
            rejectionReason = "article/blog/news/content page is not a buyer";
            tally.contentRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }
        if (commercialEvidence == null) {
            logger.info("{} '{}' ({}) - no commercial product evidence on the business's own "
                            + "website (product page/collection/catalogue/shop) "
                            + "- a search-snippet mention is not commercial evidence",
                    CODE_NO_PRODUCT_COMMERCE_EVIDENCE, result.getCompanyName(), result.getWebsite());
            rejectionReason = "no commercial product evidence on the buyer's own website "
                    + "(snippet mentions are not commercial evidence)";
            tally.commercialRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }

        // ---- GATE 3 - BUSINESS TYPE (whitelist) ----
        // A literal "buyer" word is NOT required (retailer/wholesaler/distributor/
        // importer/dealer/supplier/trading/B2B are all valid). A SERVICE-only
        // business - a practice that uses the product (spa/classes/retreats/
        // events/workshops) with NO store/selling evidence on its own website -
        // is not a buyer and is rejected. The same business that ALSO runs a
        // store/product catalogue IS accepted (it buys stock).
        businessEvidence = businessTypeEvidenceOf(fullText, path, domain);
        String businessType = businessTypeFromEvidence(fullText, path, domain);
        boolean serviceOnlyActivity = hasServiceOnlyActivity(titleText, snippetText, homeText);
        boolean siteStoreSelling = hasStoreSellingEvidence("", "", homeText, path);
        if (serviceOnlyActivity && !siteStoreSelling) {
            logger.info("{} '{}' ({}) - service-only business (spa/class/workshop/retreat/event) "
                            + "with no store/product catalogue on its own website is not a product buyer",
                    CODE_NO_BUYER_INTENT, result.getCompanyName(), result.getWebsite());
            rejectionReason = "service-only business - no store/product catalogue on its own website";
            tally.businessTypeRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }

        // ---- GATE 4 - LOCATION CLASS (REJECTS a business outside the
        // requested city/state; SAME_COUNTRY is reserved for truly country-wide
        // searches) ----
        // A confirmed non-US location, or a location the country gate cannot
        // confirm as the requested country, is a location reject. For a search
        // constrained to a requested city and/or state, a business whose OWN
        // verified address is a DIFFERENT city/state (or whose state cannot be
        // confirmed) is NEVER accepted just because it shares the requested
        // country - SAME_COUNTRY no longer exists for a constrained search
        // (requirement 1/3). Only EXACT_CITY and a verified SAME_STATE are
        // accepted for a city/state search; a country-wide search (no city, no
        // state) keeps the reliable-USA SAME_COUNTRY class.
        if (hasNonUsBusinessLocationSignal(fullText) || hasForeignTld(result.getWebsite())
                || hasForeignHostSignal(result.getWebsite(), fullText)) {
            locationEvidence = "non-US country/address/ccTLD signal";
            rejectionReason = "non-US location detected";
            tally.locationRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }
        if (!isCountryRelevant(result.getCountry(), evidence, homepage)) {
            locationEvidence = "not located in requested country "
                    + (result.getCountry() != null ? result.getCountry() : "USA");
            rejectionReason = "not located in the requested country";
            tally.locationRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }
        boolean cityRequested = result.getCity() != null && !result.getCity().isBlank();
        boolean stateRequested = result.getState() != null && !result.getState().isBlank();
        // The multi-source OFFICIAL extraction (Google/Firecrawl business
        // metadata, homepage schema/footer/body, then contact/about pages) is
        // the ONLY source for the business's ACTUAL city/state - never the
        // search listing title/snippet, never invented.
        ExtractedLocation resolvedLocation = resolveBusinessLocationFrom(result.getWebsite(),
                result.getSearchAddress(), homepage);
        String locationClass;
        if (resolvedLocation != null && resolvedLocation.city != null
                && cityRequested && sameCity(resolvedLocation.city, result.getCity())) {
            // The business's OWN verified address is the requested city.
            locationClass = LOCATION_CLASS_EXACT_CITY;
        } else if (resolvedLocation != null && resolvedLocation.state != null
                && stateRequested && sameState(resolvedLocation.state, result.getState())) {
            // A supported SAME-STATE result (the one broadening the city/state
            // search phase targets) - the business is verified in the REQUESTED
            // state, never in a random state.
            locationClass = LOCATION_CLASS_SAME_STATE;
        } else if (!cityRequested && !stateRequested) {
            // No city/state constraint at all (country-wide search): any
            // reliable USA/Canada location is accepted and only ranked by
            // country priority.
            if (!(hasReliableUsEvidence(fullText) || resolvedLocation != null)) {
                locationEvidence = "region unconfirmed and no reliable USA evidence";
                rejectionReason = "location could not be confirmed as USA";
                tally.locationRejects.incrementAndGet();
                logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                        businessEvidence, locationEvidence, rejectionReason);
                return false;
            }
            locationClass = LOCATION_CLASS_SAME_COUNTRY;
        } else {
            // A specific city and/or state was requested, but this business's
            // verified address is a different city/state (or the state could not
            // be confirmed). Out-of-region businesses are never accepted just
            // because they share the country with the requested region.
            String verifiedCity = resolvedLocation != null && resolvedLocation.city != null
                    ? resolvedLocation.city : "unknown city";
            String verifiedState = resolvedLocation != null && resolvedLocation.state != null
                    ? resolvedLocation.state : "unknown state";
            if (cityRequested && stateRequested) {
                locationEvidence = "business not verified in requested city '" + result.getCity()
                        + "', " + result.getState() + " (verified: " + verifiedCity + ", "
                        + verifiedState + ")";
            } else if (cityRequested) {
                locationEvidence = "business not verified in requested city '" + result.getCity()
                        + "' (verified: " + verifiedCity + ", " + verifiedState + ")";
            } else {
                locationEvidence = "business not verified in requested state '" + result.getState()
                        + "' (verified: " + verifiedState + ")";
            }
            rejectionReason = "business not located in the requested city/state";
            tally.locationRejects.incrementAndGet();
            logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                    businessEvidence, locationEvidence, rejectionReason);
            return false;
        }

        // ---- FINAL DECISION - all four independent gates passed ----
        result.setClassification(businessType);
        result.setBusinessType(businessType);
        result.setLocationClass(locationClass);
        result.setRelevanceScore(relevanceScoreOf(matchType, commercialEvidence, businessType));
        logger.info("Classified '{}' ({}) as '{}' from site evidence [{}]",
                result.getCompanyName(), result.getWebsite(), businessType, locationClass);

        if (resolvedLocation != null) {
            applyExtractedLocation(result, resolvedLocation);
        } else {
            resolveBusinessLocation(result, evidence, homepage);
        }
        if (result.getBuyerName() == null) {
            String name = extractBusinessName(result, effectiveSearchProduct(result));
            if (name != null) {
                result.setCompanyName(name);
                result.setBuyerName(name);
            }
        }
        locationEvidence = (locationClass != null ? locationClass : "UNKNOWN")
                + " - " + (result.getLocation() != null ? result.getLocation() : "unknown")
                + (resolvedLocation != null && resolvedLocation.source != null
                        ? " (source: " + resolvedLocation.source + ")" : "");
        logFinalVerdict(result, productLabel, matchType, commercialEvidence,
                businessEvidence, locationEvidence, null);
        logger.info("ACCEPTED '{}' ({}) - relevant to '{}' in {}/{} [{}={}]",
                result.getCompanyName(), result.getWebsite(),
                effectiveSearchProduct(result),
                result.getState() != null ? result.getState() : "any",
                result.getCity() != null ? result.getCity() : "any",
                locationClass != null ? locationClass : "UNKNOWN",
                result.getClassification() != null ? result.getClassification() : "BUYER");
        return true;
    }

    /** Evidence-strength score used to order results with the SAME location
     *  priority higher (product-match tier, real commerce, clear business
     *  type). Location priority always dominates; this only breaks ties. */
    private int relevanceScoreOf(String matchType, String commercialEvidence, String businessType) {
        int score = 0;
        if (matchType != null) {
            if (matchType.startsWith("EXACT")
                    || matchType.contains("VALID_VARIANT") || matchType.contains("ATTRIBUTE")) {
                score += 4;
            } else if (matchType.contains("STORE/SELLER")) {
                score += 3;
            } else if (matchType.contains("LISTING") || matchType.contains("SEARCH_RESULT")) {
                score += 2;
            } else if (matchType.contains("RELATED")) {
                score += 1;
            }
        }
        if (commercialEvidence != null && commercialEvidence.contains("website")) {
            score += 2;
        }
        if (businessType != null && !CLASSIFICATION_OTHER.equals(businessType)) {
            score += 1;
        }
        return score;
    }

    /** Maps the product-match tier of GATE 1 to a human description. */
    private String matchTypeLabelOf(String qualification) {
        if (qualification == null) {
            return "none";
        }
        switch (qualification) {
            case QUAL_PRODUCT_RELEVANT:
                return "SEARCH_RESULT_PRODUCT_EVIDENCE (website unavailable - strong product phrase in the candidate listing)";
            case QUAL_PRODUCT_LISTING:
                return "LISTING (canonical/variant product phrase in the candidate listing; "
                        + "website text could not independently re-confirm it - VERIFICATION_UNAVAILABLE)";
            case QUAL_DIRECT_PRODUCT_BUYER:
                return "EXACT/VALID_VARIANT/ATTRIBUTE_MATCH (attribute-preserving product phrase on the website)";
            case QUAL_RELATED_CATEGORY_BUYER:
                return "RELATED (related-category store, product not named)";
            case QUAL_POTENTIAL_WHOLESALE_BUYER:
                return "STORE/SELLER (wholesale-related or selling/store evidence)";
            case QUAL_POTENTIAL_RETAIL_BUYER:
                return "STORE/SELLER (selling/store evidence on the website)";
            default:
                return qualification;
        }
    }

    /**
     * GATE 2 evidence: proves the website REALLY offers the product for sale.
     * A shopping URL path, a product-named URL/domain, store/selling evidence
     * or a commerce sentence (sell/buy/price/wholesale/catalog) ON THE WEBSITE
     * satisfies it. A word echoed in the search LISTING is NEVER commercial
     * evidence - the engine repeats the queried terms, so a snippet mention
     * alone never proves the business sells anything (requirement 5).
     * Returns null when the site shows no real commerce at all (article/service).
     */
    private String commercialProductEvidenceOf(BuyerSearchResult result, String fullText,
                                              String titleText, String snippetText,
                                              String homeText, String path) {
        List<String> parts = new ArrayList<>();
        boolean strongCommerce = isShoppingPath(path) || hasWebsiteUrlProductEvidence(result);
        if (isShoppingPath(path)) {
            parts.add("shopping URL path");
        }
        if (hasWebsiteUrlProductEvidence(result)) {
            parts.add("product named in the URL/domain");
        }
        boolean siteStoreSelling = hasStoreSellingEvidence("", "", homeText, path);
        if (siteStoreSelling) {
            parts.add("store/selling evidence on the website");
        }
        if (parts.isEmpty() && !homeText.isBlank()
                && hasCommerceSignalText(prepareText(homeText, path))) {
            parts.add("commerce sentence on the website");
        }
        // CONTENT-SITE GUARD (requirement 5): store/selling markers and commerce
        // sentences on an ARTICLE/BLOG/MEDIA page (a podcast with a merch shop,
        // a magazine with a shop) never prove the business SELLS the requested
        // product. When there is no shopping URL and no product-named URL/domain,
        // the commerce signal must be backed by the PRODUCT ITSELF - a commerce
        // signal must read next to the product phrase on the website.
        if (!strongCommerce && !hasCommerceNearProductPhrase(result, homeText)) {
            return null;
        }
        return parts.isEmpty() ? null : String.join(", ", parts);
    }

    /** TRUE when a COMMERCE_SIGNAL token sits within a short window of the
     *  product phrase ON THE WEBSITE (homepage text) - the evidence that the
     *  business really offers the product for sale, unlike a page that merely
     *  discusses it (requirement 5). */
    private boolean hasCommerceNearProductPhrase(BuyerSearchResult result, String homeText) {
        if (homeText == null || homeText.isBlank()) {
            return false;
        }
        String product = effectiveSearchProduct(result);
        if (product == null || product.isBlank()) {
            return false;
        }
        String site = prepareText(homeText);
        String phrase = " " + product.trim().toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", " ") + " ";
        if (site.length() < phrase.length()) {
            return false;
        }
        int window = 260;
        int from = 0;
        while (true) {
            int idx = site.indexOf(phrase, from);
            if (idx < 0) {
                return false;
            }
            int start = Math.max(0, idx - window);
            int end = Math.min(site.length(), idx + phrase.length() + window);
            String near = site.substring(start, end);
            for (String token : COMMERCE_SIGNAL_PHRASES) {
                if (containsToken(near, token)) {
                    return true;
                }
            }
            from = idx + phrase.length();
        }
    }

    /** TRUE when the prepared text contains any commerce signal phrase. */
    private boolean hasCommerceSignalText(String text) {
        if (text == null || text.isBlank()) {
            return false;
        }
        for (String signal : COMMERCE_SIGNAL_PHRASES) {
            if (containsPhrase(text, signal)) {
                return true;
            }
        }
        return false;
    }

    /** GATE 3 evidence: the business-type words actually expressed. */
    private String businessTypeEvidenceOf(String fullText, String path, String domain) {
        String text = prepareText(fullText);
        List<String> hits = new ArrayList<>();
        for (String word : BUSINESS_TYPE_WORDS) {
            if (containsToken(text, word) && !hits.contains(word)) {
                hits.add(word);
            }
        }
        for (String phrase : BUSINESS_TYPE_PHRASES) {
            if (containsPhrase(text, phrase) && !hits.contains(phrase)) {
                hits.add(phrase);
            }
        }
        // URL/path can carry a business-type word too (e.g. /shop, a *-store.com
        // domain such as soundjourneystore.com) - evidence, never the query.
        if ((path != null && !path.isBlank()) || (domain != null && !domain.isBlank())) {
            String urlText = (path == null ? "" : path) + " " + (domain == null ? "" : domain);
            for (String word : BUSINESS_TYPE_WORDS) {
                if (containsPhrase(urlText, word) && !hits.contains(word)) {
                    hits.add(word);
                }
            }
        }
        return hits.isEmpty() ? null : String.join(", ", hits);
    }

    /** GATE 3 classification: a role the page states, else a business-type
     *  signal actually expressed, else OTHER - never an invented role. */
    private String businessTypeFromEvidence(String fullText, String path, String domain) {
        String role = classifyBusinessTypeFromEvidence(fullText);
        if (role != null) {
            return role;
        }
        String text = prepareText(fullText) + " "
                + (path == null ? "" : path) + " " + (domain == null ? "" : domain);
        if (containsPhrase(text, "wholesale")
                || containsToken(text, "wholesaler") || containsToken(text, "wholesalers")) {
            return "Wholesaler";
        }
        if (containsToken(text, "distributor") || containsToken(text, "distributors")
                || containsPhrase(text, "distribution")) {
            return "Distributor";
        }
        if (containsToken(text, "importer") || containsToken(text, "importers")
                || containsPhrase(text, "importing")) {
            return "Importer";
        }
        if (containsToken(text, "supplier") || containsToken(text, "suppliers")
                || containsToken(text, "vendor") || containsToken(text, "vendors")
                || containsPhrase(text, "supplying") || containsPhrase(text, "trading company")
                || containsPhrase(text, "sourcing") || containsPhrase(text, "procurement")
                || containsPhrase(text, "b2b")) {
            return "Supplier";
        }
        if (containsToken(text, "dealer") || containsToken(text, "dealers")
                || containsPhrase(text, "dealership")) {
            return "Buyer";
        }
        if (containsToken(text, "retailer") || containsToken(text, "retailers")
                || containsToken(text, "retail") || containsToken(text, "store")
                || containsToken(text, "stores") || containsToken(text, "shop")
                || containsPhrase(text, "boutique") || containsPhrase(text, "storefront")) {
            return "Retailer";
        }
        return CLASSIFICATION_OTHER;
    }

    /** The single structured verdict for GATE 1-4 results (requirement 10). */
    private void logFinalVerdict(BuyerSearchResult result, String product, String matchType,
                                 String commercialEvidence, String businessEvidence,
                                 String locationEvidence, String rejectionReason) {
        logger.info("FINAL VERDICT | DOMAIN: {} | PRODUCT: '{}' | MATCH TYPE: {} | "
                        + "COMMERCIAL EVIDENCE: {} | BUSINESS EVIDENCE: {} | LOCATION EVIDENCE: {} | "
                        + "FINAL DECISION: {} | REJECTION REASON: {}",
                result.getWebsite(), product,
                matchType == null ? "none" : matchType,
                commercialEvidence == null ? "none" : commercialEvidence,
                businessEvidence == null ? "none" : businessEvidence,
                locationEvidence == null ? "none" : locationEvidence,
                rejectionReason == null ? "ACCEPT" : "REJECT",
                rejectionReason == null ? "(none)" : rejectionReason);
    }

    // The effective product phrasing this result must be verified against: the
    // actual searched synonym when one was used, otherwise the original label.
    private String effectiveSearchProduct(BuyerSearchResult result) {
        String searchProduct = result.getSearchProduct();
        return searchProduct != null && !searchProduct.isBlank()
                ? searchProduct : result.getProductName();
    }

    private String buildEvidence(BuyerSearchResult result) {
        // companyName holds the cleaned business name; the original Firecrawl
        // title (which carries the product terms) is kept in rawTitle so product
        // relevance checks still cover what the search engine actually returned.
        String title = result.getRawTitle() != null ? result.getRawTitle() : result.getCompanyName();
        return (title == null ? "" : title)
                + " | " + (result.getSnippet() == null ? "" : result.getSnippet());
    }

    // Country relevance gate: USA and Canada searches share the same product-first
    // strategy but verify the requested country. USA uses the existing US
    // verification (Canada businesses remain accepted); Canada accepts
    // decisive Canadian signals, rejects decisive non-North-American signals
    // and US-located pages, and tolerates unknown like the US search does.
    private boolean isCountryRelevant(String country, String evidence, String homepageHtml) {
        if (country != null && country.equalsIgnoreCase("Canada")) {
            return isCanadaRelevant(evidence, homepageHtml);
        }
        return isUsRelevant(evidence, homepageHtml);
    }

    private boolean isCanadaRelevant(String evidence, String homepageHtml) {
        String evidenceText = buildRawText(evidence);
        if (!evidenceText.isBlank()) {
            if (hasNonUsBusinessLocationSignal(evidenceText)) {
                logger.debug("Text check REJECTED (Canada search): non-North-American signal in evidence");
                return false;
            }
            if (hasCanadaBusinessSignal(evidenceText)) {
                logger.debug("Text check ACCEPTED (Canada search): Canadian signal in evidence");
                return true;
            }
        }
        if (homepageHtml != null && !homepageHtml.isBlank()) {
            String homeText = buildRawText(homepageHtml);
            if (hasNonUsBusinessLocationSignal(homeText)) {
                logger.debug("Homepage check REJECTED (Canada search): non-North-American signal");
                return false;
            }
            if (hasCanadaBusinessSignal(homeText)) {
                logger.debug("Homepage check ACCEPTED (Canada search): Canadian signal");
                return true;
            }
            // A homepage that is decisively US-located is not a Canadian buyer.
            if (UsaVerificationService.STATUS_US
                    .equals(usaVerificationService.verify(homeText).getStatus())) {
                logger.debug("Homepage check REJECTED (Canada search): page is US-located");
                return false;
            }
        }
        logger.debug("ACCEPTED (Canada search) - no contradicting signals");
        return true;
    }

    private boolean isUsRelevant(String evidence, String homepageHtml) {
        UsaVerificationService.Verdict verdict = usaVerificationService.verify(evidence);
        if (UsaVerificationService.STATUS_NON_US.equals(verdict.getStatus())) {
            logger.debug("Text check REJECTED: {}", verdict.getReason());
            return false;
        }
        if (UsaVerificationService.STATUS_US.equals(verdict.getStatus())) {
            logger.debug("Text check ACCEPTED: {}", verdict.getReason());
            return true;
        }

        if (homepageHtml != null && !homepageHtml.isBlank()) {
            verdict = usaVerificationService.verify(homepageHtml);
            if (UsaVerificationService.STATUS_NON_US.equals(verdict.getStatus())) {
                logger.debug("Homepage check REJECTED: {}", verdict.getReason());
                return false;
            }
            if (UsaVerificationService.STATUS_US.equals(verdict.getStatus())) {
                logger.debug("Homepage check ACCEPTED: {}", verdict.getReason());
                return true;
            }
        }

        logger.debug("ACCEPTED - no contradicting signals in US-targeted search");
        return true;
    }

    /**
     * Decisive non-US business-location signal, detected on the RAW text
     * (punctuation/pipes preserved so ", India" tails and +phone prefixes still
     * parse): explicit country words, ", Country" address tails, "based/located
     * in <country>" phrases, pvt ltd / private limited suffixes, foreign phone
     * prefixes and non-US postal codes. Import-source mentions ("imports from
     * India", "made in China") are stripped first so a US importer that names
     * its foreign sources is never flagged.
     */
    private boolean hasNonUsBusinessLocationSignal(String rawText) {
        if (rawText == null || rawText.isBlank()) {
            return false;
        }
        String text = rawText.replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim();
        String stripped = text
                .replaceAll("(?i)\\b(?:imports?|imported|importing|export|exports|exporting|"
                        + "sourced|source|shipped|shipping|ship|ships|manufactured|manufacture|"
                        + "made|originating|produced)\\b[^.,;!?]{0,40}\\b(?:to|from|out of|in)\\s+"
                        + "(?:" + FOREIGN_COUNTRY_ALTERNATION + ")\\b", " ")
                .replaceAll("\\s+", " ").trim();

        String strippedLower = stripped.toLowerCase();
        for (String country : DECISIVE_FOREIGN_WORDS) {
            if (containsToken(strippedLower, country)) {
                logger.debug("Non-US country/destination word '{}' found", country);
                return true;
            }
        }
        if (Pattern.compile(",\\s*(?:" + FOREIGN_COUNTRY_ALTERNATION + ")\\b",
                Pattern.CASE_INSENSITIVE).matcher(text).find()) {
            logger.debug("Non-US ', Country' address tail found");
            return true;
        }
        if (Pattern.compile("\\b(?:based|located|headquartered|situated|operating|operates|"
                        + "established)\\b[^.,;!?]{0,40}\\bin\\s+(?:the\\s+)?"
                        + "(?:" + FOREIGN_COUNTRY_ALTERNATION + ")\\b",
                Pattern.CASE_INSENSITIVE).matcher(text).find()) {
            logger.debug("Non-US 'based/located in' phrase found");
            return true;
        }
        if (Pattern.compile("(?i)\\b(?:pvt\\.?\\s*ltd|private\\s+limited|private\\s+ltd)\\b")
                .matcher(text).find()) {
            logger.debug("Non-US corporate suffix found");
            return true;
        }
        if (Pattern.compile("\\+(?:91|92|94|880|971|966|974|973|968|44|61|65|60|66|84|55|52|"
                        + "64|81|86|49|33|34|39|31|32|43|41|46|47|48|7|90|98|63)\\s?[\\d(]")
                .matcher(text).find()) {
            logger.debug("Foreign phone prefix found");
            return true;
        }
        if (Pattern.compile(",\\s*[1-9]\\d{5}\\b|\\bpin[\\s-]*code\\b",
                Pattern.CASE_INSENSITIVE).matcher(text).find()) {
            logger.debug("Non-US postal/PIN code found");
            return true;
        }
        return false;
    }

    /** True when the domain ends in a country code TLD. Only a contributing
     *  signal - a decisive non-US text signal is required elsewhere; the TLD is
     *  never the sole reason a result is judged non-US. */
    private boolean hasForeignTld(String website) {
        String host = hostOf(website);
        if (host == null) {
            return false;
        }
        int lastDot = host.lastIndexOf('.');
        if (lastDot < 0 || lastDot == host.length() - 1) {
            return false;
        }
        String tld = host.substring(lastDot + 1);
        if (!tld.matches("[a-z]{2}")) {
            return false;
        }
        return FOREIGN_CCTLDS.contains(tld);
    }

    /**
     * True when the domain hostname contains an unambiguous foreign-country
     * word (e.g. "czechchandeliers.com"). A USA/Canada business that shows a
     * real "City, ST ZIP" / "City, ST" / "ST ZIP" / Canadian-postal address on
     * its own page is trusted as a local brand; without such address evidence
     * the business is treated as foreign so a German/Czech/Italian-looking
     * site is never saved as a USA buyer.
     */
    private boolean hasForeignHostSignal(String website, String rawText) {
        String host = hostOf(website);
        if (host == null) {
            return false;
        }
        String hostLower = host;
        boolean flagged = false;
        for (String word : FOREIGN_HOST_WORDS) {
            if (hostLower.contains(word)) {
                flagged = true;
                break;
            }
        }
        if (!flagged) {
            return false;
        }
        return !hasPostalOrCityStateAddress(buildRawText(rawText));
    }

    private boolean hasPostalOrCityStateAddress(String rawText) {
        if (rawText == null || rawText.isBlank()) {
            return false;
        }
        return CITY_STATE_ZIP_PATTERN.matcher(rawText).find()
                || CITY_STATE_PATTERN.matcher(rawText).find()
                || STATE_ZIP_PATTERN.matcher(rawText).find()
                || CITY_FULL_STATE_PATTERN.matcher(rawText).find()
                || CANADA_POSTAL_PATTERN.matcher(rawText).find();
    }

    /**
     * True when the raw text asserts a US state other than the requested one:
     * either a conflicting full state name (token match) or a conflicting
     * "City, XX" / "XX <zip>" address abbreviation.
     */
    private boolean hasConflictingStateSignal(String rawText, String expectedStateLower) {
        if (expectedStateLower == null || rawText == null) {
            return false;
        }
        if (hasConflictingState(prepareText(rawText), expectedStateLower)) {
            return true;
        }
        String expectedAbbrev = STATE_ABBREVIATIONS.get(expectedStateLower);
        for (Map.Entry<String, String> entry : STATE_ABBREVIATIONS.entrySet()) {
            String abbrev = entry.getValue();
            if (abbrev.equals(expectedAbbrev)) {
                continue;
            }
            if (containsStateAbbrevAddress(rawText, abbrev)) {
                logger.debug("Conflicting state abbreviation '{}' found in address", abbrev);
                return true;
            }
        }
        return false;
    }

    /**
     * CONDITION 3 - buyer intent. True when the text clearly describes a
     * business that buys/sells the product as an importer, distributor,
     * wholesaler, retailer, dealer, buyer or sourcing company (or an equivalent
     * trading / stockist / supplier / vendor role). A page that merely names the
     * product - or a generic import/export company that never names the product
     * - never proves intent on its own.
     */
    private boolean hasBuyerIntent(String... parts) {
        String text = prepareText(parts);
        if (text.isBlank()) {
            return false;
        }
        for (String word : BUYER_INTENT_WORDS) {
            if (containsToken(text, word)) {
                return true;
            }
        }
        return false;
    }

    // Role evidence ranks from the clearest B2B statements down to retail /
    // dealer / buyer wording. The FIRST role the page actually expresses
    // decides its business type; the role word in the fired query is never
    // evidence by itself. Row 0 holds the business-type label, the rest are the
    // page-text signals that express it.
    private static final String[][] ROLE_SIGNALS = {
        new String[]{"Importer", "importer", "importers", "importing",
                "imported", "we import"},
        new String[]{"Distributor", "distributor", "distributors",
                "distributing", "distribution", "authorized distributor"},
        new String[]{"Wholesaler", "wholesaler", "wholesalers", "wholesale",
                "wholesaling"},
        new String[]{"Supplier", "supplier", "suppliers", "supplying",
                "supplies"},
        new String[]{"Dealer", "dealer", "dealers", "dealership"},
        new String[]{"Retailer", "retailer", "retailers", "retailing",
                "retail", "retail store", "gift shop", "boutique"},
        new String[]{"Bulk Buyer", "bulk", "bulk orders", "bulk pricing"},
        new String[]{"Buyer", "buyer", "buyers", "buying", "we buy",
                "purchasing"}
    };

    /**
     * Classifies the buyer from the page's OWN role statements (importer >
     * distributor > wholesaler > supplier > dealer > retailer > bulk > buyer):
     * a gift shop found through a "distributor" query is only classified
     * Distributor if its page says so. Returns null when the page states no
     * role at all - callers then fall back to a neutral label instead of
     * assigning one from the query.
     */
    private String classifyBusinessTypeFromEvidence(String fullText) {
        if (fullText == null || fullText.isBlank()) {
            return null;
        }
        String text = prepareText(fullText);
        for (String[] signal : ROLE_SIGNALS) {
            String label = signal[0];
            for (int i = 1; i < signal.length; i++) {
                if (containsPhrase(text, signal[i])) {
                    return label;
                }
            }
        }
        return null;
    }

    /**
     * Trade-data / import-export record & analytics portals (OEC, Panjiva,
     * Volza, Trademap, ImportGenius, customs/shipment data...) publish statistics
     * about shipments - they do not buy the product, so they are not buyers.
     */
    private boolean isTradeDataPage(String url, String title) {
        String host = hostOf(url);
        if (host != null) {
            for (String part : TRADE_DATA_HOST_PARTS) {
                if (host.contains(part)) {
                    return true;
                }
            }
        }
        if (title != null) {
            String t = title.toLowerCase();
            for (String marker : TRADE_DATA_TITLE_MARKERS) {
                if (t.contains(marker)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Strict acceptance gate: returns the buyer-qualification tier when the
     * candidate is genuinely relevant to at least one of the USER'S ENTERED
     * products (or null when it is not). The internal synonym phrase that
     * actually retrieved the result ("home decor", "meditation bowls", ...) is
     * never accepted on its own - so a generic home-decor business is never
     * returned for a specific "Crystal Singing Bowls" search. Every entered
     * product is verified with the same phrase-based gate used by the cheap
     * screen.
     */
    private String isRelevantToEnteredProduct(BuyerSearchResult result, String homepageHtml) {
        List<String> enteredProducts = parseCommaSeparated(result.getProductName());
        if (enteredProducts.isEmpty()) {
            // No product to verify against - nothing can be proven relevant.
            return null;
        }
        for (String product : enteredProducts) {
            String qualification = isProductRelevant(result.getRawTitle(), result.getSnippet(),
                    result.getWebsite(), homepageHtml, product,
                    result.getSearchQuery() != null && !result.getSearchQuery().isBlank()
                            ? result.getSearchQuery()
                            : result.getSearchProduct());
            if (qualification != null) {
                return qualification;
            }
        }
        return null;
    }

    /**
     * Non-snippet listing product evidence for a website-unavailable candidate:
     * a canonical or approved variant phrase of one of the USER'S ENTERED
     * products in the listing HEADLINE (title) or in the business URL path/
     * domain - the SNIPPET is deliberately excluded, since it merely echoes the
     * queried terms and must never stand as product evidence on its own
     * (requirement: a buyer is never verified on a snippet keyword).
     */
    private boolean hasListingAnchorProductPhrase(BuyerSearchResult result) {
        List<String> enteredProducts = parseCommaSeparated(result.getProductName());
        if (enteredProducts.isEmpty()) {
            return false;
        }
        String titleText = prepareText(result.getRawTitle());
        String path = shopPathText(result.getWebsite());
        String domain = domainEvidence(result.getWebsite());
        for (String product : enteredProducts) {
            String p = normalizeProductForValidation(product);
            ProductSpec spec = buildProductSpec(p, new HashSet<>(tokenizeWords(p)));
            if (spec.strongPhrases.isEmpty()) {
                continue;
            }
            List<String> candidates = new ArrayList<>();
            candidates.add(p);
            for (String phrase : spec.strongPhrases) {
                if (!candidates.contains(phrase)) {
                    candidates.add(phrase);
                }
            }
            if (findFirstStrongPhrase(candidates, titleText, path, "", domain, "") != null) {
                return true;
            }
        }
        return false;
    }

    /**
     * Cheap-screen multi-product gate: TRUE when the search evidence (title +
     * snippet + URL, no homepage yet) is relevant to at least one of the
     * USER'S ENTERED products. Every product goes through the same
     * phrase-based gate as the stage-2 full-page verify - a result matching
     * only an internal synonym phrase is never accepted on its own.
     */
    private boolean isProductRelevantForAny(String title, String snippet, String website,
                                            String homepageHtml, List<String> products,
                                            String searchQuery) {
        if (products == null || products.isEmpty()) {
            return false;
        }
        for (String product : products) {
            if (isProductRelevant(title, snippet, website, homepageHtml, product, searchQuery) != null) {
                return true;
            }
        }
        return false;
    }

    /**
     * Product-family-aware relevance gate (cheap screen AND full-page verify).
     * Candidates are verified against the USER'S ENTERED product using these
     * levels and returns the buyer-qualification tier when accepted (null when
     * rejected):
     *   LEVEL 1  DIRECT  - a strong product phrase ("crystal candle holders")
     *                      in the title, shop URL, snippet, domain or homepage,
     *                      backed by physical-product/seller or store evidence.
     *                      A business identity ALONE never accepts (a sound-
     *                      healing academy that names the product but has no
     *                      shop is NOT a buyer).
     *   LEVEL 2  RELATED - a related-category store (meditation/spiritual/
     *                      wellness/metaphysical/gift/home-decor shop) that
     *                      plausibly carries the product, REQUIRING store/
     *                      selling evidence.
     *   LEVEL 3  GENERIC - a bare unrelated-category phrase ("home decor"
     *                      alone) never accepts.
     *   REJECT CONTEXTS   - a related-industry page (kitchen bowls / camping
     *                      lanterns / canning jars / candle-making supplies)
     *                      -> reject even with a loose family word.
     * Service-only businesses (spa/therapy/classes/workshops) are rejected
     * when the page has NO store/shop/catalogue evidence, even when they name
     * the product.
     */
    private String isProductRelevant(String title, String snippet, String website,
                                     String homepageHtml, String product, String searchQuery) {
        if (product == null || product.isBlank()) {
            return QUAL_DIRECT_PRODUCT_BUYER;
        }
        if (significantTerms(product).isEmpty()) {
            // A "product" made only of role words (wholesale / retailer /
            // distributor / importer) can never be verified on any page;
            // letting it pass would admit irrelevant businesses.
            logger.debug("PRODUCT RELEVANCE | REJECT '{}' - role-only product", product);
            return null;
        }
        String p = normalizeProductForValidation(product);
        ProductSpec spec = buildProductSpec(p, new HashSet<>(tokenizeWords(p)));
        if (spec.strongPhrases.isEmpty()) {
            // Unsupported product with no acceptance phrases: nothing can prove
            // it, so it is rejected here (the category gate already blocked it
            // before any Firecrawl request).
            return null;
        }

        // All zones are normalized the same way (lowercase, punctuation
        // collapsed, single-spaced) so hyphens/commas in the evidence never
        // break phrase matching.
        String titleText = prepareText(title);
        String snippetText = prepareText(snippet);
        String homeText = prepareText(homepageHtml);
        String path = shopPathText(website);
        String domain = domainEvidence(website);

        List<String> candidates = new ArrayList<>();
        candidates.add(p); // the user's exact entered phrasing is always a match
        for (String phrase : spec.strongPhrases) {
            if (!candidates.contains(phrase)) {
                candidates.add(phrase);
            }
        }

        // Related-industry contexts come from the SEARCH evidence
        // (title/snippet) only: a genuine candle company whose footer happens
        // to mention candle-making kits must not be rejected, but a
        // candle-making-supplies PAGE is.
        String reject = findRejectContext(spec.rejectContexts, prepareText(title, snippet));
        boolean searchScreenOnly = homepageHtml == null;

        // Jar/canister combination proof: a decorative-jar seller whose page is
        // worded differently (glass canisters, storage jars, apothecary jars,
        // kitchen canisters...) is relevant when a jar-family noun appears with
        // a product modifier AND business/local evidence. It is applied for any
        // jar-family synonym actually searched.
        boolean jarComboProof = isJarFamilyQuery(product)
                && reject == null
                && jarComboRelevant(titleText, snippetText, path, domain, homeText);
        // The same jar-family relaxation scoped to the website ITSELF (shopping
        // path / domain / homepage body) - used to exempt a genuine
        // differently-worded jar business from the query-echo rejection and to
        // demand store/selling evidence on the site for the full-page accept.
        boolean jarComboSiteProof = isJarFamilyQuery(product)
                && reject == null
                && jarComboRelevant("", "", path, domain, homeText == null ? "" : homeText);

        // The Level-1 phrase is computed up-front so the accessory/handle reject
        // logs below can already name it.
        String matched = findFirstStrongPhrase(candidates, titleText, path, snippetText, domain, homeText);

        // ---- ACCESSORY / CONSUMABLE GATE (cheap screen AND full page): a page
        // for the product's ACCESSORIES ("Singing Bowl Cushion", "Bowl Mallet",
        // "Box for Singing Bowls") sells the accessory, never the product, so it
        // is not a buyer of the product itself. Bowl-family heads run the
        // adjacency rule; every family additionally rejects the composed form
        // "<strong product phrase> <accessory>" ("candle holder bag"). A legit
        // "Candle Stand" product is never caught because only bowl heads trigger
        // the adjacency rule.
        String accessoryEvidence = findAccessoryEvidence(spec, p, titleText, snippetText,
                path, domain, homeText == null ? "" : homeText);
        if (accessoryEvidence != null) {
            logProductValidation(product, title, snippet, website, searchQuery,
                    "ACCESSORY-REJECT", matched, "none", "none", QUAL_NOT_A_BUYER,
                    "product accessory/consumable evidence '" + accessoryEvidence + "'");
            return null;
        }

        // ---- CUSTOMISED-JAR HANDLE GATE: a "Jars With Handle" product demands
        // handle evidence. When the user product carries "handle", a page that
        // clearly claims the jar/canister family but never shows a handle is
        // generic stock - not the searched product - and is rejected. A page
        // that does not claim the jar family at all is left to the (stricter)
        // strong-phrase gate below.
        boolean handleRequired = "jar".equals(spec.coreNoun) && p.contains("handle");
        if (handleRequired && jarFamilyMentioned(titleText, snippetText, path, domain)) {
            String handleEvidence = findHandleEvidence(titleText, snippetText, path, domain, homeText);
            if (handleEvidence == null) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "HANDLE-REJECT", matched, "none", "none", QUAL_NOT_A_BUYER,
                        "jar-family page with no 'handle' evidence for a 'jars with handle' product");
                return null;
            }
        }

        // Level-1 check: a strong product phrase (computed earlier so the
        // accessory/handle reject logs can name it).
        boolean matchedMultiWord = matched != null && matched.trim().contains(" ");

        String related = findFirstStrongPhrase(spec.relatedCategoryPhrases,
                titleText, path, snippetText, domain, homeText == null ? "" : homeText);
        // The strong product phrase re-scoped to the website ITSELF (shopping
        // URL path, domain, homepage body) - NEVER the search-listing title or
        // snippet, which merely echo the terms that were searched. A phrase
        // found only in the listing (sitePhrase == null) is no longer an
        // auto-reject: it marks the candidate VERIFICATION_UNAVAILABLE below so
        // the commercial/business/location gates still run (requirement 10/11).
        String sitePhrase = findFirstStrongPhrase(candidates, "", path, "",
                domain, homeText == null ? "" : homeText);

        // Base-category-only terms (e.g. a bare "lantern" / "glass lantern" page
        // for a "wall lantern" search): when the product has REQUIRED attributes,
        // category-only evidence labels the result GENERIC_CATEGORY_ONLY and is
        // rejected before any store/related fallthrough.
        String genericCategory = findFirstStrongPhrase(spec.genericCategoryTerms,
                titleText, path, snippetText, domain, homeText == null ? "" : homeText);

        // ---- CHEAP SCREEN (no homepage yet): a promising candidate is sent to
        // free homepage verification; strict store/service decisions happen on
        // the full page below so a real seller with a store is never dropped
        // before its homepage is seen.
        if (searchScreenOnly) {
            // The cheap screen decides ONLY product relevance for the search
            // listing: PRODUCT_RELEVANT -> send to homepage verification, or
            // nothing (NOT_PRODUCT_RELEVANT) -> reject. It NEVER emits a buyer
            // tier - a candidate is not a buyer until the commercial-evidence,
            // business-type and location gates all pass on the full page.
            boolean screenPassed = false;
            if (matched != null && (matchedMultiWord || reject == null)) {
                // Any strong product phrase ANYWHERE in the listing (title, URL,
                // snippet or domain) sends the candidate to free homepage
                // verification. The FINAL product decision is made on the official
                // website in GATE 1 - a snippet phrase alone is never enough to
                // SAVE a buyer - so the cheap screen must not drop a real seller
                // whose title/path simply lacks the product words.
                screenPassed = true;
            } else if (matched != null) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "LEVEL1-REJECT", matched, "none", "none", QUAL_NOT_A_BUYER,
                        "related-industry context '" + reject + "' overrides solo product word");
                return null;
            }
            if (matched == null && reject == null && genericCategory != null
                    && !spec.requiredAttributes.isEmpty()) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "GENERIC-CATEGORY-REJECT", genericCategory, "none", "none", QUAL_NOT_A_BUYER,
                        "MATCH TYPE: GENERIC_CATEGORY_ONLY | BASE CATEGORY '" + spec.coreNoun
                                + "' | REQUIRED ATTRIBUTES " + spec.requiredAttributes
                                + " - result carries the base category but not the required attribute(s)");
                return null;
            }
            if (!screenPassed && related != null) {
                // A related-category store in the search result -> verify further.
                if (hasAnySellingHint(titleText, snippetText, path)) {
                    screenPassed = true;
                }
            }
            if (!screenPassed && jarComboProof) {
                // Related jar/canister language with business/local evidence:
                // NOT auto-rejected - sent to homepage verification.
                logger.info("JARCOMBO PASS-TO-VERIFY '{}' - jar-family noun + modifier + business evidence",
                        website);
                screenPassed = true;
            }
            if (screenPassed) {
                String evidenceLabel = jarComboProof
                        ? "jar/canister + business/local evidence"
                        : (matched != null ? matched : related);
                logProductValidation(product, title, snippet, website, searchQuery,
                        "PASS-TO-VERIFY", matched != null ? matched : related,
                        evidenceLabel, "none",
                        QUAL_PRODUCT_RELEVANT,
                        "candidate passes the cheap PRODUCT screen; commercial/business/location "
                                + "gates run on the homepage before any buyer verdict");
                return QUAL_PRODUCT_RELEVANT;
            }
            logProductValidation(product, title, snippet, website, searchQuery,
                    "REJECT", null, "none", "none", QUAL_NOT_A_BUYER,
                    "no product phrase and no related-category seller/store signal");
            return null;
        }

        // ---- FULL PAGE (homepage already crawled): apply the strict gates. ----
        // The canonical/variant product phrase is accepted when the website
        // itself evidences it. When it appears ONLY in the candidate's own
        // listing (the site could not re-confirm it) the candidate is still kept
        // as VERIFICATION_UNAVAILABLE - it is never auto-called WRONG PRODUCT
        // (requirement 11) - and the commercial/business/location gates filter
        // it afterwards (requirement 10). Solo-noun variants are still
        // overridden by a related-industry context (requirement 6/8).
        if (matched != null && sitePhrase == null && !jarComboSiteProof) {
            boolean multiWord = matched.trim().contains(" ");
            boolean exactCanonical = p.equalsIgnoreCase(matched.trim());
            if (reject != null && !multiWord && !exactCanonical) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "LEVEL1-REJECT", matched, "none", "none", QUAL_NOT_A_BUYER,
                        "solo listing word '" + matched + "' overridden by related-industry context '" + reject + "'");
                return null;
            }
            // The product phrase appears only in the candidate's OWN listing.
            // A snippet phrase on its own merely echoes the searched terms and is
            // NOT website evidence - a buyer is never accepted on a snippet
            // keyword alone (requirement). A phrase on the listing's TITLE, URL
            // path or DOMAIN is meaningful lead evidence, so those candidates are
            // kept as VERIFICATION_UNAVAILABLE and the commercial/business/
            // location gates still run on them. A snippet-only candidate falls
            // through below and is only accepted when the website itself (or a
            // related-category store with store evidence) evidences the product.
            boolean listingAnchor = findFirstStrongPhrase(candidates,
                    titleText, path, "", domain, "") != null;
            if (listingAnchor) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "LEVEL1-ACCEPT", matched, "none", "none", QUAL_PRODUCT_LISTING,
                        "canonical/variant product phrase in the listing headline/URL; website text "
                                + "did not independently re-confirm it (VERIFICATION_UNAVAILABLE)");
                return QUAL_PRODUCT_LISTING;
            }
            // Snippet-only phrasing: keep evaluating the website below - the
            // snippet alone is never an accept.
        }
        if (jarComboSiteProof && sitePhrase == null) {
            logProductValidation(product, title, snippet, website, searchQuery,
                    "DEFER", matched, "none", "none", QUAL_DIRECT_PRODUCT_BUYER,
                    "product phrase is only a listing echo but the jar/canister "
                            + "family is worded on the website - routed to the jar-combo gate");
        }
        if (sitePhrase != null) {
            boolean siteMatchedMultiWord = sitePhrase.trim().contains(" ");
            if (siteMatchedMultiWord || reject == null || p.equalsIgnoreCase(sitePhrase.trim())) {
                boolean productEvidence = hasPhysicalProductEvidence(sitePhrase,
                        titleText, snippetText, homeText, path, domain);
                String tier = (productEvidence && !jarComboProof)
                        ? QUAL_DIRECT_PRODUCT_BUYER : QUAL_POTENTIAL_RETAIL_BUYER;
                logProductValidation(product, title, snippet, website, searchQuery,
                        "LEVEL1-ACCEPT", sitePhrase,
                        productEvidence ? "physical-product/seller evidence on the actual website" : "none",
                        "none", tier,
                        "canonical/variant product phrase confirmed on the actual website");
                return tier;
            }
            // A solo noun ("candle", "lantern") is too weak when a related-
            // industry context (candle-making supplies, camping gear...) is
            // present.
            logProductValidation(product, title, snippet, website, searchQuery,
                    "LEVEL1-REJECT", sitePhrase, "none", "none", QUAL_NOT_A_BUYER,
                    "solo noun '" + sitePhrase + "' overridden by related-industry context '" + reject + "'");
            return null;
        }

        // RELATED-INDUSTRY: with no DIRECT phrase at all, a kitchen-bowl /
        // camping-lantern / canning-jar / candle-making page that mentions the
        // family loosely must not accept.
        if (reject != null) {
            logProductValidation(product, title, snippet, website, searchQuery,
                    "REJECT", null, "none", "none", QUAL_NOT_A_BUYER,
                    "related-industry context '" + reject + "' with no product phrase");
            return null;
        }

        // GENERIC_CATEGORY_ONLY gate: when the product has REQUIRED attributes
        // (e.g. the "wall" of a "wall lantern"), a page that sits in the base
        // category but never evidences the attribute - any glass/moroccan/
        // hanging lantern, a bare candle-holder shop for a crystal-holder
        // search - is NOT a variant of the entered product and is rejected
        // HERE, before the RELATED store channel or MEDIUM signals could
        // accept it. A store that never names the category at all is still
        // handled by the RELATED gate below.
        if (matched == null && sitePhrase == null && reject == null
                && genericCategory != null && !spec.requiredAttributes.isEmpty()) {
            logProductValidation(product, title, snippet, website, searchQuery,
                    "GENERIC-CATEGORY-REJECT", genericCategory, "none", "none", QUAL_NOT_A_BUYER,
                    "MATCH TYPE: GENERIC_CATEGORY_ONLY | BASE CATEGORY '" + spec.coreNoun
                            + "' | REQUIRED ATTRIBUTES " + spec.requiredAttributes
                            + " - result carries the base category but not the required attribute(s)");
            return null;
        }

        // JAR/CANISTER COMBO PROOF (full page): with no strong phrase on the
        // page, a genuine decorative-jar business that words the product
        // differently (glass canisters, storage jars, apothecary jars, kitchen
        // canisters...) is accepted WHEN the jar-family noun appears with a
        // product modifier AND business/local evidence ON THE WEBSITE ITSELF -
        // never a naked "jar" mention and never a canning/lab/pickle page
        // (rejected above). Commerce is verified separately in GATE 2.
        if (jarComboProof && jarComboSiteProof) {
            boolean serviceOnly = hasServiceOnlyActivity(titleText, snippetText, homeText);
            if (!serviceOnly) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "JARCOMBO-ACCEPT", null,
                        "jar-family noun + product modifier + business/local evidence on the website",
                        "none", QUAL_POTENTIAL_RETAIL_BUYER,
                        "jar/canister language on the website for a decorative-jar product");
                return QUAL_POTENTIAL_RETAIL_BUYER;
            }
            logProductValidation(product, title, snippet, website, searchQuery,
                    "JARCOMBO-REJECT", null,
                    "jar-family combo but service-only page",
                    "service-only page (spa/class/workshop/retreat)",
                    QUAL_NOT_A_BUYER,
                    "jar/canister words on a service-only page");
            return null;
        }

        // LEVEL 2 - RELATED CATEGORY: an official full verification is never won on
        // a related-category word alone (redcircle.com / harmonika-institute.com
        // are exactly such related-category stores that never name the product).
        // A real buyer must evidence a canonical/variant phrase or family-context
        // signal directly; a related-category-only store is rejected here.
        if (related != null) {
            String relatedTier = "RELATED-CATEGORY-WORD-ONLY";
            try {
                relatedTier = relatedTierFor(searchQuery);
            } catch (Exception e) {
                logger.debug("relatedTierFor calculation failed for '{}': {}", product, e.getMessage());
            }
            logProductValidation(product, title, snippet, website, searchQuery,
                    "LEVEL2-REJECT", related,
                    "related-category word '" + related + "' without a canonical/variant phrase on the website",
                    "none", QUAL_NOT_A_BUYER,
                    "related-category word alone is not proof the business sells the requested product");
            return null;
        }

        // LEVEL 3 - MEDIUM / GENERIC: looser family-context words accept when
        // enough distinct signals appear; a bare unrelated phrase never does.
        if (!spec.specific) {
            int signals = countMediumSignals(spec.mediumSignals,
                    prepareText(title, snippet, homepageHtml), spec.coreNoun, path);
            if (signals >= RELEVANCE_MEDIUM_COUNT_FOR_ACCEPT) {
                logProductValidation(product, title, snippet, website, searchQuery,
                        "LEVEL3-ACCEPT", null,
                        signals + " medium family signals", "none",
                        QUAL_POTENTIAL_RETAIL_BUYER,
                        "family-context signals for a loose family product");
                return QUAL_POTENTIAL_RETAIL_BUYER;
            }
            if (signals > 0) {
                logger.debug("PRODUCT RELEVANCE | '{}' has only {}/{} medium signals - rejected",
                        product, signals, RELEVANCE_MEDIUM_COUNT_FOR_ACCEPT);
            }
        }

        logProductValidation(product, title, snippet, website, searchQuery,
                "REJECT", null, "none", "none", QUAL_NOT_A_BUYER,
                "no canonical/variant product phrase, no related-category store and no family-context signals");
        return null;
    }

    // QUAL_POTENTIAL_WHOLESALE_BUYER when the related-category store was reached
    // through a wholesale query, QUAL_POTENTIAL_RETAIL_BUYER for the retail/
    // store/for-sale profile queries, RELATED_CATEGORY_BUYER as the generic label.
    private String relatedTierFor(String searchQuery) {
        if (searchQuery != null) {
            String q = searchQuery.toLowerCase(Locale.ROOT);
            if (q.contains("wholesale") || q.contains("wholesaler") || q.contains("bulk")) {
                return QUAL_POTENTIAL_WHOLESALE_BUYER;
            }
        }
        return QUAL_RELATED_CATEGORY_BUYER;
    }

    // The number of looser family-context signals (or one core-noun-on-a-shop-
    // path) needed to accept when no STRONG product phrase was found.
    private static final int RELEVANCE_MEDIUM_COUNT_FOR_ACCEPT = 2;

    // Strong phrases per product family: a genuine multi-word product phrase
    // (or the family's own core noun) that proves the candidate deals in it.
    // withPlurals() adds the missing singular/plural form so "holder" and
    // "holders" both match.
    private static final List<String> STRONG_BOWL_PHRASES = withPlurals(List.of(
            "singing bowl", "tibetan singing bowl", "tibetan bowl",
            "himalayan singing bowl", "himalayan bowl", "meditation bowl",
            "crystal singing bowl", "sound healing bowl", "healing bowl",
            "sound bowl", "chakra bowl", "zen bowl", "buddhist bowl",
            "sing bowl", "song bowl"));

    private static final List<String> STRONG_CRYSTAL_CANDLE_HOLDER_PHRASES = withPlurals(List.of(
            "crystal candle holder", "crystal tealight holder", "crystal votive holder",
            "crystal candlestick", "crystal candle stand"));

    private static final List<String> STRONG_CANDLE_HOLDER_PHRASES = withPlurals(List.of(
            "candle holder", "candle stand", "candle pedestal", "candle sconce",
            "tealight holder", "tea light holder", "taper holder", "taper stand",
            "pillar candle holder", "candle lantern", "hurricane candle holder"));

    private static final List<String> STRONG_VOTIVE_HOLDER_PHRASES = withPlurals(List.of(
            "votive holder", "glass votive holder", "decorative votive holder",
            "votive candle holder", "votive cup", "votive glass",
            "tealight holder", "tea light holder"));

    private static final List<String> STRONG_CANDLE_PHRASES = withPlurals(List.of(
            "pillar candle", "scented candle", "aromatherapy candle",
            "soy candle", "beeswax candle", "votive candle", "taper candle",
            "dinner candle", "jar candle", "container candle", "candle set",
            "gift candle", "tealight", "tea light", "led candle", "rustic candle",
            "dripless candle", "luxury candle"));

    private static final List<String> STRONG_LANTERN_PHRASES = withPlurals(List.of(
            "decorative lantern", "moroccan lantern", "metal lantern",
            "glass lantern", "hanging lantern", "garden lantern",
            "home decor lantern", "table lantern", "candle lantern",
            "vintage lantern", "paper lantern", "wire lantern",
            "outdoor lantern", "patio lantern", "rustic lantern"));

    private static final List<String> STRONG_JAR_PHRASES = List.of(
            "decorative jar", "decorative jars", "decorative storage jar", "decorative storage jars",
            "glass decorative jar", "glass decorative jars", "glass display jar", "glass display jars",
            "glass storage jar", "glass storage jars", "glass jar", "glass jars",
            "storage jar", "storage jars", "canister", "canisters",
            "glass canister", "glass canisters", "decorative canister", "decorative canisters",
            "decorative jar with handle", "decorative jars with handle", "decorative jars with handles",
            "home decor jar", "home decor jars", "apothecary jar", "apothecary jars",
            "glass apothecary jar", "glass apothecary jars", "candy jar", "candy jars",
            "cookie jar", "cookie jars", "ceramic jar", "ceramic jars", "amber jar", "amber jars",
            "vintage jar", "vintage jars", "rustic jar", "rustic jars", "farmhouse jar", "farmhouse jars",
            "candle jar", "candle jars", "display jar", "display jars",
            "decorative glass jar", "decorative glass jars",
            "glass storage container", "glass storage containers",
            "decorative storage container", "decorative storage containers");

    private static final List<String> STRONG_HOME_DECOR_PHRASES = PRODUCT_FAMILY_TERMS.get(5);

    // RELATED category phrases: the home-decor sales channel. A home-decor
    // wholesale/boutique is a plausible buyer for any non-crystal product even
    // when it never names the product - this is the "Home Decor Wholesale →
    // RELATED → ACCEPT" rule. Crystal products are exact: their channel alone
    // proves nothing, so these phrases are never attached to crystal specs.
    private static final List<String> RELATED_HOME_DECOR_PHRASES = withPlurals(List.of(
            "home decor", "handmade home decor", "handcrafted home decor",
            "spiritual decor", "wellness decor", "meditation decor", "yoga decor",
            "gift and home decor", "artisan home decor", "home goods",
            "home accessory", "home accent", "houseware", "homeware", "decor"));

    // Looser family-context words: 2+ of them (or the core noun on a shopping
    // path) can accept when no STRONG phrase matched. Candles and lanterns get
    // this tier; exact families (crystal/votive/bowl/jar) never rely on it.
    private static final List<String> MEDIUM_CANDLE_SIGNALS = List.of(
            "candlelight", "hand poured", "home fragrance", "ambiance", "warm glow");

    private static final List<String> MEDIUM_LANTERN_SIGNALS = List.of(
            "garden lights", "string lights", "festive lighting", "outdoor lights",
            "hanging lights", "patio lights", "garden lighting", "outdoor lighting");

    // Words pointing at an OTHER-industry page (kitchen suppliers, camping gear,
    // canning/lab containers, candle-making/wax suppliers) so a loose family
    // word on such a page never accepts. Material words (soy wax, beeswax,
    // paraffin...) are deliberately NOT here: genuine finished-candle pages
    // constantly mention them ("soy wax candles", "made with beeswax") and
    // must not be rejected - an industry page instead says it MAKES SUPPLIES.
    private static final List<String> BOWL_REJECT_CONTEXTS = List.of(
            "kitchen bowl", "kitchen bowls", "mixing bowl", "mixing bowls",
            "serving bowl", "serving bowls", "salad bowl", "salad bowls",
            "cereal bowl", "soup bowl", "pasta bowl", "food storage",
            "dinnerware", "dishwasher", "microwave safe", "bakeware");

    private static final List<String> LANTERN_REJECT_CONTEXTS = List.of(
            "camping lantern", "camping gear", "flashlight", "headlamp",
            "hiking lantern", "backpacking", "emergency lantern", "automotive",
            "car accessory", "traffic", "storm lantern", "patrol lantern");

    private static final List<String> CANDLE_REJECT_CONTEXTS = List.of(
            "candle making", "candle supply", "candle supplies",
            "wick supplier", "candle mold", "candle molds",
            "candle kit", "candle kits", "restaurant", "diner");

    private static final List<String> CRYSTAL_CANDLE_REJECT_CONTEXTS = List.of(
            "gemstone", "healing crystal", "raw crystal", "crystal therapy",
            "chakra", "mineral specimen", "crystal collection");

    private static final List<String> JAR_REJECT_CONTEXTS = List.of(
            "canning jar", "canning jars", "canning supplies", "pickle jar",
            "pickle jars", "baby food", "laboratory", "pharma", "pharmaceutical",
            "medical");

    // Related jar/canister product evidence (requirement: decorative jars are
    // sold under many names). A candidate is accepted as a potential decorative-
    // jar buyer when the site says a JAR-FAMILY NOUN together with a PRODUCT
    // MODIFIER (decorative, glass, storage, display, apothecary, handle,
    // kitchen...) AND carries business/local evidence - see jarComboRelevant().
    // A page merely saying "jar" once, or a canning/lab/pickle page (JAR_REJECT_
    // CONTEXTS), never passes.
    private static final List<String> JAR_FAMILY_NOUNS = List.of(
            "jar", "jars", "canister", "canisters", "container", "containers");
    private static final List<String> JAR_COMBO_MODIFIERS = List.of(
            "decorative", "decoration", "decor", "glass", "storage", "display",
            "apothecary", "handle", "handles", "kitchen", "canister", "canisters");
    private static final List<String> JAR_COMBO_BUSINESS_EVIDENCE = List.of(
            "store", "shop", "retailer", "retail", "wholesale", "wholesaler",
            "distributor", "supplier", "buyer", "importer", "boutique",
            "products", "collection", "catalog", "decor");
    private static final java.util.regex.Pattern JAR_FAMILY_QUERY_PATTERN =
            java.util.regex.Pattern.compile(
                    "\\b(jar|jars|canister|canisters|container|containers)\\b");
    private static final java.util.regex.Pattern US_CITY_STATE_PATTERN =
            java.util.regex.Pattern.compile(
                    "\\b[A-Z][a-zA-Z]{2,}(?:\\s+[A-Z][a-zA-Z]{2,})?,\\s*[A-Z]{2}\\b",
                    java.util.regex.Pattern.CASE_INSENSITIVE);

    // Per-family REQUIRED attributes: when the user's canonical product carries
    // the attribute word, the CANONICAL is what the user narrowed the search to
    // (e.g. "wall lantern") and a candidate must evidence that attribute to be
    // a VALID_VARIANT / ATTRIBUTE_MATCH. A result that only reaches the BASE
    // CATEGORY (e.g. any glass/moroccan "lantern" for a "wall lantern" search)
    // is GENERIC_CATEGORY_ONLY and is never a relevant buyer - the search
    // planner fires attribute-preserving phrases and the validator rejects the
    // generic category before any store/related fallthrough. Index matches
    // familyIndexFor / PRODUCT_FAMILY_TERMS (0=bowls, 1=lanterns, 2=candles &
    // holders, 3=votive reserved, 4=jars, 5=home decor). Bowl products keep
    // identity-preserving variants ("Singing Bowls" -> tibetan/himalayan/crystal
    // singing bowls all preserve the singing-bowl identity) so no extra
    // attribute gate applies.
    private static final List<Set<String>> FAMILY_REQUIRED_ATTRIBUTES = List.of(
            Set.of(),
            Set.of("wall"),
            Set.of("crystal"),
            Set.of(),
            Set.of("handle"),
            Set.of());

    // Alternative form of a required-attribute token (the canonical token is
    // replaced 1:1 so the resulting phrase still carries the attribute), e.g.
    // "wall lantern" -> "wall mounted lantern".
    private static final Map<String, List<String>> ATTRIBUTE_ALT_FORMS = Map.of(
            "wall", List.of("wall mounted"),
            "crystal", List.of("crystal"));

    // Secondary modifiers that keep the canonical's required attribute in a
    // NEW variant: "<modifier> <canonical>" (e.g. "outdoor wall lantern"). The
    // canonical phrase (which already carries the attribute) is never dropped
    // to a bare base-category term, so no modifier puts the product's required
    // attribute at risk. Ordered so the first variants are the commercially
    // strongest attribute-preserving phrases.
    private static final List<String> LANTERN_ATTRIBUTE_MODIFIERS = List.of(
            "outdoor", "exterior", "decorative", "led", "interior", "metal",
            "glass", "modern", "farmhouse", "rustic", "hanging", "garden",
            "table", "moroccan", "vintage", "solar", "black", "bronze",
            "iron", "antique");

    private Set<String> requiredAttributesOf(String p, Set<String> words, int familyIndex) {
        Set<String> required = new LinkedHashSet<>();
        if (familyIndex < 0 || familyIndex >= FAMILY_REQUIRED_ATTRIBUTES.size()) {
            return required;
        }
        for (String attr : FAMILY_REQUIRED_ATTRIBUTES.get(familyIndex)) {
            if (words.contains(attr)) {
                required.add(attr);
            }
        }
        return required;
    }

    private static List<String> modifiersForFamily(int familyIndex) {
        if (familyIndex == 1) {
            return LANTERN_ATTRIBUTE_MODIFIERS;
        }
        return List.of();
    }

    // Attribute-preserving candidate phrases for a product with REQUIRED
    // attributes: the canonical itself, its attribute-synonym alt form and the
    // secondary-modifier forms, all of which keep the attribute. Used by BOTH
    // the query planner (discovery) and the product validator, so a "wall
    // lantern" search fires and accepts "outdoor wall lantern", "wall mounted
    // lantern", "exterior wall lantern", "decorative wall lantern", "LED wall
    // lantern", ... but never "glass lantern" / "moroccan lantern" (no wall
    // attribute). An unsupported family returns the canonical alone.
    private List<String> attributePreservingVariants(String p, int familyIndex, Set<String> required) {
        List<String> out = new ArrayList<>();
        out.add(p);
        for (String attr : required) {
            for (String alt : ATTRIBUTE_ALT_FORMS.getOrDefault(attr, List.of(attr))) {
                String form = p.replaceFirst("\\b" + Pattern.quote(attr) + "\\b", alt);
                if (!form.equals(p) && !out.contains(form)) {
                    out.add(form);
                }
            }
        }
        for (String modifier : modifiersForFamily(familyIndex)) {
            String form = modifier + " " + p;
            if (!out.contains(form)) {
                out.add(form);
            }
        }
        return withPlurals(out);
    }

    // Base-category terms of the lantern family: words that prove a result is
    // IN the lantern category without the required attribute (bare "lantern" or
    // any generic lantern phrase). Only used to LABEL the category-only case as
    // GENERIC_CATEGORY_ONLY and reject it - never as an accept phrase.
    private List<String> lanternCategoryTerms() {
        List<String> terms = new ArrayList<>(withPlurals(List.of("lantern")));
        for (String t : STRONG_LANTERN_PHRASES) {
            if (!terms.contains(t)) {
                terms.add(t);
            }
        }
        return terms;
    }

    /** The acceptance profile of one product family: the phrases that prove it
     *  DIRECTLY, the RELATED-CATEGORY store words that make it a plausible
     *  buyer (audio for exact/crystal products), the looser language that may
     *  hint at it, the related-industry contexts that exclude it, whether it is
     *  exact/crystal (never accepts on RELATED or MEDIUM signals), its core
     *  noun used for shop-path evidence, the base-category terms that make a
     *  product with REQUIRED attributes GENERIC_CATEGORY_ONLY (never accepted),
     *  and the required attributes the product's variant phrases must preserve. */
    private static final class ProductSpec {
        final List<String> strongPhrases;
        final List<String> relatedCategoryPhrases;
        final List<String> mediumSignals;
        final List<String> rejectContexts;
        final boolean specific;
        final String coreNoun;
        final List<String> genericCategoryTerms;
        final Set<String> requiredAttributes;

        ProductSpec(List<String> strongPhrases, List<String> relatedCategoryPhrases,
                    List<String> mediumSignals, List<String> rejectContexts,
                    boolean specific, String coreNoun,
                    List<String> genericCategoryTerms, Set<String> requiredAttributes) {
            this.strongPhrases = strongPhrases;
            this.relatedCategoryPhrases = relatedCategoryPhrases;
            this.mediumSignals = mediumSignals;
            this.rejectContexts = rejectContexts;
            this.specific = specific;
            this.coreNoun = coreNoun;
            this.genericCategoryTerms = genericCategoryTerms;
            this.requiredAttributes = requiredAttributes;
        }
    }

    /** Picks the ProductSpec for the normalized entered product, using the same
     *  family detection as the query planner: candle family first (crystal →
     *  exact, votive+holder, holder, candles), then bowls, lanterns, jars and
     *  generic home decor. Anything else can only match its own exact phrase.
     *  CRYSTAL-qualified products are always exact/specific: they never accept
     *  via the home-decor RELATED channel or loose MEDIUM signals. */
    private ProductSpec buildProductSpec(String p, Set<String> words) {
        boolean crystal = words.contains("crystal");
        boolean candle = words.contains("candle") || words.contains("candles")
                || p.contains("candle") || p.contains("candela")
                || words.contains("votive") || words.contains("votives")
                || words.contains("taper") || words.contains("tapers")
                || words.contains("tealight") || words.contains("tealights")
                || p.contains("tea light") || p.contains("tea lights");
        boolean holder = words.contains("holder") || words.contains("holders")
                || words.contains("stand") || words.contains("stands")
                || words.contains("sconce") || words.contains("pedestal");
        boolean votive = words.contains("votive") || words.contains("votives")
                || words.contains("tealight") || words.contains("tealights")
                || p.contains("tea light") || p.contains("tea lights");

        int familyIndex = familyIndexFor(p);
        Set<String> requiredAttrs = requiredAttributesOf(p, words, familyIndex);

        // LEVEL 2 - RELATED CATEGORY fit: the product family's buyer-profile
        // store categories (meditation/spiritual/wellness/crystal/gift shops for
        // bowls, home-decor/lighting/garden for lanterns, home-fragrance/gift/
        // boutique for candles, glassware/kitchen/gift for jars, artisan/home-
        // goods for home decor). A related-category store is accepted ONLY with
        // store/selling evidence (handled inside isProductRelevant).
        List<String> related = new ArrayList<>();
        for (List<String> profile : categoryProfilesFor(p)) {
            for (String term : profile) {
                if (!related.contains(term)) {
                    related.add(term);
                }
            }
        }
        boolean specific = crystal;

        if (candle && crystal && holder) {
            // Crystal candle holders are the exact/specific case: only a true
            // "crystal ... holder" phrase can ever accept these.
            return new ProductSpec(STRONG_CRYSTAL_CANDLE_HOLDER_PHRASES, List.of(),
                    List.of(), CRYSTAL_CANDLE_REJECT_CONTEXTS, true, "candle",
                    STRONG_CANDLE_HOLDER_PHRASES, requiredAttrs);
        }
        if (candle && votive && holder) {
            return new ProductSpec(STRONG_VOTIVE_HOLDER_PHRASES, related, List.of(),
                    CANDLE_REJECT_CONTEXTS, specific, "votive", List.of(), requiredAttrs);
        }
        if (candle && holder) {
            return new ProductSpec(STRONG_CANDLE_HOLDER_PHRASES, related, List.of(),
                    CANDLE_REJECT_CONTEXTS, specific, "candle", List.of(), requiredAttrs);
        }
        if (candle) {
            return new ProductSpec(STRONG_CANDLE_PHRASES, related, MEDIUM_CANDLE_SIGNALS,
                    CANDLE_REJECT_CONTEXTS, specific, "candle", List.of(), requiredAttrs);
        }
        if (words.contains("bowl") || words.contains("bowls")) {
            // Singing bowls: the approved relevance space covers the exact
            // singing-bowl phrases PLUS the related/commercial categories under
            // which singing bowls genuinely sell - meditation / sound-healing /
            // wellness stores, spiritual & home-decor, crystal / metaphysical /
            // gift shops, and the lantern / candle / candle-holder / votive-
            // holder sellers explicitly allowed for singing-bowl searches. Only
            // a genuinely commerce-backed related business is accepted: the
            // relevance is decided here and the store/selling evidence is
            // verified separately (GATE 2 + business-type gates), so a bare
            // word on an article/blog/non-commercial page still never accepts.
            List<String> bowlRelated = new ArrayList<>(related);
            for (String term : List.of("sound healing", "wellness", "spiritual",
                    "home decor", "meditation", "lanterns", "candles",
                    "candle holders", "votive holders")) {
                if (!bowlRelated.contains(term)) {
                    bowlRelated.add(term);
                }
            }
            return new ProductSpec(STRONG_BOWL_PHRASES, bowlRelated, List.of(),
                    BOWL_REJECT_CONTEXTS, true, "bowl", List.of(), requiredAttrs);
        }
        if (p.contains("lantern")) {
            if (requiredAttrs.contains("wall")) {
                return new ProductSpec(attributePreservingVariants(p, 1, requiredAttrs),
                        related, List.of(), LANTERN_REJECT_CONTEXTS, true, "lantern",
                        lanternCategoryTerms(), requiredAttrs);
            }
            return new ProductSpec(STRONG_LANTERN_PHRASES, related, MEDIUM_LANTERN_SIGNALS,
                    LANTERN_REJECT_CONTEXTS, specific, "lantern", List.of(), requiredAttrs);
        }
        if (words.contains("jar") || words.contains("jars")) {
            return new ProductSpec(STRONG_JAR_PHRASES, related, List.of(),
                    JAR_REJECT_CONTEXTS, specific, "jar", List.of(), requiredAttrs);
        }
        if (isHomeDecorProduct(p, words)) {
            return new ProductSpec(STRONG_HOME_DECOR_PHRASES, related, List.of(),
                    List.of(), specific, "decor", List.of(), requiredAttrs);
        }
        // Unsupported combination: the exact entered phrasing is the only
        // phrase that can ever match (never loose tokens).
        return new ProductSpec(List.of(), List.of(), List.of(), List.of(), false, null,
                List.of(), requiredAttrs);
    }

    // ----- product-phrase helpers -----------------------------------------

    /** Adds the plural (or missing singular) form of every phrase, e.g. adds
     *  "candle holders" for "candle holder" and "lantern" for "lanterns" (the
     *  singular is never re-added when the phrase already ends in "s"). */
    private static List<String> withPlurals(List<String> phrases) {
        List<String> out = new ArrayList<>(phrases);
        for (String phrase : phrases) {
            String trimmed = phrase.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            String[] words = trimmed.split("\\s+");
            String last = words[words.length - 1].toLowerCase(Locale.ROOT);
            if (last.length() < 3 || last.endsWith("s") || last.endsWith("or")
                    || last.endsWith("ing") || last.endsWith("ware")) {
                continue;
            }
            words[words.length - 1] = last + "s";
            out.add(String.join(" ", words));
        }
        return out.stream().distinct().collect(Collectors.toList());
    }

    /** TRUE when the phrase occurs as a whole phrase in the text: padded with
     *  spaces both sides so "candle holder" never matches inside "candle
     *  holders" (the plural form is matched by its own entry). */
    private boolean containsPhrase(String text, String phrase) {
        if (text == null || phrase == null || phrase.isBlank()) {
            return false;
        }
        String t = " " + text.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ") + " ";
        String p = " " + phrase.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ") + " ";
        return t.contains(p);
    }

    /** Scans the evidence zones in priority order (title → shopping URL path →
     *  snippet → domain → homepage) and returns the first STRONG phrase found,
     *  or null. */
    private String findFirstStrongPhrase(List<String> phrases, String title, String path,
                                         String snippet, String domain, String homepageText) {
        for (String phrase : phrases) {
            if (containsPhrase(title, phrase)) {
                return phrase;
            }
        }
        if (isShoppingPath(path)) {
            for (String phrase : phrases) {
                if (containsPhrase(path, phrase)) {
                    return phrase;
                }
            }
        }
        for (String phrase : phrases) {
            if (containsPhrase(snippet, phrase)) {
                return phrase;
            }
        }
        for (String phrase : phrases) {
            if (domainAlnumEvidence(domain, phrase)) {
                return phrase;
            }
        }
        for (String phrase : phrases) {
            if (containsPhrase(homepageText, phrase)) {
                return phrase;
            }
        }
        return null;
    }

    /** Names the zone where a matched phrase was found (for the diagnostic log). */
    private String strongPhraseZone(String phrase, String title, String path,
                                    String snippet, String domain, String homepageText) {
        if (containsPhrase(title, phrase)) {
            return "title";
        }
        if (isShoppingPath(path) && containsPhrase(path, phrase)) {
            return "shop path";
        }
        if (containsPhrase(snippet, phrase)) {
            return "snippet";
        }
        if (domainAlnumEvidence(domain, phrase)) {
            return "domain";
        }
        return "homepage";
    }

    // ------------------------------------------------------------------
    // ACCESSORY / CONSUMABLE GATE - words that are parts sold FOR the product
    // ("Singing Bowl Cushion", "Bowl Mallet", "Box for Singing Bowls",
    // "candle holder bag") rather than the product itself. A page whose product
    // is an accessory sells the accessory, never the product, so it is not a
    // buyer of the product and is rejected before any email scraping or save.
    // Bowl-family heads run the ADJACENCY rule (an accessory within a few tokens
    // of a strong bowl phrase, before or after); every family additionally
    // rejects the COMPOSED form of a multi-word strong phrase immediately
    // followed by an accessory word. A legit "Candle Stand" product is never
    // caught: "candle" is a single-word phrase that the composed form skips
    // (the strong lists carry no loose bare noun), and the adjacency rule only
    // runs for bowl heads.
    // ------------------------------------------------------------------
    private static final Set<String> ACCESSORY_WORDS = Set.of(
            "cushion", "mallet", "striker", "beater", "box", "bag", "pouch",
            "case", "cover", "sleeve", "stand", "ring", "carrying", "travel",
            "storage", "organizer", "organiser"
    );

    // Max tokens separating an accessory word from a strong bowl phrase (either
    // side) for the bowl-head adjacency rule. 3 tokens covers "Box for Singing
    // Bowls" (accessory 2 tokens before the phrase) while keeping genuine
    // bowl sellers safe.
    private static final int ACCESSORY_ADJACENCY_TOKENS = 3;

    /** The strong-product phrase candidates for the accessory gate: the user's
     *  own product phrase first, then every strong phrase of its family. */
    private List<String> accessoryPhraseCandidates(ProductSpec spec, String product) {
        List<String> candidates = new ArrayList<>();
        if (product != null && !product.isBlank()) {
            candidates.add(product.trim());
        }
        for (String phrase : spec.strongPhrases) {
            if (!candidates.contains(phrase)) {
                candidates.add(phrase);
            }
        }
        return candidates;
    }

    private List<String> phraseTokens(String phrase) {
        return Arrays.stream(phrase.split("\\s+"))
                .filter(w -> !w.isEmpty())
                .collect(Collectors.toList());
    }

    private boolean phraseMatchesAt(List<String> words, int at, List<String> phraseWords) {
        for (int k = 0; k < phraseWords.size(); k++) {
            if (!phraseWords.get(k).equals(words.get(at + k))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns the accessory word found in the evidence when the site sells an
     * accessory of the product rather than the product itself, or null.
     *  - bowl-family heads: an ACCESSORY_WORDS token within
     *    ACCESSORY_ADJACENCY_TOKENS of any strong bowl phrase (either side);
     *  - every family: a multi-word strong phrase immediately followed by an
     *    ACCESSORY_WORDS token ("candle holder bag").
     */
    private String findAccessoryEvidence(ProductSpec spec, String product, String titleText,
                                         String snippetText, String path, String domain,
                                         String homeText) {
        String text = prepareText(titleText, snippetText, path, domain, homeText);
        List<String> words = tokenizeWords(text);
        if (words.isEmpty()) {
            return null;
        }
        boolean bowlHead = "bowl".equals(spec.coreNoun);
        for (String phrase : accessoryPhraseCandidates(spec, product)) {
            List<String> phraseWords = phraseTokens(phrase);
            int len = phraseWords.size();
            if (len == 0) {
                continue;
            }
            for (int i = 0; i + len <= words.size(); i++) {
                if (!phraseMatchesAt(words, i, phraseWords)) {
                    continue;
                }
                if (bowlHead) {
                    // Adjacency rule: an accessory within a small radius on either
                    // side of the strong bowl phrase.
                    int start = Math.max(0, i - ACCESSORY_ADJACENCY_TOKENS);
                    int end = Math.min(words.size(), i + len + ACCESSORY_ADJACENCY_TOKENS);
                    for (int j = start; j < end; j++) {
                        String w = words.get(j);
                        if (ACCESSORY_WORDS.contains(w)) {
                            return w;
                        }
                    }
                } else if (len >= 2) {
                    // Composed form: a multi-word strong phrase immediately
                    // followed by an accessory word (e.g. "candle holder bag").
                    int next = i + len;
                    if (next < words.size() && ACCESSORY_WORDS.contains(words.get(next))) {
                        return words.get(next);
                    }
                }
            }
        }
        return null;
    }

    /** The meaningful single label of a website host, e.g. "crystalcandleholder"
     *  for "www.crystalcandleholder.com" - used for domain-level phrase proof. */
    private String domainEvidence(String website) {
        if (website == null || website.isBlank()) {
            return "";
        }
        String host = website.replaceFirst("(?i)^https?://", "")
                .replaceFirst("(?i)^www\\.", "");
        int slash = host.indexOf('/');
        if (slash >= 0) {
            host = host.substring(0, slash);
        }
        String best = "";
        for (String label : host.split("\\.")) {
            if (label.length() > best.length()) {
                best = label;
            }
        }
        return best.toLowerCase(Locale.ROOT);
    }

    /** A phrase without any non-alphanumeric characters, e.g. "candle holder"
     *  → "candleholder", so a domain can prove it. */
    private String stripNonAlnum(String s) {
        return s == null ? "" : s.replaceAll("[^a-zA-Z0-9]", "");
    }

    /** A domain proves a phrase when the phrase's letter-form appears inside
     *  the domain's letter-form (minimum 6 letters to avoid noise). */
    private boolean domainAlnumEvidence(String domain, String phrase) {
        String phraseAlnum = stripNonAlnum(phrase);
        if (phraseAlnum.length() < 6) {
            return false;
        }
        return stripNonAlnum(domain).contains(phraseAlnum);
    }

    /** The URL path of the website (hyphens/underscores → spaces), used to
     *  detect "the shop really stocks the product" from /shop, /collections,
     *  /category, /products or /catalog links. */
    private String shopPathText(String website) {
        if (website == null || website.isBlank()) {
            return "";
        }
        String w = website.toLowerCase(Locale.ROOT);
        int q = w.indexOf('?');
        if (q >= 0) {
            w = w.substring(0, q);
        }
        int scheme = w.indexOf("://");
        String rest = scheme >= 0 ? w.substring(scheme + 3) : w;
        int slash = rest.indexOf('/');
        if (slash < 0) {
            return "";
        }
        return rest.substring(slash).replace('-', ' ').replace('_', ' ');
    }

    /** TRUE for the URL paths that act as a shop's product sections. */
    private boolean isShoppingPath(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("/shop") || p.contains("/collections") || p.contains("/category")
                || p.contains("/catalog") || p.contains("/product") || p.contains("/browse")
                || p.contains("/store");
    }

    /** TRUE when a DIRECT product phrase is backed by physical-product (seller)
     *  evidence: a shop/collection/catalog URL, a product-named domain, or a
     *  COMMERCE_SIGNAL sentence within a short window of the phrase in the
     *  combined title/snippet/homepage text. Requiring the commerce token NEAR
     *  the phrase means an article/service page that merely mentions the
     *  product cannot pass just because "buy"/"wholesale" appears somewhere in
     *  its footer. */
    private boolean hasPhysicalProductEvidence(String phrase, String title,
            String snippet, String home, String path, String domain) {
        if (isShoppingPath(path)) {
            return true;
        }
        if (domainAlnumEvidence(domain, phrase)) {
            return true;
        }
        String t = " " + (title + " " + snippet + " " + home).toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", " ") + " ";
        String p = " " + phrase.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ") + " ";
        if (p.trim().isEmpty()) {
            return false;
        }
        int from = 0;
        int window = 140;
        while (true) {
            int idx = t.indexOf(p, from);
            if (idx < 0) {
                return false;
            }
            int start = Math.max(0, idx - window);
            int end = Math.min(t.length(), idx + p.length() + window);
            String near = t.substring(start, end);
            for (String token : COMMERCE_SIGNAL_PHRASES) {
                if (near.contains(" " + token + " ")) {
                    return true;
                }
            }
            from = idx + p.length();
        }
    }

    /**
     * "Selling hint" for the CHEAP SCREEN only (title/snippet/shop URL): TRUE
     * when the search listing shows the candidate might sell physical goods.
     * This is intentionally lenient - a real seller whose store is only
     * visible on its homepage must still pass to free HTTP verification; the
     * strict store/service decision happens on the full page below.
     */
    private boolean hasAnySellingHint(String titleText, String snippetText, String path) {
        if (isShoppingPath(path)) {
            return true;
        }
        String surface = titleText + " " + snippetText;
        for (String marker : STORE_SELLING_MARKERS) {
            if (containsPhrase(surface, marker)) {
                return true;
            }
        }
        return false;
    }

    /** TRUE when the page actually SELLS a physical product: a shopping URL,
     *  a single STRONG store marker (our shop / add to cart / buy now /
     *  checkout / shopping cart...) anywhere on the page, or at least two
     *  general store-selling markers (shop, store, boutique, retail, ...).
     *  This backs the LEVEL-2 related-category gate and rescues a business
     *  that ALSO offers classes from the service-only rejection. */
    private boolean hasStoreSellingEvidence(String titleText, String snippetText,
                                            String homeText, String path) {
        if (isShoppingPath(path)) {
            return true;
        }
        String text = titleText + " " + snippetText + " " + homeText;
        for (String marker : STRONG_STORE_SELLING_MARKERS) {
            if (containsPhrase(text, marker)) {
                return true;
            }
        }
        int count = 0;
        for (String marker : STORE_SELLING_MARKERS) {
            if (containsPhrase(text, marker)) {
                count++;
            }
        }
        return count >= 2;
    }

    /** TRUE when the page looks like a SERVICE-only business (spa, therapist,
     *  yoga class, sound-healing sessions, workshops, retreats, courses,
     *  training, certification, bookings, events). Used ONLY against a page
     *  that has no store/catalogue: a service business that names the product
     *  is not a buyer unless it also has shop/cart evidence. */
    private boolean hasServiceOnlyActivity(String titleText, String snippetText,
                                           String homeText) {
        String text = titleText + " " + snippetText + " " + homeText;
        for (String marker : SERVICE_ONLY_MARKERS) {
            if (containsPhrase(text, marker)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Single structured decision log for the product validation of one result.
     * Prints the fired query, the requested product, the matched phrase, the
     * commercial/business evidence, the decision, the buyer-qualification tier
     * and the final reason, so every result has a traceable, human-readable
     * audit line (SEARCH QUERY | PRODUCT | URL | TITLE | MATCHED | COMMERCIAL
     * EVIDENCE | BUSINESS TYPE | DECISION | QUALIFICATION | REASON).
     */
    private void logProductValidation(String product, String title, String snippet,
            String website, String searchQuery, String decision, String matchedPhrase,
            String commercialEvidence, String businessType, String qualification,
            String reason) {
        logger.info("PRODUCT VALIDATION |"
                + " Query: {} | Product: '{}' | Matched phrase: {}"
                + " | Commercial evidence: {} | Business type: {} | Decision: {}"
                + " | Qualification: {} | Reason: {} | Site: {} | Title: {} | Snippet: {}",
                searchQuery == null || searchQuery.isBlank() ? "n/a" : "'" + searchQuery + "'",
                product, matchedPhrase == null ? "none" : "'" + matchedPhrase + "'",
                commercialEvidence, businessType == null ? "none" : businessType,
                decision, qualification, reason,
                website == null || website.isBlank() ? "unknown" : website,
                cleanForLog(title), cleanForLog(snippet));
    }

    /** Requirement: for EVERY accepted/rejected candidate log the PRODUCT /
     *  BUSINESS / LOCATION evidence buckets plus the DECISION and REASON in one
     *  line, so failures stack up (why a decorative-jar seller was dropped) and
     *  gate-relaxation effects are visible in the logs. Evidence is read from
     *  the raw title/snippet/URL surface only - never invented. */
    private void logCandidateVerdict(String decision, String reason, String title,
                                     String snippet, String website, String queryProduct,
                                     String state, String city) {
        try {
            String surface = prepareText(title) + " " + prepareText(snippet);
            String path = shopPathText(website);
            String domain = domainEvidence(website);

            List<String> productHits = new ArrayList<>();
            if (queryProduct != null && !queryProduct.isBlank()) {
                for (String term : significantTerms(queryProduct)) {
                    if (surface.contains(term)) {
                        productHits.add(term);
                    }
                }
            }
            List<String> businessHits = new ArrayList<>();
            for (String m : STORE_SELLING_MARKERS) {
                if (containsPhrase(surface, m)
                        || (path != null && containsPhrase(path, m))) {
                    businessHits.add(m);
                }
            }
            List<String> locHits = new ArrayList<>();
            if (US_CITY_STATE_PATTERN.matcher(surface).find()) {
                locHits.add("address(US city,ST)");
            }
            if (city != null && !city.isBlank()
                    && surface.contains(city.toLowerCase(Locale.ROOT))) {
                locHits.add("city '" + city + "'");
            }
            if (state != null && !state.isBlank()) {
                String abbr = stateAbbreviation(state);
                if (abbr != null && !abbr.isEmpty()
                        && containsToken(surface, abbr.toLowerCase(Locale.ROOT))) {
                    locHits.add("state '" + abbr + "'");
                }
            }
            logger.info("CANDIDATE VERDICT | Decision: {} | Reason: {}"
                            + " | PRODUCT EVIDENCE: {} | BUSINESS EVIDENCE: {}"
                            + " | LOCATION EVIDENCE: {}"
                            + " | Product: '{}' | Site: {} | Title: {}",
                    decision, reason,
                    productHits.isEmpty() ? "none" : String.join(",", productHits),
                    businessHits.isEmpty() ? "none" : String.join(",", businessHits),
                    locHits.isEmpty() ? "none" : String.join(",", locHits),
                    queryProduct,
                    website == null || website.isBlank() ? "unknown" : website,
                    cleanForLog(title));
        } catch (Exception e) {
            logger.debug("CANDIDATE VERDICT logging skipped for '{}': {}",
                    website, e.getMessage());
        }
    }

    private String cleanForLog(String text) {
        if (text == null || text.isBlank()) {
            return "none";
        }
        String t = text.trim().replaceAll("\\s+", " ");
        return t.length() > 120 ? t.substring(0, 117) + "..." : t;
    }

    /** TRUE when the path mentions the family's core noun (with its common
     *  singular/plural forms), e.g. "holder"/"holders" in /collections/holders. */
    private boolean mentionsCoreNoun(String path, String coreNoun) {
        String p = path.toLowerCase(Locale.ROOT);
        for (String form : new String[]{coreNoun, coreNoun + "s", coreNoun + "es"}) {
            if (containsToken(p, form)) {
                return true;
            }
        }
        return false;
    }

    /** Counts the loose family-context signals found in the evidence; a core
     *  noun on the shopping path counts as one extra signal. */
    private int countMediumSignals(List<String> signals, String fullText,
                                   String coreNoun, String path) {
        int count = 0;
        for (String signal : signals) {
            if (containsPhrase(fullText, signal)) {
                count++;
            }
        }
        if (coreNoun != null && isShoppingPath(path) && mentionsCoreNoun(path, coreNoun)) {
            count++;
        }
        return count;
    }

    /** Returns the first reject context found in the evidence, or null. */
    private String findRejectContext(List<String> contexts, String text) {
        for (String context : contexts) {
            if (containsPhrase(text, context)) {
                return context;
            }
        }
        return null;
    }

    private List<String> significantTerms(String product) {
        String[] words = product.toLowerCase().split("[^a-z0-9]+");
        return Arrays.stream(words)
                .filter(w -> w.length() >= 2)
                .filter(w -> !STOPWORDS.contains(w))
                .collect(Collectors.toList());
    }

    /**
     * CONDITION 2 (full-page re-check) - location verdict.
     *  - CONFLICT : the business explicitly states a location that conflicts
     *               with the requested city/state -> rejected.
     *  - VERIFIED : the requested city/state is positively present.
     *  - UNKNOWN  : no positive or negative location signal. The business
     *               location is simply UNAVAILABLE - the buyer is kept and its
     *               location is marked Unknown (never invented, never guessed).
     */
    private LocationVerdict locationVerdictOf(String evidence, String homepageHtml,
                                              String state, String city) {
        String stateValue = collapseWhitespace(state);
        String cityValue = collapseWhitespace(city);
        if (stateValue == null && cityValue == null) {
            return LocationVerdict.VERIFIED;
        }

        String text = prepareText(evidence, homepageHtml);
        String raw = buildRawText(evidence, homepageHtml);
        if (text.isBlank()) {
            // No evidence at all - the location is unavailable, not conflicting.
            return LocationVerdict.UNKNOWN;
        }

        String stateLower = stateValue != null ? stateValue.toLowerCase(Locale.ROOT) : null;
        String abbrev = stateLower != null ? STATE_ABBREVIATIONS.get(stateLower) : null;
        if (abbrev == null && stateLower != null) {
            // The requested state may itself be an abbreviation ("TX"): resolve
            // the reverse mapping so full-name evidence ("Dallas, Texas") is
            // verified against it and vice versa.
            String fullName = STATE_ABBR_TO_NAME.get(stateLower.toUpperCase(Locale.ROOT));
            if (fullName != null) {
                abbrev = stateLower.toUpperCase(Locale.ROOT);
            }
        }
        String cityLower = cityValue != null ? cityValue.toLowerCase(Locale.ROOT) : null;

        // A conflicting, explicitly stated region - a different state by full
        // name or by "City, ST" address abbreviation - means the business is not
        // located in the requested region regardless of any other match.
        if (stateLower != null && hasConflictingStateSignal(raw, stateLower)) {
            logger.debug("Conflicting state rejected location match");
            return LocationVerdict.CONFLICT;
        }

        // When a specific city was requested, that city must be positively
        // present (e.g. "…, El Paso, TX 79901"). If it is simply not mentioned
        // anywhere and no conflicting region exists, the location is treated as
        // unavailable rather than rejected.
        if (cityLower != null) {
            if (containsToken(text, cityLower)) {
                return LocationVerdict.VERIFIED;
            }
            logger.debug("LOCATION UNKNOWN - requested city '{}' not found in evidence", cityLower);
            return LocationVerdict.UNKNOWN;
        }

        if (stateLower != null) {
            if (containsToken(text, stateLower)) {
                // The requested state is explicitly present - by its full name
                // ("texas" in "Dallas, Texas") or by its abbreviation token
                // ("tx" in "Houston, TX" / "houston tx").
                return LocationVerdict.VERIFIED;
            }
            if (abbrev != null) {
                if (containsStateZip(text, abbrev)
                        || containsStateAbbrevAddress(raw, abbrev)) {
                    // "City, ST 12345" / "City, ST" address patterns confirmed.
                    return LocationVerdict.VERIFIED;
                }
                String fullName = STATE_ABBR_TO_NAME.get(abbrev);
                if (fullName != null && containsToken(text, fullName.toLowerCase(Locale.ROOT))) {
                    // Requested by abbreviation ("TX") but the evidence spells
                    // the state out in full ("Dallas, Texas", "based in Texas").
                    return LocationVerdict.VERIFIED;
                }
            }
            // No positive state signal, but no conflicting region either.
            return LocationVerdict.UNKNOWN;
        }
        return LocationVerdict.VERIFIED;
    }

    /** True when the extracted business state matches the requested state, by
     *  full name or abbreviation ("Texas" vs "TX"). */
    private boolean sameState(String extracted, String requested) {
        String e = stateKey(extracted);
        String r = stateKey(requested);
        return e != null && r != null && e.equals(r);
    }

    private String stateKey(String state) {
        if (state == null) {
            return null;
        }
        String s = collapseWhitespace(state);
        if (s == null) {
            return null;
        }
        s = s.trim().toLowerCase(Locale.ROOT);
        if (s.length() == 2) {
            return s; // already an abbreviation ("tx")
        }
        String abbr = STATE_ABBREVIATIONS.get(s);
        return abbr != null ? abbr.toLowerCase(Locale.ROOT) : s;
    }

    /** True when the extracted business city matches the requested city,
     *  tolerating a trailing state on either value ("Dallas, TX" == "Dallas"). */
    private boolean sameCity(String extracted, String requested) {
        String e = cityKey(extracted);
        String r = cityKey(requested);
        return e != null && r != null && e.equals(r);
    }

    private String cityKey(String city) {
        if (city == null) {
            return null;
        }
        String c = collapseWhitespace(city);
        if (c == null) {
            return null;
        }
        c = c.replaceAll("[.;]+", " ").trim().toLowerCase(Locale.ROOT);
        int comma = c.indexOf(',');
        if (comma >= 0) {
            c = c.substring(0, comma).trim();
        }
        String[] toks = c.split("\\s+");
        if (toks.length >= 2) {
            String last = toks[toks.length - 1];
            if (last.length() == 2
                    && STATE_ABBR_TO_NAME.containsKey(last.toUpperCase(Locale.ROOT))) {
                // "arlington tx" -> "arlington"
                c = String.join(" ", Arrays.copyOf(toks, toks.length - 1));
            }
        }
        if (c.isBlank()) {
            return null;
        }
        return c;
    }

    private enum LocationVerdict { CONFLICT, VERIFIED, UNKNOWN }

    // Canadian postal code "A1A 1A1" - a decisive Canadian-address proof when no
    // province name is written out.
    private static final Pattern CANADA_POSTAL_PATTERN = Pattern.compile(
            "\\b[a-z]\\d[a-z]\\s\\d[a-z]\\d\\b");

    private static final class ExtractedLocation {
        final String city;
        final String state;
        final String country;
        final String source;

        ExtractedLocation(String city, String state, String country, String source) {
            this.city = city;
            this.state = state;
            this.country = country;
            this.source = source;
        }
    }

    /**
     * Extracts the buyer's REAL business location whenever the search did not
     * pin a verified city (USA-wide / state-wide searches and searched-city
     * unavailable). Sources in priority order: Google Business address from the
     * search result, search title/snippet, homepage schema.org data, homepage
     * footer, homepage body, then (only when still unresolved) the contact page
     * and the about page fetched with plain HTTP - never a Firecrawl credit.
     * Nothing is ever invented: when no reliable city/state exists the location
     * is marked Unknown, or the bare country alone when only the country is
     * positively known.
     */
    private void resolveBusinessLocation(BuyerSearchResult result, String evidence, String homepageHtml) {
        String website = result.getWebsite();
        ExtractedLocation el = resolveBusinessLocationFrom(website, result.getSearchAddress(),
                homepageHtml);
        if (el != null) {
            applyExtractedLocation(result, el);
            return;
        }

        // No reliable city/state anywhere - fall back without inventing one.
        String state = result.getState();
        if (state != null && !state.isBlank()) {
// A searched state (state-wide search) that verified still stands.
                result.setLocation(buildLocationDisplay(state, null, result.getCountry()));
            if (result.getLocationSource() == null) {
                result.setLocationSource("searched state");
            }
            logger.info("LOCATION EXTRACT | website={} | source={} | extracted='{}'",
                    website, result.getLocationSource(), result.getLocation());
            return;
        }
        String combined = buildRawText(evidence, homepageHtml);
        if (hasCanadaBusinessSignal(combined)) {
            result.setCountry("Canada");
            result.setLocation("Canada");
            result.setLocationSource("canada-only signal");
            logger.info("LOCATION EXTRACT | website={} | source={} | extracted='Canada'",
                    website, result.getLocationSource());
            return;
        }
        if (hasUsBusinessSignal(combined)) {
            result.setCountry("USA");
            result.setLocation(buildLocationDisplay(null, null, "USA"));
            result.setLocationSource("usa-only signal");
            logger.info("LOCATION EXTRACT | website={} | source={} | extracted='USA'",
                    website, result.getLocationSource());
            return;
        }
        result.setLocation("Unknown");
        result.setLocationSource(null);
        logger.info("LOCATION UNKNOWN | website={} | reason=no address/schema/location signal found | sources_tried={}",
                website, el == null ? "google business, search result, homepage schema, homepage footer, homepage, contact page, about page" : el.source);
    }

    /**
     * REQUIRED-CITY confirmation from OFFICIAL sources only (GATE 4): the
     * structured Google/Firecrawl business address or the buyer's OWN website
     * (schema address, footer, body). The search-listing title/snippet is never
     * consulted - a city word echoed by the engine is not location evidence
     * (requirement 4). Only real "City, ST" / "City, ST ZIP" address forms
     * count; a bare mention of the city without an address is not proof.
     */
    private boolean officialWebsiteConfirmsCity(String homepageHtml, String searchAddress,
                                                String requestedCity) {
        if (requestedCity == null || requestedCity.isBlank()) {
            return false;
        }
        // 1) Structured Google Business / Firecrawl address - the business's own
        //    listing (never free-text snippets).
        if (searchAddress != null && !searchAddress.isBlank()) {
            ExtractedLocation el = extractLocationFromText(searchAddress, "google business");
            if (el != null && el.city != null && sameCity(el.city, requestedCity)) {
                return true;
            }
        }
        if (homepageHtml == null || homepageHtml.isBlank()) {
            return false;
        }
        // 2) The buyer's OWN website, in the same priority the official
        //    extraction uses: schema address, footer, then body.
        String schema = extractSchemaAddress(homepageHtml);
        if (schema != null && !schema.isBlank()) {
            ExtractedLocation el = extractLocationFromText(schema, "homepage schema");
            if (el != null && el.city != null && sameCity(el.city, requestedCity)) {
                return true;
            }
        }
        String footer = extractFooterText(homepageHtml);
        if (footer != null && !footer.isBlank()) {
            ExtractedLocation el = extractLocationFromText(footer, "homepage footer");
            if (el != null && el.city != null && sameCity(el.city, requestedCity)) {
                return true;
            }
        }
        String body = extractBodyText(homepageHtml);
        if (body != null && !body.isBlank()) {
            ExtractedLocation el = extractLocationFromText(body, "homepage");
            if (el != null && el.city != null && sameCity(el.city, requestedCity)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Multi-source business-location extraction used by BOTH the pre-save pinning
     * (resolveBusinessLocation) and the GATE-4 verification. Sources in priority
     * order: Google/Firecrawl business-metadata address, homepage schema.org
     * data, homepage footer, homepage body, then (only when nothing resolved yet)
     * the contact page and the about page fetched with plain HTTP - never a
     * Firecrawl credit. The search-listing title/snippet is NEVER a source: a
     * city word echoed by the engine is not location evidence (requirement 4).
     * Returns null when no reliable city/state exists anywhere. Nothing is ever
     * invented: a bare word is never accepted as a city (only real "City, ST" /
     * ZIP / state patterns count).
     */
    private ExtractedLocation resolveBusinessLocationFrom(String website, String searchAddress,
                                                          String homepageHtml) {
        // Source 1 - the structured Google Business / Firecrawl business address
        // (the business's own listing, never free-text search snippets).
        if (searchAddress != null && !searchAddress.isBlank()) {
            ExtractedLocation el = extractLocationFromText(searchAddress, "google business");
            if (el != null) {
                return el;
            }
        }

        if (homepageHtml != null && !homepageHtml.isBlank()) {
            // Source 3 - schema.org structured data on the homepage.
            String schema = extractSchemaAddress(homepageHtml);
            if (schema != null && !schema.isBlank()) {
                ExtractedLocation el = extractLocationFromText(schema, "homepage schema");
                if (el != null) {
                    return el;
                }
            }
            // Source 4 - homepage footer (most business addresses live there).
            String footer = extractFooterText(homepageHtml);
            if (footer != null && !footer.isBlank()) {
                ExtractedLocation el = extractLocationFromText(footer, "homepage footer");
                if (el != null) {
                    return el;
                }
            }
            // Source 5 - homepage body text (decoded, tag-stripped).
            String body = extractBodyText(homepageHtml);
            if (body != null && !body.isBlank()) {
                ExtractedLocation el = extractLocationFromText(body, "homepage");
                if (el != null) {
                    return el;
                }
            }
        }

        // Sources 6-7 - contact page then about page. Fetched only when the
        // buyer's city/state is still unknown (plain HTTP, no Firecrawl credit),
        // and bounded so an unreachable site cannot trigger a long request burst.
        int fetches = 0;
        for (String path : LOCATION_PAGE_PATHS) {
            if (fetches >= MAX_LOCATION_PAGE_FETCHES) {
                break;
            }
            fetches++;
            boolean contact = path.contains("contact") || path.contains("touch")
                    || path.contains("reach");
            String source = contact ? "contact page" : "about page";
            ExtractedLocation el = extractLocationFromPage(website, path, source);
            if (el != null) {
                return el;
            }
        }
        return null;
    }

    /**
     * Applies an extracted location to the result and logs the website / source
     * / extracted value (requirement: keep every location extract traceable).
     */
    private void applyExtractedLocation(BuyerSearchResult result, ExtractedLocation el) {
        result.setCity(el.city);
        result.setState(el.state);
        // The extracted country is only applied when it agrees with (or the
        // search was for) the searched country - a Canada search can NEVER be
        // re-labelled "USA" because its homepage happens to show a US-looking
        // address. The perfect country gate already verified the page is not
        // decisively US-located, so "Canada" is the only correct label there.
        String searchedCountry = result.getCountry();
        if (el.country != null && (searchedCountry == null
                || el.country.equalsIgnoreCase(searchedCountry))) {
            result.setCountry(el.country);
        }
        result.setLocation(buildLocationDisplay(el.state, el.city, result.getCountry()));
        result.setLocationSource(el.source);
        logger.info("LOCATION EXTRACT | website={} | source={} | extracted='{}' | city={} | state={} | country={}",
                result.getWebsite(), el.source, result.getLocation(),
                el.city, el.state, el.country);
    }

    private ExtractedLocation extractLocationFromPage(String website, String path, String source) {
        String html = emailDiscoveryService.fetchWebsitePage(website, path);
        if (html == null || html.isBlank()) {
            return null;
        }
        try {
            String schema = extractSchemaAddress(html);
            if (schema != null && !schema.isBlank()) {
                ExtractedLocation el = extractLocationFromText(schema, source + " (schema)");
                if (el != null) {
                    return el;
                }
            }
            String body = extractBodyText(html);
            if (body != null && !body.isBlank()) {
                ExtractedLocation el = extractLocationFromText(body, source);
                if (el != null) {
                    return el;
                }
            }
        } catch (Exception e) {
            logger.debug("Location extraction failed on {} for '{}': {}", path, website, e.getMessage());
        }
        return null;
    }

    /**
     * Extracts a reliable city/state from a plain text block. "Reliable" means
     * a real US state / Canadian province (by abbreviation or full name) came
     * with it - a bare word is never accepted as a city. Returns null when no
     * such location is present.
     */
    private ExtractedLocation extractLocationFromText(String rawText, String source) {
        if (rawText == null || rawText.isBlank()) {
            return null;
        }
        String text = buildRawText(rawText);

        // 1. "City ST ZIP" / "City, ST ZIP" (comma optional) - most reliable.
        Matcher m = CITY_STATE_ZIP_PATTERN.matcher(text);
        while (m.find()) {
            String city = cleanCityCandidate(m.group(1));
            String state = stateNameForAbbr(m.group(2));
            if (state != null) {
                return new ExtractedLocation(city, state, countryNameForState(state), source);
            }
        }
        // 2. "City, ST" (no ZIP).
        m = CITY_STATE_PATTERN.matcher(text);
        while (m.find()) {
            String city = cleanCityCandidate(m.group(1));
            String state = stateNameForAbbr(m.group(2));
            if (state != null) {
                return new ExtractedLocation(city, state, countryNameForState(state), source);
            }
        }
        // 3. "City, FullState" (e.g. "Dallas, Texas").
        m = CITY_FULL_STATE_PATTERN.matcher(text);
        while (m.find()) {
            String city = cleanCityCandidate(m.group(1));
            String state = stateFullName(m.group(2));
            if (state != null) {
                return new ExtractedLocation(city, state, countryNameForState(state), source);
            }
        }
        // 4. "ST ZIP" - a state plus a ZIP is still a reliable state.
        m = STATE_ZIP_PATTERN.matcher(text);
        while (m.find()) {
            String state = stateNameForAbbr(m.group(1));
            if (state != null) {
                return new ExtractedLocation(null, state, countryNameForState(state), source);
            }
        }
        // 5. A standalone full state/province name ("We ship from Texas").
        String state = standaloneStateName(text);
        if (state != null) {
            return new ExtractedLocation(null, state, countryNameForState(state), source);
        }
        return null;
    }

    private String stateNameForAbbr(String abbr) {
        if (abbr == null) {
            return null;
        }
        String name = STATE_ABBR_TO_NAME.get(abbr.toUpperCase(Locale.ROOT));
        return name != null ? titleCaseState(name) : null;
    }

    private String stateFullName(String matched) {
        if (matched == null) {
            return null;
        }
        String key = matched.toLowerCase(Locale.ROOT);
        for (String name : US_STATE_NAMES) {
            if (name.equals(key)) {
                return titleCaseState(name);
            }
        }
        for (String name : CANADIAN_PROVINCE_NAMES) {
            if (name.equals(key)) {
                return titleCaseState(name);
            }
        }
        return null;
    }

    private String standaloneStateName(String text) {
        if (text == null) {
            return null;
        }
        String lower = text.toLowerCase(Locale.ROOT);
        for (String name : US_STATE_NAMES) {
            if (containsToken(lower, name)) {
                return titleCaseState(name);
            }
        }
        for (String name : CANADIAN_PROVINCE_NAMES) {
            if (containsToken(lower, name)) {
                return titleCaseState(name);
            }
        }
        return null;
    }

    // Turns the text before ", ST" / "ST ZIP" into a clean, reliable city name.
    // Confirmed known cities win; leading house numbers and street names are
    // stripped; short residues are kept whole and title-cased. A pure street
    // address ("123 Main St") has NO city - null is returned so the buyer keeps
    // only their verified state instead of an invented city.
    private String cleanCityCandidate(String chunk) {
        if (chunk == null) {
            return null;
        }
        String c = chunk.trim();
        if (c.isEmpty()) {
            return null;
        }
        // 1) A known city suffix proves the exact city without guessing.
        String known = knownCitySuffix(c);
        if (known != null) {
            return known;
        }
        // 2) Strip leading house-number tokens ("123 Main St Dallas" -> "Main St Dallas").
        if (c.matches(".*\\d.*")) {
            String[] toks = c.split("\\s+");
            int i = 0;
            while (i < toks.length && toks[i].matches(".*\\d.*")) {
                i++;
            }
            c = joinWhitespace(toks, i, toks.length);
        }
        String[] toks = c.split("\\s+");
        if (toks.length == 0 || (toks.length == 1 && toks[0].isEmpty())) {
            return null;
        }
        // 3) Strip "<street-name> <street-suffix>" pairs when they only preface
        //    a real city ("Main St Dallas" -> "Dallas"). When they ARE the whole
        //    chunk ("123 Main St", "221B Baker Street") no city exists at all.
        int keepFrom = 0;
        while (toks.length - keepFrom >= 2 && isStreetSuffix(toks[keepFrom + 1])) {
            keepFrom += 2;
        }
        int remaining = toks.length - keepFrom;
        if (remaining == 0) {
            return null;
        }
        // 4) Multiword residue: prefer the last two tokens ("Avery Creek").
        if (remaining >= 2) {
            String pair = toks[toks.length - 2] + " " + toks[toks.length - 1];
            // Guard: a trailing single-word street pair ("Oak St") is still a
            // street, not a city - no city can be claimed.
            if (remaining == 2 && (isStreetSuffix(toks[toks.length - 1])
                    || isStreetSuffix(toks[toks.length - 2]))) {
                return null;
            }
            return titleCaseCity(pair);
        }
        return titleCaseCity(joinWhitespace(toks, keepFrom, toks.length));
    }

    private boolean isStreetSuffix(String token) {
        if (token == null) {
            return false;
        }
        String t = token.toLowerCase(Locale.ROOT);
        switch (t) {
            case "st": case "st.": case "street": case "ave": case "ave.":
            case "avenue": case "rd": case "road": case "dr": case "dr.":
            case "drive": case "blvd": case "blvd.": case "boulevard":
            case "ln": case "lane": case "ct": case "court": case "pl":
            case "place": case "way": case "pkwy": case "parkway": case "hwy":
            case "highway": case "sq": case "square": case "trl": case "trail":
            case "cir": case "circle": case "ter": case "terrace": case "ste":
            case "suite": case "unit": case "bldg": case "boulee":
                return true;
            default:
                return false;
        }
    }

    private String knownCitySuffix(String chunk) {
        if (chunk == null) {
            return null;
        }
        String[] toks = chunk.trim().split("\\s+");
        for (int i = 0; i < toks.length; i++) {
            StringBuilder phrase = new StringBuilder();
            for (int j = i; j < toks.length; j++) {
                if (phrase.length() > 0) {
                    phrase.append(' ');
                }
                phrase.append(toks[j]);
            }
            String display = KNOWN_US_CA_CITIES.get(phrase.toString().toLowerCase(Locale.ROOT));
            if (display != null) {
                return display;
            }
        }
        return null;
    }

    private String titleCaseCity(String city) {
        if (city == null) {
            return null;
        }
        String clean = collapseWhitespace(city);
        if (clean == null) {
            return null;
        }
        String[] toks = clean.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String tok : toks) {
            if (tok.isEmpty()) {
                continue;
            }
            String lower = tok.toLowerCase(Locale.ROOT);
            if (lower.equals("st") || lower.equals("st.") || lower.equals("saint")) {
                sb.append("St.");
            } else if (lower.equals("mt") || lower.equals("mt.")) {
                sb.append("Mt.");
            } else if (lower.startsWith("mc") && lower.length() > 2) {
                sb.append("Mc").append(Character.toUpperCase(lower.charAt(2)))
                        .append(lower.substring(3));
            } else {
                sb.append(Character.toUpperCase(lower.charAt(0))).append(lower.substring(1));
            }
            sb.append(' ');
        }
        return sb.toString().trim();
    }

    private String titleCaseState(String name) {
        if (name == null) {
            return null;
        }
        String clean = collapseWhitespace(name);
        if (clean == null) {
            return null;
        }
        String[] toks = clean.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String tok : toks) {
            if (tok.isEmpty()) {
                continue;
            }
            String lower = tok.toLowerCase(Locale.ROOT);
            if (lower.equals("of") || lower.equals("and") || lower.equals("the")) {
                sb.append(lower);
            } else {
                sb.append(Character.toUpperCase(lower.charAt(0))).append(lower.substring(1));
            }
            sb.append(' ');
        }
        return sb.toString().trim();
    }

    private String joinWhitespace(String[] parts, int from, int to) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < to; i++) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(parts[i]);
        }
        return sb.toString();
    }

    private String extractFooterText(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        try {
            Document doc = Jsoup.parse(html);
            Elements footers = doc.select("footer, [class*=footer], [id*=footer], "
                    + "[class*=Footer], [id*=Footer]");
            StringBuilder sb = new StringBuilder();
            for (Element f : footers) {
                String t = f.text();
                if (t != null && !t.isBlank()) {
                    sb.append(t).append(' ');
                }
            }
            return sb.length() == 0 ? null : collapseWhitespace(sb.toString());
        } catch (Exception e) {
            logger.debug("Failed to extract footer text: {}", e.getMessage());
            return null;
        }
    }

    private String extractBodyText(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        try {
            Document doc = Jsoup.parse(html);
            String text = doc.body() != null ? doc.body().text() : doc.text();
            return text == null || text.isBlank() ? null : text;
        } catch (Exception e) {
            logger.debug("Failed to extract page text: {}", e.getMessage());
            return null;
        }
    }

    /** Structured address from a page: schema.org JSON-LD first, then HTML
     *  microdata (itemprop=addressLocality / addressRegion). */
    private String extractSchemaAddress(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        try {
            Document doc = Jsoup.parse(html);
            Elements scripts = doc.select("script[type='application/ld+json']");
            for (Element script : scripts) {
                String json = script.data();
                if (json == null || json.isBlank()) {
                    continue;
                }
                try {
                    JsonNode root = objectMapper.readTree(json);
                    String address = extractSchemaAddressNode(root);
                    if (address != null && !address.isBlank()) {
                        return address;
                    }
                } catch (JsonProcessingException e) {
                    // malformed JSON-LD block - try the next one
                }
            }
            Element locEl = doc.selectFirst("[itemprop=addressLocality]");
            Element regionEl = doc.selectFirst("[itemprop=addressRegion]");
            if (locEl != null || regionEl != null) {
                StringBuilder sb = new StringBuilder();
                if (locEl != null && !locEl.text().isBlank()) {
                    sb.append(locEl.text().trim());
                }
                if (regionEl != null && !regionEl.text().isBlank()) {
                    if (sb.length() > 0) {
                        sb.append(", ");
                    }
                    sb.append(regionEl.text().trim());
                }
                if (sb.length() > 0) {
                    return sb.toString();
                }
            }
        } catch (Exception e) {
            logger.debug("Failed to parse schema data: {}", e.getMessage());
        }
        return null;
    }

    private String extractSchemaAddressNode(JsonNode node) {
        if (node == null) {
            return null;
        }
        if (node.isArray()) {
            for (JsonNode child : node) {
                String found = extractSchemaAddressNode(child);
                if (found != null) {
                    return found;
                }
            }
            return null;
        }
        if (!node.isObject()) {
            return null;
        }
        String locality = textFieldOrNull(node, "addressLocality");
        String region = textFieldOrNull(node, "addressRegion");
        String postal = textFieldOrNull(node, "postalCode");
        if (locality != null || region != null) {
            StringBuilder sb = new StringBuilder();
            if (locality != null) {
                sb.append(locality);
            }
            if (region != null) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(region);
            }
            if (postal != null) {
                sb.append(' ').append(postal);
            }
            return sb.toString();
        }
        JsonNode address = node.get("address");
        if (address != null && address.isObject()) {
            String found = extractSchemaAddressNode(address);
            if (found != null) {
                return found;
            }
        }
        Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
        while (fields.hasNext()) {
            String found = extractSchemaAddressNode(fields.next().getValue());
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    private String textFieldOrNull(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v != null && v.isTextual()) {
            String s = v.asText();
            return s.isBlank() ? null : s.trim();
        }
        return null;
    }

    private boolean hasUsBusinessSignal(String text) {
        if (text == null || text.isBlank()) {
            return false;
        }
        try {
            return UsaVerificationService.STATUS_US.equals(
                    usaVerificationService.verify(text).getStatus());
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasCanadaBusinessSignal(String text) {
        if (text == null || text.isBlank()) {
            return false;
        }
        String lower = text.toLowerCase(Locale.ROOT);
        for (String name : CANADIAN_PROVINCE_NAMES) {
            if (containsToken(lower, name)) {
                return true;
            }
        }
        return CANADA_POSTAL_PATTERN.matcher(lower).find();
    }

    // ------------------------------------------------------------------
    // Home-decor product category gate helpers (used BEFORE any Firecrawl
    // request so invalid products never spend credits).
    // ------------------------------------------------------------------

    private boolean isSupportedHomeDecorProduct(String productEntry) {
        String p = normalizeProductForValidation(productEntry);
        if (p.isEmpty()) {
            return false;
        }
        Set<String> words = new HashSet<>(tokenizeWords(p));
        return isBowlFamilyProduct(p, words)
                || isCandleProduct(p, words)
                || isLanternProduct(p)
                || isDecorativeJarProduct(words)
                || isHomeDecorProduct(p, words)
                || isSoundHealingProduct(p);
    }

    private boolean isSoundHealingProduct(String p) {
        for (String phrase : SOUND_HEALING_TERMS) {
            if (p.contains(phrase)) {
                return true;
            }
        }
        return false;
    }

    private boolean isBowlFamilyProduct(String p, Set<String> words) {
        if (!words.contains("bowl") && !words.contains("bowls")) {
            return false;
        }
        for (String qualifier : SUPPORTED_BOWL_QUALIFIERS) {
            if (words.contains(qualifier)) {
                return true;
            }
        }
        // Alternate phrasings: "sing bowls", "song bowls", "singing bowls".
        return p.contains("sing bowl") || p.contains("song bowl");
    }

    private boolean isCandleProduct(String p, Set<String> words) {
        if (p.contains("candle") || p.contains("candela")) {
            return true;
        }
        return words.contains("votive") || words.contains("votives")
                || words.contains("taper") || words.contains("tapers")
                || words.contains("tealight") || words.contains("tealights")
                || p.contains("tea light") || p.contains("tea lights");
    }

    private boolean isLanternProduct(String p) {
        return p.contains("lantern");
    }

    private boolean isDecorativeJarProduct(Set<String> words) {
        if (!words.contains("jar") && !words.contains("jars")) {
            return false;
        }
        for (String context : DECORATIVE_JAR_CONTEXT) {
            if (words.contains(context)) {
                return true;
            }
        }
        return false;
    }

    /** TRUE when the SEARCHED product is a jar/canister family phrase - the
     *  trigger for the looser jar/canister combo relevance rule. Covering the
     *  related commercial names (glass jars, canisters, containers) so results
     *  found for ANY decorative-jar synonym get the same relaxed processing. */
    private boolean isJarFamilyQuery(String product) {
        return product != null
                && JAR_FAMILY_QUERY_PATTERN.matcher(product.toLowerCase(Locale.ROOT)).find();
    }

    /** Jar/canister combination proof (requirement 1): the site states a
     *  jar-family noun (jar/canister/container) together with a PRODUCT modifier
     *  (decorative, glass, storage, display, apothecary, handle, kitchen...) AND
     *  carries business or local evidence (store, shop, retailer, wholesale,
     *  supplier, boutique, catalog, ..., or a "City, ST" address). This is the
     *  relaxation that lets a real decorative-jar seller that worded its page
     *  differently (e.g. "Set of Blue & White Ribbed Kitchen Canisters", with a
     *  local address) reach homepage verification instead of being auto-
     *  rejected. It still NEVER accepts a naked "jar" mention, and a canning /
     *  lab / pickle page is blocked by JAR_REJECT_CONTEXTS before this runs. */
    private boolean jarComboRelevant(String titleText, String snippetText, String path,
                                     String domain, String homeText) {
        List<String> zones = new ArrayList<>();
        if (titleText != null && !titleText.isBlank()) {
            zones.add(titleText);
        }
        if (snippetText != null && !snippetText.isBlank()) {
            zones.add(snippetText);
        }
        if (path != null && !path.isBlank()) {
            zones.add(path);
        }
        if (domain != null && !domain.isBlank()) {
            zones.add(domain);
        }
        if (homeText != null && !homeText.isBlank()) {
            zones.add(homeText);
        }
        String text = String.join(" ", zones).toLowerCase(Locale.ROOT);
        if (text.isBlank()) {
            return false;
        }
        Set<String> words = new HashSet<>();
        for (String w : tokenizeWords(text)) {
            if (w.length() >= 2) {
                words.add(w);
            }
        }
        boolean jarOrCanister = words.contains("jar") || words.contains("jars")
                || words.contains("canister") || words.contains("canisters");
        boolean containerWord = words.contains("container") || words.contains("containers");
        boolean decoOrGlass = words.contains("decorative") || words.contains("decoration")
                || words.contains("decor") || words.contains("glass");
        // "container" alone is too generic (shipping containers); it only counts
        // with an explicit decorative/glass qualifier.
        if (!jarOrCanister && !(containerWord && decoOrGlass)) {
            return false;
        }
        boolean modifier = false;
        for (String m : JAR_COMBO_MODIFIERS) {
            if (words.contains(m)) {
                modifier = true;
                break;
            }
        }
        if (!modifier) {
            return false;
        }
        for (String b : JAR_COMBO_BUSINESS_EVIDENCE) {
            if (words.contains(b)) {
                return true;
            }
        }
        // "Houston, TX" style local-business addresses count as business evidence.
        return US_CITY_STATE_PATTERN.matcher(text).find();
    }

    /** TRUE when the search evidence (title/snippet/shopping path/domain)
     *  actually declares the jar/canister family - a jar-family noun appears -
     *  as opposed to merely being the searched product label. The handle gate
     *  uses this to distinguish "the page claims the family but never shows a
     *  handle" (rejected for a "jars with handle" product) from "the page does
     *  not claim the jar family at all" (left to the stricter strong-phrase
     *  gate below). */
    private boolean jarFamilyMentioned(String titleText, String snippetText, String path,
                                       String domain) {
        String text = prepareText(titleText, snippetText, path, domain);
        for (String noun : JAR_FAMILY_NOUNS) {
            if (containsPhrase(text, noun)) {
                return true;
            }
        }
        return false;
    }

    /** Returns the handle evidence when the page shows a handle for the
     *  jar/canister family ("with handle", "handles", "handle", "handled"), or
     *  null. A "Jars With Handle" product demands this on any page that claims
     *  the jar family: without it the mention is generic stock, not the
     *  searched product. */
    private String findHandleEvidence(String titleText, String snippetText, String path,
                                      String domain, String homeText) {
        String text = prepareText(titleText, snippetText, path, domain, homeText);
        for (String form : new String[]{"with handle", "handles", "handle", "handled"}) {
            if (containsPhrase(text, form)) {
                return form;
            }
        }
        return null;
    }

    private boolean isHomeDecorProduct(String p, Set<String> words) {
        // Event/party supplies and other non-home venues are never home decor.
        for (String eventWord : EVENT_NON_DECOR_WORDS) {
            if (words.contains(eventWord)) {
                return false;
            }
        }
        // Car decor, cake decorations, clothing, hotels, ... are not home decor.
        for (String nonHomeWord : NON_HOME_DECOR_WORDS) {
            if (words.contains(nonHomeWord)) {
                return false;
            }
        }
        // "decor"/"decorative"/"decoration"/"décor" and every home-* decor
        // phrase (home decor, wall decor, table decor, ...) matches here.
        if (p.contains("decor")) {
            return true;
        }
        for (String phrase : HOME_DECOR_PHRASES) {
            if (p.contains(phrase)) {
                return true;
            }
        }
        return false;
    }

    private String normalizeProductForValidation(String product) {
        if (product == null) {
            return "";
        }
        String normalized = product.toLowerCase(Locale.ROOT)
                .replace('\u00e9', 'e').replace('\u00e8', 'e').replace('\u00ea', 'e')
                .replace('\u00e2', 'a').replace('\u00e0', 'a')
                .replace('\u00f4', 'o')
                .replace('\u00fb', 'u').replace('\u00f9', 'u')
                .replace('\u00ee', 'i').replace('\u00ef', 'i')
                .replace('\u00e7', 'c');
        return normalized.replaceAll("\\s+", " ").trim();
    }

    private List<String> tokenizeWords(String text) {
        return Arrays.stream(text.split("[^a-z0-9]+"))
                .filter(w -> w.length() >= 2)
                .collect(Collectors.toList());
    }

    /**
     * Builds raw (original-case, punctuation-preserved) concatenated text from
     * the given parts, with HTML tags removed. Used for address-pattern checks
     * such as "city, ST" where comma placement carries meaning.
     */
    private String buildRawText(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part == null) {
                continue;
            }
            sb.append(part).append(' ');
        }
        return sb.toString().replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim();
    }

    /**
     * Matches a US state abbreviation in an address context within raw text:
     * either right after a comma (", TX") or directly before a ZIP code
     * ("TX 79901"). Comparing with the full state-name or ZIP-only checks, this
     * accepts the very common "City, ST" address form without ZIP.
     */
    private boolean containsStateAbbrevAddress(String rawText, String abbrev) {
        if (rawText == null || abbrev == null) {
            return false;
        }
        Pattern commaAbbrev = Pattern.compile(",\\s*" + Pattern.quote(abbrev) + "\\b",
                Pattern.CASE_INSENSITIVE);
        if (commaAbbrev.matcher(rawText).find()) {
            return true;
        }
        Pattern abbrevZip = Pattern.compile("\\b" + Pattern.quote(abbrev) + "\\s+\\d{5}\\b",
                Pattern.CASE_INSENSITIVE);
        return abbrevZip.matcher(rawText).find();
    }

    private boolean hasConflictingState(String text, String expectedState) {
        for (String usState : US_STATE_NAMES) {
            if (usState.equals(expectedState)) {
                continue;
            }
            if ("washington".equals(expectedState) && "washington state".equals(usState)) {
                continue;
            }
            if (containsToken(text, usState)) {
                logger.debug("Conflicting US state '{}' found in evidence", usState);
                return true;
            }
        }
        return false;
    }

    /** TRUE when the raw text carries a reliable ADDRESS-form signal for a US
     *  state OTHER than the one requested (", ST" or "ST ZIP"), with nothing for
     *  the requested abbreviation. A bare state-name mention ("now shipping to
     *  New York") is NOT enough - only a real address form proves the business
     *  is physically located in that state. */
    private boolean showsConflictingStateAddress(String rawText, String requestedAbbrev) {
        if (rawText == null || rawText.isBlank()) {
            return false;
        }
        String lower = prepareText(rawText.toLowerCase(Locale.ROOT));
        for (String abbr : STATE_ABBR_TO_NAME.keySet()) {
            if (abbr.equals(requestedAbbrev)) {
                continue;
            }
            if (containsStateAbbrevAddress(rawText, abbr)) {
                return true;
            }
            if (containsStateZip(lower, abbr)) {
                return true;
            }
        }
        return false;
    }

    private boolean containsStateZip(String text, String abbrev) {
        // text was normalized to lowercase with punctuation collapsed to spaces,
        // so both "Houston, TX 77001" and "Houston TX 77001" read as "houston tx 77001".
        String upper = text.toUpperCase();
        return Pattern.compile("\\b" + Pattern.quote(abbrev) + "\\s+\\d{5}\\b")
                .matcher(upper).find();
    }

    private String prepareText(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part == null) {
                continue;
            }
            sb.append(part).append(' ');
        }
        String cleaned = sb.toString()
                .replaceAll("<[^>]*>", " ")
                .replaceAll("&amp;", "&")
                .replaceAll("&nbsp;", " ")
                .replaceAll("&#\\d+;", " ")
                .replaceAll("\\p{Punct}", " ");
        return " " + cleaned.replaceAll("\\s+", " ").toLowerCase() + " ";
    }

    private String normalizeForComparison(String s) {
        if (s == null) {
            return null;
        }
        return s.toLowerCase().replaceAll("\\p{Punct}", " ").replaceAll("\\s+", " ").trim();
    }

    private boolean containsToken(String text, String token) {
        return Pattern.compile("(?<![a-z0-9])" + Pattern.quote(token) + "(?![a-z0-9])")
                .matcher(text).find();
    }

    // ------------------------------------------------------------------
    // Cheap page-type & business-identity screening - URL + title only, no
    // homepage fetch. Runs before verification/email scraping so rejected,
    // duplicate, irrelevant and non-buyer results never cost processing.
    // ------------------------------------------------------------------

    /**
     * Returns a "REJECTED - ..." reason when the page must be dropped, or null
     * when it may represent a real buyer business and deserves deeper
     * (homepage-based) verification. Marketplaces are NOT rejected by domain:
     * a page that clearly identifies a distinct relevant seller business
     * passes, a generic product/listing page is rejected.
     */
    private String classifyPage(String url, String title, String product) {
        String hostL = hostOf(url) == null ? "" : hostOf(url);
        String path = pathOf(url) == null ? "" : pathOf(url);
        String query = queryOf(url) == null ? "" : queryOf(url);
        String t = title == null ? "" : title;
        String tL = t.toLowerCase();

        // Files / documents (PDFs, office docs, archives, images...) are never
        // buyer business pages.
        if (isFileUrl(path)) {
            return REJECT_FILE;
        }

        // Academic / research pages (universities, journals, working papers).
        if (isAcademicLike(hostL, path, tL)) {
            return REJECT_ACADEMIC;
        }

        // Government websites are never buyers.
        if (hostL.matches("(?i).*\\.gov(\\.[a-z]{2})?$") || hostL.endsWith(".mil")
                || path.contains("/gov")
                || tL.contains("department of") || tL.contains("ministry of")
                || tL.contains("official website of")) {
            return REJECT_GOV;
        }

        // Blogs / articles / news / pure content pages are not buyer businesses.
        if (isArticleLike(hostL, path, tL)) {
            return REJECT_ARTICLE;
        }

        // Directories / forums / listing aggregators are not buyer businesses.
        if (isDirectoryLike(hostL, path, tL)) {
            return REJECT_NOT_BUYER;
        }

        boolean marketplace = isShoppingHost(hostL);
        boolean platform = isPlatformHost(hostL);
        boolean productPath = matchesAny(path, SHOPPING_PATH_MARKERS);
        boolean shoppingQuery = containsAnyKey(query, SHOPPING_QUERY_KEYS);
        boolean shoppingTitle = matchesAny(tL, SHOPPING_TITLE_MARKERS)
                || PRICE_PATTERN.matcher(t).find();
        boolean productDetail = productPath || shoppingQuery;

        if (marketplace) {
            // ANY page on a marketplace is rejected outright. A listing may
            // identify a plausible seller brand, but the "domain" is the
            // marketplace itself (etsy.com, ebay.com, faire.com, atly.com,
            // importyeti.com...) - it is not the seller's own business website
            // and never has its own product catalog/contact ownership. Only a
            // business with its own website is a genuine buyer.
            logger.info("BUSINESS EVIDENCE | MARKETPLACE '{}' - rejecting listing on marketplace host", url);
            return REJECT_SHOPPING;
        }

        if (productDetail || shoppingTitle || platform) {
            // Generic shopping pages (search/product listing pages, unbranded
            // platform storefronts) are rejected; a page that identifies a
            // distinct seller business may still be a genuine buyer.
            String brand = bestBrandSegment(tL, product);
            boolean distinctSeller = brand != null && isMeaningfulName(brand, product)
                    && !mentionsAggregator(brand) && hasGenuineBrandWord(brand);
            if (distinctSeller) {
                return null;
            }
            return REJECT_SHOPPING;
        }

        return null;
    }

    /** First title segment (before any separator) - the place a company name
     *  is expected on marketplace storefronts and branded catalogs. */
    private String leadingBrandSegment(String title, String product) {
        if (title == null || title.isBlank()) {
            return null;
        }
        String cleaned = cleanTitle(title);
        List<String> segments = splitSegments(cleaned);
        if (segments.isEmpty()) {
            return null;
        }
        return segments.get(0);
    }

    private boolean isFileUrl(String path) {
        if (path == null || path.isEmpty()) {
            return false;
        }
        String p = path.toLowerCase();
        int lastSlash = p.lastIndexOf('/');
        String tail = lastSlash >= 0 ? p.substring(lastSlash + 1) : p;
        if (tail.isEmpty() || !tail.contains(".")) {
            return false;
        }
        String ext = tail.substring(tail.lastIndexOf('.') + 1).toLowerCase();
        return FILE_EXTENSIONS.contains(ext);
    }

    private boolean isAcademicLike(String host, String path, String titleLower) {
        if (host.endsWith(".edu") || host.contains(".edu.")
                || host.endsWith(".ac.uk") || host.endsWith(".ac.in")
                || host.endsWith(".ac.jp") || host.endsWith(".ac.id")) {
            return true;
        }
        if (path != null) {
            for (String marker : ACADEMIC_PATH_MARKERS) {
                if (path.contains(marker)) {
                    return true;
                }
            }
        }
        if (titleLower != null) {
            for (String marker : ACADEMIC_TITLE_MARKERS) {
                if (titleLower.contains(marker)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isArticleLike(String host, String path, String titleLower) {
        if (host.contains("wordpress.com") || host.contains("blog.")
                || host.contains("medium.com") || host.contains("substack.com")
                || host.contains("tumblr.com")) {
            return true;
        }
        // Podcast episodes are content, never buyer businesses. This covers
        // podcast.substack / apple podcasts / spotify / podbean / buzzsprout
        // and any host, path or TITLE carrying the word "podcast" - a podcast
        // page is content even when the host domain does not say "podcast"
        // (e.g. disruptors.com "Disruptors Podcast").
        if (host.contains("podcast") || host.contains("podbean")
                || host.contains("buzzsprout") || host.contains("anchor.fm")
                || path.contains("/podcast") || path.contains("/episode")
                || path.contains("/episodes")
                || (titleLower != null && titleLower.contains("podcast"))) {
            return true;
        }
        // Music / audio-streaming platforms are content distributors, never
        // buyer businesses for a product.
        for (String mediaHost : MEDIA_CONTENT_HOSTS) {
            if (host.equals(mediaHost) || host.endsWith("." + mediaHost)) {
                return true;
            }
        }
        for (String part : CONTENT_NEWS_HOST_PARTS) {
            if (host.contains(part)) {
                return true;
            }
        }
        if (path.contains("/blog") || path.contains("/news")
                || path.contains("/article") || path.contains("/press")
                || path.contains("/insights") || path.contains("/resources")
                || path.matches(".*/20\\d{2}/\\d{2}/.*")) {
            return true;
        }
        if (titleLower != null) {
            for (String marker : ARTICLE_TITLE_MARKERS) {
                if (titleLower.contains(marker)) {
                    return true;
                }
            }
            // Event / ticket / workshop pages (sound baths, classes, retreats,
            // concerts) describe a happening, not a business that sells the
            // product - and title links like "Buy Tickets" are explicit event
            // commerce, not product commerce.
            if (titleLower.contains("tickets") || titleLower.contains("ticket")
                    || titleLower.contains("eventbrite") || titleLower.contains("event")
                    || titleLower.contains("workshop") || titleLower.contains("workshops")
                    || titleLower.contains("retreat") || titleLower.contains("retreats")
                    || titleLower.contains("sound bath") || titleLower.contains("sound baths")
                    || titleLower.contains("sound healing session")
                    || titleLower.contains("meditation session")) {
                return true;
            }
            if (titleLower.endsWith("- blog") || titleLower.endsWith("| blog")
                    || titleLower.endsWith("- news") || titleLower.endsWith(" news")
                    || titleLower.endsWith("| news")
                    || titleLower.contains(" - wikipedia") || titleLower.contains(" | wikipedia")) {
                return true;
            }
        }
        return false;
    }

    private boolean isDirectoryLike(String host, String path, String titleLower) {
        if (host.contains("directory") || host.contains("yellowpages")
                || host.contains("classified") || host.contains("listings")
                || host.contains("cybo") || host.contains("thomsonlocal")
                || host.contains("forum") || host.contains("discussion")
                || host.contains("bulletinboard")) {
            return true;
        }
        if (path.contains("/directory") || path.contains("/classified")
                || path.contains("/forum") || path.contains("/forums")
                || path.contains("/discussion") || path.contains("/thread/")
                || path.contains("/threads")) {
            return true;
        }
        if (titleLower != null) {
            for (String marker : DIRECTORY_TITLE_MARKERS) {
                if (titleLower.contains(marker)) {
                    return true;
                }
            }
            if (titleLower.contains("forum") || titleLower.contains("discussion")) {
                return true;
            }
        }
        return false;
    }

    private boolean isShoppingHost(String host) {
        if (host == null || host.isEmpty()) {
            return false;
        }
        return SHOPPING_HOSTS.contains(host)
                || host.contains("ubuy") || host.contains("desertcart");
    }

    private boolean isPlatformHost(String host) {
        if (host == null) {
            return false;
        }
        for (String suffix : PLATFORM_HOST_SUFFIXES) {
            if (host.endsWith(suffix)) {
                return true;
            }
        }
        return false;
    }

    private boolean matchesAny(String text, Set<String> markers) {
        if (text == null || text.isEmpty()) {
            return false;
        }
        for (String marker : markers) {
            if (text.contains(marker)) {
                return true;
            }
        }
        return false;
    }

    private boolean containsAnyKey(String query, Set<String> keys) {
        if (query == null || query.isEmpty()) {
            return false;
        }
        String q = query.toLowerCase();
        for (String part : q.split("&")) {
            int eq = part.indexOf('=');
            String key = eq >= 0 ? part.substring(0, eq) : part;
            if (keys.contains(key)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Derives the meaningful business/company name from the result: the best
     * title segment, falling back to a name derived from the site's own domain
     * so a "-" or bare product-title result is never used as a buyer name.
     */
    private String extractBusinessName(BuyerSearchResult result, String product) {
        String title = result.getRawTitle() != null ? result.getRawTitle() : result.getCompanyName();
        String name = bestBrandSegment(title, product);
        if (name != null && isMeaningfulName(name, product)) {
            return name;
        }
        String hostName = businessNameFromHost(result.getWebsite());
        if (hostName != null && isMeaningfulName(hostName, product)) {
            return hostName;
        }
        return null;
    }

    /**
     * Picks the title segment that most looks like a company name: most words
     * that are neither stopwords nor product terms, preferring non-aggregator
     * segments ("Blue Gem Trading" over "Ubuy India").
     */
    private String bestBrandSegment(String title, String product) {
        if (title == null || title.isBlank()) {
            return null;
        }
        String cleaned = cleanTitle(title);
        String best = null;
        int bestMeaningful = 0;
        boolean bestAggregator = false;
        for (String seg : splitSegments(cleaned)) {
            int meaningful = meaningfulNameWords(seg, product).size();
            if (meaningful == 0) {
                continue;
            }
            boolean aggregator = mentionsAggregator(seg);
            if (best == null || meaningful > bestMeaningful
                    || (meaningful == bestMeaningful && !aggregator && bestAggregator)) {
                best = seg;
                bestMeaningful = meaningful;
                bestAggregator = aggregator;
            }
        }
        return best;
    }

    private boolean isMeaningfulName(String name, String product) {
        if (name == null) {
            return false;
        }
        String n = name.trim();
        if (n.isEmpty() || "-".equals(n) || "\u2014".equals(n) || "\u2013".equals(n)) {
            return false;
        }
        if (n.length() < 2) {
            return false;
        }
        String productTrim = product == null ? "" : product.trim();
        if (!productTrim.isEmpty() && n.equalsIgnoreCase(productTrim)) {
            return false;
        }
        // Entirely composed of stopwords / product terms (e.g. a bare "Singing
        // Bowls" title) is a generic product page, not a business identity.
        return !meaningfulNameWords(n, product).isEmpty();
    }

    /** Words that are neither stopwords nor product terms, i.e. brand words. */
    private Set<String> meaningfulNameWords(String text, String product) {
        Set<String> productTerms = new HashSet<>(significantTerms(product));
        Set<String> result = new LinkedHashSet<>();
        if (text == null) {
            return result;
        }
        for (String word : text.toLowerCase().split("[^a-z0-9]+")) {
            if (word.length() < 2 || STOPWORDS.contains(word) || productTerms.contains(word)) {
                continue;
            }
            result.add(word);
        }
        return result;
    }

    /** True when the text contains a word that is genuinely a brand word (not a
     *  marketplace identity, commerce stopword or aggregator name). */
    private boolean hasGenuineBrandWord(String name) {
        if (name == null) {
            return false;
        }
        for (String word : name.toLowerCase().split("[^a-z0-9]+")) {
            if (word.length() < 2) {
                continue;
            }
            if (COMMERCE_NOISE_WORDS.contains(word) || AGGREGATOR_BRANDS.contains(word)) {
                continue;
            }
            return true;
        }
        return false;
    }

    private boolean mentionsAggregator(String name) {
        if (name == null) {
            return false;
        }
        String n = name.toLowerCase();
        for (String brand : AGGREGATOR_BRANDS) {
            if (containsToken(n, brand)) {
                return true;
            }
        }
        return false;
    }

    private String businessNameFromHost(String website) {
        String host = hostOf(website);
        if (host == null || host.isEmpty()) {
            return null;
        }
        String h = host;
        for (String suffix : PLATFORM_HOST_SUFFIXES) {
            if (h.endsWith(suffix)) {
                h = h.substring(0, h.length() - suffix.length());
            }
        }
        if (h.isEmpty()) {
            return null;
        }
        StringBuilder out = new StringBuilder();
        for (String part : h.split("[.]")) {
            if (part.length() < 2 || LOW_SIGNAL_DOMAIN_PARTS.contains(part)) {
                continue;
            }
            if (out.length() > 0) {
                out.append(' ');
            }
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.length() == 0 ? null : out.toString();
    }

    private String normalizeBusinessKey(String name) {
        if (name == null) {
            return null;
        }
        String k = name.toLowerCase().replaceAll("\\s+", " ").trim();
        k = k.replaceAll("^the\\s+", "");
        k = k.replaceAll("\\b(?:llc|inc|incorporated|corp|corporation|ltd|limited|co|company|pvt|private limited|gmbh|pty|plc)\\b\\.?", " ");
        k = k.replaceAll("\\s+", " ").trim();
        return k.isEmpty() ? null : k;
    }

    private String cleanTitle(String title) {
        if (title == null) {
            return null;
        }
        String t = title
                .replaceAll("(?i)\\b(add to cart|buy now|shop now|free shipping|order now|best price|low price|compare prices|online shopping|in stock|limited time offer|checkout)\\b", " ")
                .replaceAll("[$\\u20AC\\u00A3\\u20B9]\\s?\\d+(?:[.,]\\d+)*", " ")
                .replaceAll("\\b(?:u\\$d|usd|inr|eur|gbp|rs\\.?)\\s?\\d+(?:[.,]\\d+)*", " ")
                .replaceAll("\\s+", " ")
                .trim();
        return t.isEmpty() ? title.trim() : t;
    }

    private List<String> splitSegments(String text) {
        if (text == null || text.isBlank()) {
            return List.of();
        }
        List<String> segments = new ArrayList<>();
        for (String part : text.split("\\s*\\R\\s*|\\s*[\\||:;]\\s*|\\s+(?:-|\u2014|\u2013)\\s+|\\s*[()]\\s*")) {
            String seg = part.trim();
            if (!seg.isEmpty()) {
                segments.add(seg);
            }
        }
        return segments;
    }

    private String hostOf(String url) {
        if (url == null || url.isEmpty()) {
            return null;
        }
        try {
            URI uri = URI.create(url);
            String host = uri.getHost();
            if (host == null || host.isEmpty()) {
                return null;
            }
            host = host.toLowerCase();
            if (host.startsWith("www.")) {
                host = host.substring(4);
            }
            return host;
        } catch (Exception e) {
            return null;
        }
    }

    private String pathOf(String url) {
        if (url == null || url.isEmpty()) {
            return "";
        }
        try {
            URI uri = URI.create(url);
            String path = uri.getPath();
            return (path == null ? "" : path).toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private String queryOf(String url) {
        if (url == null || url.isEmpty()) {
            return "";
        }
        try {
            URI uri = URI.create(url);
            String query = uri.getQuery();
            return query == null ? "" : query.toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private String collapseWhitespace(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim().replaceAll("\\s+", " ");
        return t.isEmpty() ? null : t;
    }

    // ------------------------------------------------------------------
    // LinkedIn & Facebook targeting (site:linkedin.com / site:facebook.com)
    // ------------------------------------------------------------------

    /**
     * Fires the dedicated LinkedIn/Facebook search pass for the user's product
     * + location, drawing from the SAME shared per-search Firecrawl budget as
     * the exact/web passes (so web + social together stay within the 6-request
     * cap). Only company / showcase pages (LinkedIn) and business-style page
     * slugs (Facebook) are accepted; individual person profiles and search/home
     * pages are skipped. Verification uses the search-result evidence only
     * (LinkedIn/Facebook block plain HTTP scraping) - product relevance and
     * location are checked exactly like the cheap-screen checks of the web
     * pipeline.
     */
    private List<BuyerSearchResult> runSocialSearch(String queryProduct, String userProductLabel,
                                                     String stateValue, String selectedCity,
                                                     String countryNameFull, String countryWord,
                                                     String apiKey, SearchBudget budget,
                                                     int maxResults,
                                                     Set<String> existingSocialWebsites,
                                                     Set<String> socialSeen) {
        List<BuyerSearchResult> social = new ArrayList<>();
        if (queryProduct == null || queryProduct.isBlank() || maxResults <= 0) {
            return social;
        }
        if (budget.exhausted()) {
            return social;
        }

        // The SAME location the user selected: "City" State / State / country word.
        String locPart;
        if (selectedCity != null && !selectedCity.isBlank()) {
            locPart = "\"" + selectedCity.trim() + "\""
                    + (stateValue != null && !stateValue.isBlank() ? " " + stateValue.trim() : "");
        } else if (stateValue != null && !stateValue.isBlank()) {
            locPart = stateValue.trim();
        } else {
            locPart = countryWord != null ? countryWord : countryNameFull;
        }
        Combo combo = new Combo(queryProduct, queryProduct, stateValue, selectedCity, countryNameFull);
        String firecrawlLocation = buildFirecrawlLocation(combo);

        for (String siteOp : new String[]{"site:linkedin.com", "site:facebook.com"}) {
            if (budget.exhausted() || social.size() >= maxResults) {
                break;
            }
            String platform = "site:linkedin.com".equals(siteOp) ? "LinkedIn" : "Facebook";
            String query = "\"" + queryProduct.trim() + "\" " + locPart + " " + siteOp;

            List<BuyerSearchResult> results;
            try {
                results = executeSearch(query, "Buyer", apiKey, RESULTS_PER_QUERY,
                        firecrawlLocation, budget, true);
            } catch (BudgetExhaustedException e) {
                logger.warn("SOCIAL SEARCH stopped - {}", e.getMessage());
                break;
            } catch (Exception e) {
                logger.error("SOCIAL SEARCH failed for '{}': {}", query, e.getMessage());
                continue;
            }

            int accepted = 0;
            int skipped = 0;
            for (BuyerSearchResult result : results) {
                if (social.size() >= maxResults) {
                    break;
                }
                String url = result.getWebsite();

                // Only company/showcase (LinkedIn) and business-page style
                // (Facebook) URLs. Individual people profiles (/in/, /profile/,
                // numeric page ids) never become buyers.
                if (!isSocialBusinessPage(url)) {
                    skipped++;
                    logger.info("{} | '{}' ({}) - not a LinkedIn company / Facebook business page",
                            CODE_INVALID_CONTENT, result.getRawTitle(), url);
                    continue;
                }

                // Dedup against already-saved social pages and this search.
                String socialKey = normalizeSocialUrl(url);
                if (socialKey == null) {
                    skipped++;
                    continue;
                }
                if (existingSocialWebsites.contains(socialKey)) {
                    skipped++;
                    logger.info("{} '{}' ({}) - social page already in the buyer database",
                            CODE_ALREADY_IN_DATABASE, result.getRawTitle(), url);
                    continue;
                }
                if (!socialSeen.add(socialKey)) {
                    skipped++;
                    logger.info("{} '{}' ({}) - social page already returned this search",
                            CODE_DUPLICATE, result.getRawTitle(), url);
                    continue;
                }

                // Business identity from the profile slug (most reliable), with
                // the cleaned page title as fallback.
                String name = extractSocialBusinessName(url, result.getRawTitle());
                if (name == null) {
                    skipped++;
                    logger.info("{} '{}' ({}) - no business identity in social page",
                            CODE_NO_COMPANY_IDENTITY, result.getRawTitle(), url);
                    continue;
                }

                // Product relevance is verified against the search evidence
                // (title + snippet) with the same gate as the web pipeline.
                String evidence = buildEvidence(result);
                if (isProductRelevant(result.getRawTitle(), result.getSnippet(), url, null,
                            queryProduct, result.getSearchQuery() != null
                                    ? result.getSearchQuery() : queryProduct) == null) {
                    skipped++;
                    logger.info("{} '{}' ({}) - evidence does not mention '{}'",
                            CODE_WRONG_PRODUCT, result.getRawTitle(), url, queryProduct);
                    continue;
                }

                // Location: ONLY a decisive non-US signal rejects an unconstrained
                // search. For a search constrained to a requested city/state, a
                // social page that does NOT confirm the requested city/state is
                // rejected too - SAME_COUNTRY no longer rescues a page outside
                // the requested region (requirements 2/3).
                String evidenceRaw = buildRawText(evidence);
                if (hasNonUsBusinessLocationSignal(evidenceRaw) || hasForeignTld(url)
                        || hasForeignHostSignal(url, evidenceRaw)) {
                    skipped++;
                    logger.info("{} '{}' ({}) - social page points outside USA/Canada",
                            CODE_WRONG_LOCATION, result.getRawTitle(), url);
                    continue;
                }
                String socialClass = socialLocationClass(evidence, countryNameFull,
                        stateValue, selectedCity);
                if (socialClass == null) {
                    String requestedRegion = (selectedCity != null && !selectedCity.isBlank()
                            ? "city '" + selectedCity + "'" : "")
                            + (stateValue != null && !stateValue.isBlank()
                            ? ((selectedCity != null && !selectedCity.isBlank() ? ", " : "")
                            + "state '" + stateValue + "'") : "");
                    skipped++;
                    logger.info("{} '{}' ({}) - social page location not confirmed in requested {}",
                            CODE_WRONG_LOCATION, result.getRawTitle(), url, requestedRegion);
                    continue;
                }

                result.setWebsite(url);
                result.setCompanyName(name);
                result.setBuyerName(name);
                result.setProductName(userProductLabel);
                result.setSearchProduct(queryProduct);
                result.setBusinessType("Buyer");
                result.setClassification(PRODUCT_RELEVANT_CLASSIFICATION);
                result.setSourceUrl(url);
                result.setLocationClass(socialClass);
                result.setRelevanceScore(relevanceScoreOf(
                        "LISTING (social page evidence)", null, "Buyer"));
                applySocialLocation(result, evidence, countryNameFull, stateValue, selectedCity);
                logger.info("ACCEPTED [{}] '{}' ({}) - social page relevant to '{}' in {}/{} [{}={}]",
                        platform, name, url, queryProduct,
                        result.getState() != null ? result.getState() : "any",
                        result.getCity() != null ? result.getCity() : "any",
                        result.getLocationClass() != null ? result.getLocationClass() : "UNKNOWN",
                        result.getLocation() != null ? result.getLocation() : "unknown");
                social.add(result);
                accepted++;
            }
            logger.info("SOCIAL SEARCH | platform={} | query='{}' | raw={} | accepted={} | skipped={}",
                    platform, query, results.size(), accepted, skipped);
        }
        return social;
    }

    private void applySocialLocation(BuyerSearchResult result, String evidence,
                                     String countryNameFull, String stateValue, String selectedCity) {
        String evidenceText = prepareText(evidence);
        String countryValue = countryNameFull != null ? countryNameFull : "USA";
        result.setCountry(countryValue);
        boolean cityPresent = selectedCity != null && !selectedCity.isBlank()
                && containsToken(evidenceText, selectedCity.toLowerCase(Locale.ROOT));
        boolean statePresent = stateValue != null && !stateValue.isBlank()
                && containsToken(evidenceText, stateValue.toLowerCase(Locale.ROOT));
        if (selectedCity != null && !selectedCity.isBlank() && cityPresent) {
            result.setState(collapseWhitespace(stateValue));
            result.setCity(selectedCity.trim());
            result.setLocation(buildLocationDisplay(stateValue, selectedCity.trim(), countryValue));
            result.setLocationSource("social page (searched city)");
        } else if (selectedCity == null && stateValue != null && !stateValue.isBlank()
                && statePresent) {
            // A state-level fallback is allowed ONLY when no specific city was
            // requested - a searched city is never silently broadened.
            result.setState(collapseWhitespace(stateValue));
            result.setCity(null);
            result.setLocation(buildLocationDisplay(stateValue, null, countryValue));
            result.setLocationSource("social page (searched state)");
        } else {
            result.setState(null);
            result.setCity(null);
            result.setLocation(countryValue);
            result.setLocationSource("social page (country)");
        }
    }

    /** Location-priority class for a social page (title/snippet only): EXACT_CITY
     *  when the requested city appears, SAME_STATE when the requested state does.
     *  For a search constrained to a requested city/state, a page that confirms
     *  neither is NOT a valid result and returns null (rejected) - SAME_COUNTRY
     *  is reserved for truly unconstrained country-wide searches. */
    private String socialLocationClass(String evidence, String countryNameFull,
                                       String stateValue, String selectedCity) {
        String evidenceText = prepareText(evidence);
        boolean constrained = (selectedCity != null && !selectedCity.isBlank())
                || (stateValue != null && !stateValue.isBlank());
        boolean cityPresent = selectedCity != null && !selectedCity.isBlank()
                && containsToken(evidenceText, selectedCity.toLowerCase(Locale.ROOT));
        boolean statePresent = stateValue != null && !stateValue.isBlank()
                && containsToken(evidenceText, stateValue.toLowerCase(Locale.ROOT));
        if (cityPresent) {
            return LOCATION_CLASS_EXACT_CITY;
        }
        if (statePresent) {
            return LOCATION_CLASS_SAME_STATE;
        }
        return constrained ? null : LOCATION_CLASS_SAME_COUNTRY;
    }

    /** True for LinkedIn company/showcase pages and Facebook business-page URLs. */
    private boolean isSocialBusinessPage(String url) {
        String host = hostOf(url);
        if (host == null) {
            return false;
        }
        if (host.equals("linkedin.com") || host.endsWith(".linkedin.com")) {
            return socialSlugOfLinkedIn(url) != null;
        }
        if (host.equals("facebook.com") || host.endsWith(".facebook.com")) {
            return socialSlugOfFacebook(url) != null;
        }
        return false;
    }

    private String socialSlugOfLinkedIn(String url) {
        String path = pathOf(url);
        String[] segs = path.split("/");
        for (int i = 0; i < segs.length - 1; i++) {
            if ("company".equals(segs[i]) || "showcase".equals(segs[i])) {
                String slug = segs[i + 1];
                if (slug.isEmpty() || "pages".equals(slug)) {
                    return null;
                }
                String trimmed = slug.replaceAll("[.?].*$", "").trim();
                return trimmed.isEmpty() ? null : trimmed;
            }
        }
        return null;
    }

    private String socialSlugOfFacebook(String url) {
        String path = pathOf(url);
        String lastAlpha = null;
        for (String seg : path.split("/")) {
            if (seg.isEmpty()) {
                continue;
            }
            String s = seg.toLowerCase(Locale.ROOT);
            if ("pages".equals(s) || "category".equals(s) || "profile.php".equals(s)
                    || "groups".equals(s) || "events".equals(s) || "watch".equals(s)
                    || "login".equals(s) || "messages".equals(s) || "share".equals(s)) {
                continue;
            }
            // A numeric page id cannot provide a business name.
            if (s.matches("\\d+")) {
                return null;
            }
            if (s.chars().anyMatch(Character::isLetter)) {
                lastAlpha = seg;
            }
        }
        return lastAlpha;
    }

    /** Friendly company name from the social handle (e.g. "blue-gem-trading" ->
     *  "Blue Gem Trading"). Returns null when the handle carries no brand. */
    private String slugToCompanyName(String slug) {
        if (slug == null) {
            return null;
        }
        String cleaned = slug.replaceAll("[_-]+", " ")
                .replaceAll("[^a-zA-Z0-9 ]+", " ")
                .replaceAll("\\s+", " ").trim();
        if (cleaned.isEmpty()) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        int kept = 0;
        for (String tok : cleaned.split(" ")) {
            if (tok.length() < 2) {
                continue;
            }
            String lower = tok.toLowerCase(Locale.ROOT);
            if (COMMERCE_NOISE_WORDS.contains(lower)) {
                continue;
            }
            sb.append(Character.toUpperCase(tok.charAt(0))).append(tok.substring(1)).append(' ');
            kept++;
        }
        return kept == 0 ? null : sb.toString().trim();
    }

    /** Business identity for a social page: the profile slug first, then the
     *  cleaned page title (platform suffix stripped) as fallback. */
    private String extractSocialBusinessName(String url, String title) {
        String slug = null;
        String host = hostOf(url);
        if (host != null && (host.equals("linkedin.com") || host.endsWith(".linkedin.com"))) {
            slug = socialSlugOfLinkedIn(url);
        } else if (host != null && (host.equals("facebook.com") || host.endsWith(".facebook.com"))) {
            slug = socialSlugOfFacebook(url);
        }
        if (slug != null) {
            String fromSlug = slugToCompanyName(slug);
            if (fromSlug != null) {
                return fromSlug;
            }
        }
        if (title != null && !title.isBlank()) {
            String cleaned = title
                    .replaceAll("(?i)\\s+\\|\\s*(?:linkedin|facebook).*$", "")
                    .replaceAll("(?i)\\s+-\\s*(?:home|official|facebook|linkedin).*$", "")
                    .replaceAll("(?i)\\s+\\|\\s+.*$", "")
                    .trim();
            if (cleaned.length() >= 2 && cleaned.length() <= 120) {
                return cleaned;
            }
        }
        return null;
    }

    /** Registry key for a social profile URL (host + lowercase path, no
     *  trailing slash) used to dedupe already-saved social pages. */
    private String normalizeSocialUrl(String url) {
        if (url == null) {
            return null;
        }
        try {
            URI uri = URI.create(url.trim());
            String key = (uri.getHost() == null ? "" : uri.getHost().toLowerCase())
                    + (uri.getPath() == null ? "" : uri.getPath().toLowerCase());
            while (key.endsWith("/")) {
                key = key.substring(0, key.length() - 1);
            }
            return key.isEmpty() ? null : key;
        } catch (Exception e) {
            String key = url.trim().toLowerCase(Locale.ROOT);
            while (key.endsWith("/")) {
                key = key.substring(0, key.length() - 1);
            }
            return key.isEmpty() ? null : key;
        }
    }

    private Set<String> loadExistingSocialWebsites() {
        Set<String> normalized = new HashSet<>();
        try {
            Set<String> stored = buyerRepository.findSocialWebsiteValues();
            if (stored != null) {
                for (String website : stored) {
                    String n = normalizeSocialUrl(website);
                    if (n != null && !n.isEmpty()) {
                        normalized.add(n);
                    }
                }
            }
        } catch (Exception e) {
            logger.warn("Failed to load existing social websites from DB: {}", e.getMessage());
        }
        return normalized;
    }

    // ------------------------------------------------------------------
    // Firecrawl execution
    // ------------------------------------------------------------------

    private Set<String> loadNormalizedDatabaseWebsites() {
        Set<String> normalized = new HashSet<>();
        try {
            Set<String> stored = buyerRepository.findAllWebsiteValues();
            if (stored != null) {
                for (String website : stored) {
                    String n = normalizeWebsite(website);
                    if (n != null && !n.isEmpty()) {
                        normalized.add(n);
                    }
                }
            }
        } catch (Exception e) {
            logger.warn("Failed to load existing websites from DB: {}", e.getMessage());
        }
        return normalized;
    }

    private List<BuyerSearchResult> executeSearch(String query, String businessType,
                                                   String apiKey, int limit,
                                                   String location, SearchBudget budget)
            throws JsonProcessingException {
        return executeSearch(query, businessType, apiKey, limit, location, budget, false);
    }

    private List<BuyerSearchResult> executeSearch(String query, String businessType,
                                                   String apiKey, int limit,
                                                   String location, SearchBudget budget,
                                                   boolean allowSocial)
            throws JsonProcessingException {
        List<BuyerSearchResult> results = new ArrayList<>();

        Map<String, Object> requestBody = new LinkedHashMap<>();
        requestBody.put("query", query);
        requestBody.put("limit", limit);
        requestBody.put("country", "US");
        if (location != null && !location.isBlank()) {
            requestBody.put("location", location);
        }
        // Never surface social profiles, business directories, review sites or
        // marketplaces - only real business domains can be relevant buyers.
        // EXCEPTION (allowSocial): the LinkedIn/Facebook targeting pass keeps
        // linkedin.com and facebook.com available so company/showcase/business
        // pages can be found, while every other non-business host stays blocked.
        List<String> excludeDomains = new ArrayList<>(NON_BUSINESS_HOSTS);
        if (allowSocial) {
            excludeDomains.remove("linkedin.com");
            excludeDomains.remove("facebook.com");
        }
        requestBody.put("excludeDomains", excludeDomains);
        requestBody.put("ignoreInvalidURLs", true);

        String responseJson = null;
        HttpStatusCode lastStatus = null;
        int attempt = 0;
        // Acquire one logical budget slot for this entire query (including its
        // 429 retries). A 429 retry is a single query retried, NOT a new query.
        // Acquiring here (before the loop) ensures retries never consume
        // additional slots from the 6-request logical search budget.
        if (!budget.tryAcquire()) {
            throw new BudgetExhaustedException(
                    "Firecrawl request budget exhausted before query '" + query + "'");
        }
        while (responseJson == null) {
            attempt++;
            // Log every request that actually hits the Firecrawl API (retries
            // included) so credit usage is always accountable.
            logger.info("Firecrawl request {}/{} (attempt {}/{}) for '{}'",
                    budget.used(), budget.max(), attempt, MAX_429_RETRIES + 1, query);

            // Respect the account-wide requests-per-minute budget before every
            // Firecrawl call, retries included. Runs before each attempt so a
            // backed-off retry also waits its turn behind other searches.
            throttleFirecrawlRequest();

            // exchangeToMono gives direct access to the response status/headers
            // (the config's default status handler is not applied here), so a
            // 429 can be detected and retried with a short backoff. The status
            // AND body must be captured inside a single reactive chain: reading
            // response.bodyToMono(...) after the exchange has already been
            // block()-ed returns an EMPTY body, because the completed exchange
            // discards the unread response body.
            Object[] statusAndBody = webClient.post()
                    .uri("/v2/search")
                    .header("Authorization", "Bearer " + apiKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .exchangeToMono(resp -> {
                        // Read the optional Retry-After BEFORE consuming the body:
                        // headers are always available on the ClientResponse, and
                        // this is the only per-attempt chance to capture them.
                        String retryAfter = resp.headers().header("Retry-After").stream()
                                .findFirst().orElse(null);
                        return resp.bodyToMono(String.class)
                                .defaultIfEmpty("")
                                .map(body -> new Object[]{resp.statusCode(), retryAfter, body});
                    })
                    .onErrorResume(e -> {
                        logger.error("Firecrawl request failed for query '{}': {}",
                                query, e.getMessage());
                        return Mono.just(new Object[]{HttpStatus.BAD_GATEWAY, null, ""});
                    })
                    .block();

            if (statusAndBody == null) {
                logger.warn("Firecrawl returned no response for query '{}'", query);
                return results;
            }

            HttpStatusCode responseStatus = (HttpStatusCode) statusAndBody[0];
            Object retryAfterHeader = statusAndBody[1];
            responseJson = (String) statusAndBody[2];
            lastStatus = responseStatus;

            if (responseStatus.isSameCodeAs(HttpStatus.TOO_MANY_REQUESTS)) {
                budget.recordRetry();
                if (attempt - 1 >= MAX_429_RETRIES) {
                    // After two backoff retries the query is skipped entirely -
                    // no long, repeated waiting that burns the request budget.
                    logger.error("Firecrawl rate-limited (429) for '{}' - skipping after {} attempts",
                            query, attempt);
                    return results;
                }
                // Wait for the server-provided Retry-After when the 429 carried one
                // (never retry immediately); fall back to the short fixed backoff
                // when the server sent no usable header.
                long serverWaitMs = serverRetryWaitMillis(retryAfterHeader);
                long backoffMs = serverWaitMs >= 0 ? serverWaitMs : retryBackoffMillis(attempt);
                logger.warn("Firecrawl rate-limited (429) for '{}' - retrying after {} ms (attempt {}/{}){}",
                        query, backoffMs, attempt, MAX_429_RETRIES,
                        serverWaitMs >= 0 ? " (server-provided Retry-After)" : "");
                sleepQuietly(backoffMs);
                continue;
            }

            if (responseStatus.isError()) {
                logger.error("Firecrawl HTTP {} for query '{}': {}",
                        responseStatus, query, safePreview(responseJson, 300));
                return results;
            }

            if (responseJson == null || responseJson.isBlank()) {
                // A 2xx response with an empty body means this query/engine call
                // produced nothing. Rewinding and retrying the SAME query is a
                // guaranteed credit burn, so return now and let the round use the
                // next role-word (distributor, wholesaler, ...) for the budget.
                logger.warn("Firecrawl HTTP {} for query '{}': API genuinely returned "
                                + "an empty body - 0 raw results, not a parsing failure",
                        responseStatus.value(), query);
                return results;
            }
        }

        // Parse outside the retry loop: the body was not consumed, so no retry
        // would change the content. A failure here is REAL and different from
        // the API returning zero results - it must never be logged as "0 valid".
        JsonNode root;
        try {
            root = objectMapper.readTree(responseJson);
        } catch (JsonProcessingException e) {
            logger.error("Firecrawl response PARSE FAILED for query '{}' (HTTP {}) - "
                            + "NOT counted as zero results. parseError='{}', preview={}",
                    query, lastStatus, e.getOriginalMessage(),
                    safePreview(responseJson, 300));
            return results;
        }

        if (root.hasNonNull("error")) {
            String errorMessage = root.get("error").asText("Unknown Firecrawl error");
            logger.warn("Firecrawl HTTP {} reported an error for query '{}': {}",
                    lastStatus, query, safePreview(errorMessage, 300));
            throw new RuntimeException("Firecrawl returned error: " + errorMessage);
        }

        if (!root.path("success").asBoolean(true)) {
            logger.warn("Firecrawl reported failure for query '{}', no results returned", query);
            return results;
        }

        JsonNode data = root.path("data");
        JsonNode resultsArray = data;
        // Some Firecrawl revisions return per-source arrays under data.web.
        if (!data.isArray() && data.isObject() && data.path("web").isArray()) {
            resultsArray = data.path("web");
        }
        if (!resultsArray.isArray()) {
            logger.warn("No results array for query '{}'. Keys: {} (HTTP {})",
                    query, root.fieldNames(), lastStatus);
            return results;
        }

        int noLink = 0;
        int noTitle = 0;
        for (JsonNode item : resultsArray) {
            String title = extractText(item, "title");
            String link = extractText(item, "url");
            if (link.isEmpty()) {
                link = extractText(item, "link");
            }
            if (link.isEmpty()) {
                link = extractText(item, "pageUrl");
            }
            String snippet = extractText(item, "description");
            if (snippet.isEmpty()) {
                snippet = extractText(item, "snippet");
            }
            // Google Business / local-result data and generic meta fields often
            // carry the real business address - the most reliable structured
            // location source of all. It is kept on the result so per-buyer
            // location extraction can use it before touching any website.
            String searchAddress = extractGoogleBusinessAddress(item);
            if (searchAddress.isEmpty()) {
                // Generic meta fields (Firecrawl may name it "meta" or
                // "metadata") sometimes carry an address too.
                JsonNode meta = item.path("meta").isObject() ? item.path("meta")
                        : item.path("metadata");
                if (meta.isObject() && meta.path("address").isTextual()) {
                    searchAddress = meta.path("address").asText("").trim();
                }
            }

            if (title.isEmpty()) {
                noTitle++;
            }
            if (link.isEmpty()) {
                noLink++;
            }
            if (!title.isEmpty() && !link.isEmpty()) {
                BuyerSearchResult parsed = new BuyerSearchResult(
                        title, link, "USA", businessType, link, query, snippet);
                if (!searchAddress.isEmpty()) {
                    parsed.setSearchAddress(searchAddress);
                }
                results.add(parsed);
            }
        }

        int rawCount = resultsArray.size();
        int parsedCount = results.size();
        int rejectedCount = rawCount - parsedCount;
        if (rawCount == 0) {
            // The API genuinely returned zero results for this query - a parse
            // never happened, so this is NOT treated as a parsing failure.
            logger.info("Firecrawl HTTP {} [query '{}']: API returned 0 raw results, "
                            + "0 parsed, 0 rejected - genuine zero, not a parse failure. preview={}",
                    lastStatus, query, safePreview(responseJson, 200));
        } else if (parsedCount == 0) {
            // Raw results existed but none had both a title and URL - flagged so
            // it can never be mistaken for "the API returned nothing".
            logger.warn("Firecrawl HTTP {} [query '{}']: {} raw results -> 0 parsed "
                            + "({} rejected: title missing={}, link missing={}) - "
                            + "results HAVE a body but could not be extracted; preview={}",
                    lastStatus, query, rawCount, rejectedCount,
                    noTitle, noLink, safePreview(responseJson, 300));
        } else {
            logger.info("Firecrawl HTTP {} [query '{}']: {} raw results -> {} parsed "
                            + "({} rejected: title missing={}, link missing={})",
                    lastStatus, query, rawCount, parsedCount,
                    rejectedCount, noTitle, noLink);
        }

        return results;
    }

    // Short, safe single-line preview of a Firecrawl response body for logs.
    private String safePreview(String body, int maxLen) {
        if (body == null) {
            return "null";
        }
        String flat = body.replace('\r', ' ').replace('\n', ' ')
                .replaceAll("[\\t ]+", " ").trim();
        if (flat.length() <= maxLen) {
            return flat;
        }
        return flat.substring(0, maxLen) + "...(" + flat.length() + " total chars)";
    }

    /**
     * Waits so Firecrawl requests are fired at most every
     * MIN_FIRECRAWL_REQUEST_INTERVAL_MS, using a static timestamp shared by all
     * searches (even concurrent ones) so the account's requests-per-minute
     * budget is honoured. Failed compare-and-set means another request just
     * claimed the slot, so the loop simply waits for the next one.
     */
    private void throttleFirecrawlRequest() {
        while (true) {
            long now = System.nanoTime();
            long nextAllowed = LAST_FIRECRAWL_REQUEST_NANOS.get()
                    + TimeUnit.MILLISECONDS.toNanos(MIN_FIRECRAWL_REQUEST_INTERVAL_MS);
            long waitMs = TimeUnit.NANOSECONDS.toMillis(nextAllowed - now);
            if (waitMs <= 0) {
                if (LAST_FIRECRAWL_REQUEST_NANOS.compareAndSet(
                        LAST_FIRECRAWL_REQUEST_NANOS.get(), now)) {
                    return;
                }
                continue;
            }
            sleepQuietly(Math.min(waitMs, MIN_FIRECRAWL_REQUEST_INTERVAL_MS));
        }
    }

    /**
     * Short fixed backoff for a rate-limited query: ~2.5s before the first
     * retry and ~6s before the second (2-3s and 5-7s with jitter). Never a long
     * wait - after MAX_429_RETRIES retries the query is skipped entirely.
     */
    private long retryBackoffMillis(int attempt) {
        int idx = Math.min(attempt - 1, FIRE_429_RETRY_BASE_DELAY_MS.length - 1);
        long jitter = ThreadLocalRandom.current().nextLong(FIRE_429_RETRY_JITTER_MS[idx] + 1);
        return FIRE_429_RETRY_BASE_DELAY_MS[idx] + jitter;
    }

    /**
     * Server-provided Retry-After (seconds) when the 429 response carried one.
     * The search NEVER retries immediately after a 429: it waits the full
     * server-requested delay, hard-capped at MAX_SERVER_RETRY_AFTER_MS so a
     * hostile/huge value can never stall the search indefinitely. Returns -1
     * (caller falls back to the fixed short backoff) when the server sent no
     * usable Retry-After header.
     */
    private long serverRetryWaitMillis(Object retryAfterHeader) {
        if (retryAfterHeader == null) {
            return -1;
        }
        try {
            String raw = String.valueOf(retryAfterHeader).trim();
            if (raw.isEmpty()) {
                return -1;
            }
            long seconds = Long.parseLong(raw);
            if (seconds <= 0) {
                return -1;
            }
            return Math.min(seconds * 1000L, MAX_SERVER_RETRY_AFTER_MS);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void sleepQuietly(long millis) {
        if (millis <= 0) {
            return;
        }
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Reads a field from a Firecrawl search result, falling back to the nested
     * metadata object. The field can be a plain string or an array (Firecrawl
     * may return either), in which case the first element is used.
     */
    private String extractText(JsonNode item, String field) {
        JsonNode node = item.path(field);
        String value = node.isArray() && node.size() > 0 ? node.get(0).asText("").trim()
                : node.asText("").trim();
        if (value.isEmpty()) {
            JsonNode meta = item.path("metadata");
            JsonNode metaNode = meta.path(field);
            value = metaNode.isArray() && metaNode.size() > 0 ? metaNode.get(0).asText("").trim()
                    : metaNode.asText("").trim();
        }
        return value;
    }

    /**
     * Extracts the structured business address carried by a Firecrawl Google
     * Search result item. Google local results put the address in
     * google.business_data.address (a formatted string) and often also expose
     * the separate locality/region parts; older revisions may nest it under a
     * "googleData" key. Returns "" when no address is present.
     */
    private String extractGoogleBusinessAddress(JsonNode item) {
        if (item == null) {
            return "";
        }
        JsonNode google = item.path("google");
        if (!google.isObject()) {
            google = item.path("googleData");
        }
        if (!google.isObject()) {
            return "";
        }
        JsonNode business = google.path("business_data");
        if (business.isObject()) {
            JsonNode address = business.path("address");
            if (address.isTextual() && !address.asText().trim().isEmpty()) {
                return address.asText().trim();
            }
            // Address parts (Google may return them separately).
            JsonNode locality = business.path("locality");
            JsonNode region = business.path("region");
            String loc = locality.isTextual() ? locality.asText().trim() : "";
            String reg = region.isTextual() ? region.asText().trim() : "";
            if (!loc.isEmpty() && !reg.isEmpty()) {
                return loc + ", " + reg;
            }
            String street = business.path("streetAddress").asText("").trim();
            String postal = business.path("postalCode").asText("").trim();
            if (!street.isEmpty() && !loc.isEmpty()) {
                String base = street + ", " + loc;
                return (postal.isEmpty() ? base : base + " " + postal).trim();
            }
        }
        JsonNode address = google.path("address");
        if (address.isTextual() && !address.asText().trim().isEmpty()) {
            return address.asText().trim();
        }
        return "";
    }

    private String normalizeWebsite(String url) {
        if (url == null || url.isEmpty()) {
            return null;
        }
        try {
            URI uri = URI.create(url);
            String host = uri.getHost();
            if (host == null || host.isEmpty()) {
                return null;
            }
            host = host.toLowerCase();
            if (host.startsWith("www.")) {
                host = host.substring(4);
            }
            return "https://" + host;
        } catch (Exception e) {
            return url.toLowerCase();
        }
    }

    /**
     * Returns true when the (normalized) website belongs to a social network,
     * directory, review or marketplace host that can never be a real buyer
     * business, or is a subdomain / sub-path of one. Subdomains are checked so
     * e.g. "elpaso.yellowpages.com" is still filtered even though the host is
     * not literally in the blocked set.
     */
    private boolean isNonBusinessHost(String normalizedWebsite) {
        if (normalizedWebsite == null) {
            return false;
        }
        try {
            URI uri = URI.create(normalizedWebsite);
            String host = uri.getHost();
            if (host == null) {
                return false;
            }
            host = host.toLowerCase();
            if (host.startsWith("www.")) {
                host = host.substring(4);
            }
            if (NON_BUSINESS_HOSTS.contains(host)) {
                return true;
            }
            int dot = host.indexOf('.');
            while (dot > 0 && dot < host.length() - 1) {
                String base = host.substring(dot + 1);
                if (NON_BUSINESS_HOSTS.contains(base)) {
                    return true;
                }
                dot = host.indexOf('.', dot + 1);
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private static Map<String, String> buildStateAbbreviations() {
        Map<String, String> map = new HashMap<>();
        map.put("alabama", "AL");
        map.put("alaska", "AK");
        map.put("arizona", "AZ");
        map.put("arkansas", "AR");
        map.put("california", "CA");
        map.put("colorado", "CO");
        map.put("connecticut", "CT");
        map.put("delaware", "DE");
        map.put("florida", "FL");
        map.put("georgia", "GA");
        map.put("hawaii", "HI");
        map.put("idaho", "ID");
        map.put("illinois", "IL");
        map.put("indiana", "IN");
        map.put("iowa", "IA");
        map.put("kansas", "KS");
        map.put("kentucky", "KY");
        map.put("louisiana", "LA");
        map.put("maine", "ME");
        map.put("maryland", "MD");
        map.put("massachusetts", "MA");
        map.put("michigan", "MI");
        map.put("minnesota", "MN");
        map.put("mississippi", "MS");
        map.put("missouri", "MO");
        map.put("montana", "MT");
        map.put("nebraska", "NE");
        map.put("nevada", "NV");
        map.put("new hampshire", "NH");
        map.put("new jersey", "NJ");
        map.put("new mexico", "NM");
        map.put("new york", "NY");
        map.put("north carolina", "NC");
        map.put("north dakota", "ND");
        map.put("ohio", "OH");
        map.put("oklahoma", "OK");
        map.put("oregon", "OR");
        map.put("pennsylvania", "PA");
        map.put("rhode island", "RI");
        map.put("south carolina", "SC");
        map.put("south dakota", "SD");
        map.put("tennessee", "TN");
        map.put("texas", "TX");
        map.put("utah", "UT");
        map.put("vermont", "VT");
        map.put("virginia", "VA");
        map.put("washington", "WA");
        map.put("washington state", "WA");
        map.put("west virginia", "WV");
        map.put("wisconsin", "WI");
        map.put("wyoming", "WY");
        map.put("district of columbia", "DC");
        return Collections.unmodifiableMap(map);
    }
}